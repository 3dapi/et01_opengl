// Interface for the IGLSprite class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _IGLSprite_H_
#define _IGLSprite_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
	virtual ~CLASS_NAME(){}
#endif


interface IGLSprite
{
	LC_CLASS_DESTROYER(	IGLSprite	);

	virtual INT Create()=0;
	virtual INT Draw(	IGLTexture* pTx			// Texture Pointer
					,	RECT* rc				// Image rect
					,	D3DXVECTOR2* vcScl		// Scaling
					,	D3DXVECTOR2* vcRot		// Rotation Center
					,	FLOAT fRot				// Angle(Radian)
					,	D3DXVECTOR2* vcTrns		// Position
					,	D3DXCOLOR dcolor		// color
					)=0;
};


INT LgDev_CreateSprite(char* sCmd
					, IGLSprite** pData);


#endif

