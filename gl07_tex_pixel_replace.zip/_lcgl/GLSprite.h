// Interface for the CGLSprite class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _GLSprite_H_
#define _GLSprite_H_


class CGLSprite : public IGLSprite
{
public:
	virtual ~CGLSprite();

	virtual INT Create();

	virtual INT Draw(	IGLTexture* pTx	// Texture Pointer
			,	RECT* rc				// Image rect
			,	D3DXVECTOR2* vcScl		// Scaling
			,	D3DXVECTOR2* vcRot		// Rotation Center
			,	FLOAT fRot				// Angle(Radian)
			,	D3DXVECTOR2* vcTrns		// Position
			,	D3DXCOLOR dcolor		// color
			);
};

#endif

