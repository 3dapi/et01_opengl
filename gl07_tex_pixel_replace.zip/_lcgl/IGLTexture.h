// Interface for the IGLTexture class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _IGLTexture_H_
#define _IGLTexture_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
	virtual ~CLASS_NAME(){}
#endif


interface IGLTexture
{
	LC_CLASS_DESTROYER(	IGLTexture	);

	virtual	INT		Create(char* sFile, DWORD color, DWORD dFilter)=0;
	virtual	void	Destroy()=0;

	virtual	void	SetTexture(INT modulate)=0;

	virtual	GLuint	GetName()=0;
	virtual	GLenum	GetFMT()=0;
	virtual	GLenum	GetType()=0;

	virtual	INT		GetImgW()=0;
	virtual	INT		GetImgH()=0;

	virtual	void	DrawPixel(RECT* rc			// Image rect
						, D3DXVECTOR2* vcScl	// Scaling
						, D3DXVECTOR2* vcRot	// Rotation Center
						, FLOAT fRot			// Angle(Radian)
						, D3DXVECTOR2* vcTrn	// Position
						, D3DXCOLOR dcolor		// color
						)=0;
};


INT LgDev_CreateTexture(char* sCmd
					, IGLTexture** pData
					, char* sFile
					, DWORD dcolorKey
					, DWORD dFilter=0);


#endif