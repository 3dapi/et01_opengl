// Interface for the CGLTexture class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _GLTexture_H_
#define _GLTexture_H_


class CGLTexture : public IGLTexture
{
protected:
	GLuint		m_nTex;			// Name
	GLenum		m_Fmt;			// Pixel Format
	GLenum		m_Type;			// Pixel Data Type

	INT			m_ImgW;
	INT			m_ImgH;
	DWORD		m_dKey;			// Color Key

public:
	CGLTexture ();
	virtual ~CGLTexture();

	virtual	INT		Create(char* sFile, DWORD dColor, DWORD dFilter);
	virtual	void	Destroy();

	virtual	void	SetTexture(INT modulate);

	virtual	GLuint	GetName()	{	return m_nTex;	}
	virtual	GLenum	GetFMT()	{	return m_Fmt;	}
	virtual	GLenum	GetType()	{	return m_Type;	}
	virtual	INT		GetImgW()	{	return m_ImgW;	}
	virtual	INT		GetImgH()	{	return m_ImgH;	}

	virtual	void	DrawPixel(RECT* rc			// Image rect
						, D3DXVECTOR2* vcScl	// Scaling
						, D3DXVECTOR2* vcRot	// Rotation Center
						, FLOAT fRot			// Angle(Radian)
						, D3DXVECTOR2* vcTrn	// Position
						, D3DXCOLOR dcolor		// color
						);
};




#endif