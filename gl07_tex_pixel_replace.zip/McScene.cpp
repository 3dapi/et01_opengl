// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
}


CMcScene::~CMcScene()
{
	Destroy();
}

void CMcScene::Destroy()
{
	if(m_nTex)
	{
		glDeleteTextures(1, &m_nTex);
		m_nTex = 0;
	}
}


INT CMcScene::Init()
{
	INT	hr=0;

	INT		ImgW=128;
	INT		ImgH=128;

	DWORD*	pPxl = new DWORD[ImgW * ImgH];

	for(int y=0; y<ImgH; ++y)
	{
		for(int x=0; x<ImgW; ++x)
		{
			pPxl[ y * ImgW + x]=D3DXCOLOR(0,1,1,1);
		}
	}

	glGenTextures (1,&m_nTex);

	glBindTexture (GL_TEXTURE_2D, m_nTex);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, ImgW, ImgH, 0, GL_RGBA, GL_UNSIGNED_BYTE, pPxl);

	glBindTexture (GL_TEXTURE_2D, 0);
	glDisable(GL_TEXTURE_2D);

	delete pPxl;

	return 0;
}

INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	glShadeModel(GL_SMOOTH);
	glEnable(GL_CULL_FACE);
	glFrontFace(GL_CCW);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);


	glDisable(GL_ALPHA_TEST);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDisable(GL_FOG);
	glDisable(GL_BLEND);



	// ��ȯ ��� ����
	float	mtPrj[16]={0};
	float	mtViw[16]={0};
	glGetFloatv(GL_PROJECTION_MATRIX, (GLfloat*)mtPrj);
	glGetFloatv(GL_MODELVIEW_MATRIX, (GLfloat*)mtViw);

	// ��ȯ ��� ���� �ʱ�ȭ
	glMatrixMode(GL_PROJECTION);	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);		glLoadIdentity();



	glBindTexture (GL_TEXTURE_2D, m_nTex);

	INT		ImgW=128;
	INT		ImgH=128;
	DWORD*	pPxl = new DWORD[ImgW * ImgH];
	glGetTexImage(GL_TEXTURE_2D, 0, GL_RGBA, GL_UNSIGNED_BYTE, pPxl);
	
	for(int y=0; y<ImgH; ++y)
	{
		for(int x=0; x<ImgW; ++x)
		{
			pPxl[ y * ImgW + x]=D3DXCOLOR(1,0,1,1);
		}
	}


	glTexImage2D(GL_TEXTURE_2D, 0, 4, ImgW, ImgH, 0, GL_RGBA, GL_UNSIGNED_BYTE, pPxl);
	delete [] pPxl;



	glEnable(GL_TEXTURE_2D);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexEnvi (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);


	glBegin(GL_TRIANGLE_FAN);
		glTexCoord2f(0, 0); glVertex3f(-0.6f, -0.6f, 0);
		glTexCoord2f(1, 0); glVertex3f( 0.6f, -0.6f, 0);	
		glTexCoord2f(1, 1); glVertex3f( 0.6f,  0.6f, 0);
		glTexCoord2f(0, 1); glVertex3f(-0.6f,  0.6f, 0);
	glEnd();


	glColor4f(1, 1, 1, 1);


	glBindTexture (GL_TEXTURE_2D, 0);
	glDisable(GL_TEXTURE_2D);				// Enable 2D texturing
}



