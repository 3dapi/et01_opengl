

#include "_StdAfx.h"


CMain*	g_pApp = NULL;


int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int)
{
	CMain mainApp;
	g_pApp = &mainApp;


	if(FAILED(mainApp.Create(hInst)))
		return 0;


	return mainApp.Run();
}


