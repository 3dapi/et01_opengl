// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
}


CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Init()
{
	return 0;
}

void CMcScene::Destroy()
{
}

INT CMcScene::FrameMove()
{
	float fAngle = GetTickCount() * 0.1f;

	
	D3DXMATRIX	mtScl1;
	D3DXMATRIX	mtRot1;
	D3DXMATRIX	mtTrn1;

	D3DXMatrixIdentity(&m_mtObj);
	D3DXMatrixScaling(&mtScl1, 1.0f, 1.0f, 1.0f);
	D3DXMatrixRotationAxis(&mtRot1, &D3DXVECTOR3(0, 0, 1), D3DXToRadian(fAngle*0.f));
	D3DXMatrixTranslation(&mtTrn1, 0, 0, 0);

//	m_mtObj = mtScl1 * mtRot1 * mtTrn1;


	return 0;
}

void CMcScene::Render()
{
	if(::GetAsyncKeyState('L') & 0x8000)
		glShadeModel(GL_FLAT);
	else
		glShadeModel(GL_SMOOTH);


	glEnable(GL_CULL_FACE);			// Culling Ȱ��ȭ
	glEnable(GL_DEPTH_TEST);		// ���� �׽�Ʈ Ȱ��ȭ
	glFrontFace(GL_CCW);			// ������ CCW�� �׸���.
	

	D3DXVECTOR4	LgtPos0( 1.0f, 0.5f,  0.5f, 0.0f);	// Lighting Direction
	D3DXCOLOR	LgtDif0( 2.0f, 0.4f,  0.4f, 1.0f);	// Diffuse Lighting Color
	D3DXCOLOR	LgtSpc0( 0.0f, 1.4f,  3.0f, 1.0f);	// Specular Lighting Color


	D3DXVECTOR4	LgtPos1(-1.0f,-0.5f, -0.5f, 0.0f);	// Lighting Direction
	D3DXCOLOR	LgtDif1( 0.4f, 0.4f,  1.5f, 1.0f);	// Diffuse Lighting Color
	D3DXCOLOR	LgtSpc1( 0.9f, 0.4f,  0.4f, 1.0f);	// Specular Lighting Color


	D3DXCOLOR	MtlColS( 0.6f, 0.6f,  0.6f, 1.0f);	// Material Color

	glLightfv(GL_LIGHT0, GL_POSITION, (GLfloat*)LgtPos0);	// Position(or Direction)
	glLightfv(GL_LIGHT0, GL_DIFFUSE , (GLfloat*)LgtDif0);	// Diffuse Element
	glLightfv(GL_LIGHT0, GL_SPECULAR, (GLfloat*)LgtSpc0);	// Specular Element


	glLightfv(GL_LIGHT1, GL_POSITION, (GLfloat*)LgtPos1);	// Position(or Direction)
	glLightfv(GL_LIGHT1, GL_DIFFUSE , (GLfloat*)LgtDif1);	// Diffuse Element
	glLightfv(GL_LIGHT1, GL_SPECULAR, (GLfloat*)LgtSpc1);	// Specular Element


	glMaterialfv(GL_FRONT, GL_DIFFUSE,(GLfloat*)MtlColS);
	glMaterialfv(GL_FRONT, GL_SPECULAR,(GLfloat*)MtlColS);
	glMaterialf (GL_FRONT, GL_SHININESS, 90.0F);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);

	DrawModel(&m_mtObj);


	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_LIGHTING);
}



void CMcScene::DrawModel(D3DXMATRIX* mtWorld)
{
	glPushMatrix();
		glMultMatrixf((FLOAT*)mtWorld);

		glutSolidSphere(6.F, 160, 120);
	glPopMatrix();
}