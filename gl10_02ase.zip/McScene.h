// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef _McScene_H_
#define _McScene_H_


class CMcScene
{
protected:
	ILcMdl*		m_pMdlOrg1	;		// Original
	ILcMdl*		m_pMdlIns1	;		// Instance

	ILcMdl*		m_pMdlOrg2	;		// Original
	ILcMdl*		m_pMdlIns2	;		// Instance

public:
	CMcScene();
	virtual ~CMcScene();

	INT		Init();
	void	Destroy();
	INT		FrameMove();
	void	Render();
};


#endif

