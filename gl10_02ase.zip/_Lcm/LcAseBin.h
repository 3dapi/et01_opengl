// Interface for the CLcAseB class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcAseBin_H_
#define _LcAseBin_H_


class CLcAseB : public ILcMdl
{
public:

	struct Tmtl
	{
		char			sTex[LCM_TX_NAME];
		IGLTexture*		pTex;

		Tmtl();
		~Tmtl();
	};

	struct Tidx
	{
		WORD a;	WORD b;	WORD c;
		Tidx() : a(0), b(1), c(2){}
	};

	struct Tvtx
	{
		D3DXVECTOR3	p;
		Tvtx() : p(0,0,0){}
		enum	{FVF = (D3DFVF_XYZ),};
	};
		
	struct TvtxUV
	{
		D3DXVECTOR3	p;
		FLOAT	u, v;

		TvtxUV() : p(0,0,0), u(0),v(0){}
		enum	{FVF = (D3DFVF_XYZ|D3DFVF_TEX1),};
	};

	struct Ttrack
	{
		INT		nF;																// Frame
		FLOAT	x;
		FLOAT	y;
		FLOAT	z;
		FLOAT	w;

		Ttrack() : nF(0), x(0), y(0), z(0), w(0){}
	};


	struct Tgeo
	{
		char		sName[32];			// Current Node Name
		INT			nPrn	;				// Parent Index
		INT			nMtl	;				// Material Index

		INT			iNix	;				// Number of Index
		INT			iNvx	;				// Number of Vertex
		Tidx*		pIdx	;				// indexed buffer
		void*		pVtx	;				// vertex buffer
		DWORD		dFVF	;				// Flexible Vertex Format
		DWORD		dVtx	;				// Zero Stride

		D3DXMATRIX	mtTmL	;				// Tm Local
		D3DXMATRIX	mtW		;				// World Matrix
		D3DXMATRIX	mtL		;				// Local Matrix
		
		INT			nRot	;				// Rotation Number
		INT			nTrs	;				// Translation Number
		Ttrack*		vRot	;				// Rotation
		Ttrack*		vTrs	;				// Translation

		Tgeo();
		~Tgeo();
	};

	struct Thead
	{
		char		sVer[16]	;
		INT			nFrmF		;			// First Frame
		INT			nFrmL		;			// Last Frame
		INT			nFrmS		;			// Frame Speed
		INT			nFrmT		;			// Tick per Frame

		Thead():nFrmF(0),nFrmL(0),nFrmS(0),nFrmT(0)
		{
			memset(sVer, 0, sizeof sVer);
		}
	};


protected:
	char		m_sFile[MAX_PATH];

	Thead		m_Scene		;
	INT			m_nMtl		;
	Tmtl*		m_pMtl		;

	INT			m_nGeo		;
	Tgeo*		m_pGeo		;

	DOUBLE		m_dFrmCur	;				// Current Frame
	DOUBLE		m_dTimeCur	;				// Current Time
	D3DXMATRIX	m_mtWld		;				// World Matrix


public:
	CLcAseB();
	virtual ~CLcAseB();

	virtual INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		SetAttrib(char* sCmd, void* pData);
	virtual INT		GetAttrib(char* sCmd, void* pData);

public:
	const Thead* GetHeader() const{	return &m_Scene;}
	INT		GetNumMtl()			{	return m_nMtl;	}
	Tmtl*	GetMtrl()	 const	{	return m_pMtl;	}

	INT		GetNumGeo()			{	return m_nGeo;	}
	Tgeo*	GetGeometry() const	{	return m_pGeo;	}
	INT		GetAniTrack(void* mtA, INT nGeo, FLOAT dFrame);

protected:
	INT		Load();
};

#endif

