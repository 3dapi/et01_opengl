// Interface for the CLcAseInst class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcAseInst_H_
#define _LcAseInst_H_


#include <vector>


class CLcAseInst : public ILcMdl
{
public:
	struct TlinkTm
	{
		D3DXMATRIX	mtW		;		// World Matrix
		D3DXMATRIX	mtL		;		// Local Matrix
		INT			nPrn	;		// Parent Node Index

		TlinkTm();
	};

protected:
	CLcAse*		m_pOrg		;		// Original ASE Model Pointer

	INT			m_nFrmF		;		// First Frame
	INT			m_nFrmL		;		// Last Frame
	INT			m_nFrmS		;		// Frame Speed
	INT			m_nFrmT		;		// Tick per Frame

	INT				m_nMtl	;		// copy from Original
	CLcAse::AseMtl*	m_pMtl	;
	INT				m_nGeo	;		// copy from Original
	CLcAse::AseGeo*	m_pGeo	;


	DOUBLE		m_dFrmCur	;		// Current Frame
	DOUBLE		m_dTimeCur	;		// Current Time

	D3DXMATRIX	m_mtWld		;		// World Matrix
	TlinkTm*	m_pTM		;		// World and Animation Matrix


public:
	CLcAseInst();
	virtual ~CLcAseInst();

	virtual INT		Create(void* p1=0, void* p2=0, void* p3=0, void* p4=0);
	virtual void	Destroy();

	virtual INT		FrameMove();
	virtual void	Render();

	virtual INT		SetAttrib(char* sCmd, void* pData);
	virtual INT		GetAttrib(char* sCmd, void* pData);
};

#endif

