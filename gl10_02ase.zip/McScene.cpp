// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pMdlOrg1	= NULL;
	m_pMdlIns1	= NULL;

	m_pMdlOrg2	= NULL;
	m_pMdlIns2	= NULL;
}


CMcScene::~CMcScene()
{
	Destroy();
}

void CMcScene::Destroy()
{
	SAFE_DELETE(	m_pMdlOrg1	);
	SAFE_DELETE(	m_pMdlIns1	);

	SAFE_DELETE(	m_pMdlOrg2	);
	SAFE_DELETE(	m_pMdlIns2	);
}

INT CMcScene::Init()
{
	INT	hr=0;

	hr = LcMdl_CreateAse("Ase Text PC", &m_pMdlOrg1, NULL, "Model/dancing.ase");
	if(FAILED(hr))
		return -1;

	hr = LcMdl_CreateAse("Ase Text PC", &m_pMdlIns1, NULL, NULL, m_pMdlOrg1);
	if(FAILED(hr))
		return -1;

	hr = LcMdl_CreateAse("Ase Bin PC", &m_pMdlOrg2, NULL, "Model/dancing.asb");
	if(FAILED(hr))
		return -1;

	hr = LcMdl_CreateAse("Ase Bin PC", &m_pMdlIns2, NULL, NULL, m_pMdlOrg2);
	if(FAILED(hr))
		return -1;

	return 0;
}

INT CMcScene::FrameMove()
{
	D3DXMATRIX	mtRotX;
	D3DXMATRIX	mtRotZ;
	D3DXMATRIX	mtWld;
	float		fTime = 0;

	DOUBLE		fElapsed = MAINAPP->GetElapsed();


	D3DXMatrixIdentity(&mtRotX);
	D3DXMatrixIdentity(&mtRotZ);
	D3DXMatrixIdentity(&mtWld);


	D3DXMatrixIdentity(&mtWld);
	D3DXMatrixRotationZ(&mtRotZ, D3DXToRadian(0));
	D3DXMatrixTranslation(&mtWld, -150, 0, 0);
	mtWld = mtRotX * mtRotZ * mtWld;
	fTime = fElapsed*0.8;

	m_pMdlOrg1->SetAttrib("World Matrix", &mtWld);
	m_pMdlOrg1->SetAttrib("Advance Time", &fTime);
	SAFE_FRAMEMOVE(	m_pMdlOrg1	);


	D3DXMatrixIdentity(&mtWld);
	D3DXMatrixRotationZ(&mtRotZ, D3DXToRadian(90));
	D3DXMatrixTranslation(&mtWld, -50, 0, 0);
	mtWld = mtRotZ * mtWld;
	fTime = fElapsed*.4;

	m_pMdlIns1->SetAttrib("World Matrix", &mtWld);
	m_pMdlIns1->SetAttrib("Advance Time", &fTime);
	SAFE_FRAMEMOVE(	m_pMdlIns1	);


	D3DXMatrixIdentity(&mtWld);
	D3DXMatrixRotationZ(&mtRotZ, D3DXToRadian(-90));
	D3DXMatrixTranslation(&mtWld, 50, 0, 0);
	mtWld = mtRotZ * mtWld;
	fTime = fElapsed*.6f;

	m_pMdlOrg2->SetAttrib("World Matrix", &mtWld);
	m_pMdlOrg2->SetAttrib("Advance Time", &fTime);
	SAFE_FRAMEMOVE(	m_pMdlOrg2	);


	D3DXMatrixIdentity(&mtWld);
	D3DXMatrixRotationZ(&mtRotZ, D3DXToRadian(-90));
	D3DXMatrixTranslation(&mtWld, 150, 0, 0);
	mtWld = mtRotZ * mtWld;
	fTime = fElapsed*1.f;

	m_pMdlIns2->SetAttrib("World Matrix", &mtWld);
	m_pMdlIns2->SetAttrib("Advance Time", &fTime);
	SAFE_FRAMEMOVE(	m_pMdlIns2	);

	return 0;
}

void CMcScene::Render()
{
	glDisable(GL_CULL_FACE);
	SAFE_RENDER(	m_pMdlOrg1	);
	SAFE_RENDER(	m_pMdlIns1	);

	SAFE_RENDER(	m_pMdlOrg2	);
	SAFE_RENDER(	m_pMdlIns2	);
}


