// Interface for the CApplicationGL class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef _AppGL_H_
#define _AppGL_H_


class CApplicationGL
{
protected:
	HINSTANCE	m_hInst		;
	HWND		m_hWnd		;
	HACCEL		m_hAccl		;			// Accelator

	INT			m_ScnX		;			// Screen X
	INT			m_ScnY		;			// Screen Y
	RECT		m_rcWin		;			// WinRect

	INT			m_ScnW		;			// Width
	INT			m_ScnH		;			// Height
	INT			m_ScnD		;			// Depth
	INT			m_ScnS		;			// Stencil
	INT			m_ScnC		;			// Color Bit
	INT			m_ScnR		;			// Color Red Bit
	INT			m_ScnG		;			// Color Green Bit
	INT			m_ScnB		;			// Color Blue Bit
	INT			m_ScnA		;			// Color Alpha Bit
	INT			m_ScnM		;			// Multi Sample
	char		m_sCls[128]	;

	DWORD		m_dWinStyle	;
	DWORD		m_dWinAccl	;
	DWORD		m_dWinMode	;
	DWORD		m_dWinExit	;
	BOOL		m_bWindow	;
	BOOL		m_bActive	;
	DEVMODE		m_DevWin	;
	DEVMODE		m_DevFull	;
	

	HDC			m_hDC		;		// Device Context
	HGLRC		m_hRC		;		// Rendering Context
	INT			m_bChkMulti	;		// Check Multi Sampling

	DOUBLE		m_fElapsed	;
	FLOAT		m_fFPS		;
	D3DXCOLOR	m_dClear	;		// clear color

public:
	CApplicationGL();
	INT		Create(HINSTANCE);
	INT		Run();

	static CApplicationGL* m_pAppGL;
	static LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);

protected:
	INT		Init3DEnvironment();
	INT		Cleanup3DEnvironment();
	INT		Render3DEnvironment();
	void	UpdateFPS();

	INT		WindowCreate();
	void	WindowResize(INT width, INT height);
	INT		WindowChange();
	
	INT		GLCreate();
	INT		GLDestroy();
	void	GLVSyncOn(BOOL bVsyncOn = TRUE);


protected:
	virtual	INT		Init()		{	return 0;	}
	virtual	INT		Destroy()	{	return 0;	}
	virtual	INT		FrameMove()	{	return 0;	}
	virtual	INT		Render()	{	return 0;	}
	virtual	LRESULT	MsgProc(HWND,UINT,WPARAM,LPARAM);

public:
	DOUBLE	GetElapsed()	{	return m_fElapsed;	}
	FLOAT	GetFPS()		{	return m_fFPS;		}
};

#endif


