// Interface for the CLcInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcInput_H_
#define _LcInput_H_


class CLcInput : public ILcInput
{
public:
	enum
	{
		EINPUT_NONE  = 0,
		EINPUT_DOWN  = 1,
		EINPUT_UP	 = 2,
		EINPUT_PRESS = 3,
		EINPUT_DBCLC = 4,
	};

	enum
	{
		MAX_INPUT_KEY	= 256,
		MAX_INPUT_BTN	=   8,
	};

protected:
	HWND		m_hWnd;
	
	BYTE		m_KeyCur[MAX_INPUT_KEY];	// Ű���� ���� ����
	BYTE		m_KeyOld[MAX_INPUT_KEY];	// Ű���� ���� ����
	BYTE		m_KeyMap[MAX_INPUT_KEY];	// Ű���� ��

	BYTE		m_BtnCur[MAX_INPUT_BTN];	// ���콺 ���� ����
	BYTE		m_BtnOld[MAX_INPUT_BTN];	// ���콺 ���� ����
	BYTE		m_BtnMap[MAX_INPUT_BTN];	// ���콺 ��

	D3DXVECTOR3	m_vcCur;					// �� ���콺 Z
	D3DXVECTOR3	m_vcOld;
	D3DXVECTOR3	m_vcEps;

	DWORD		m_dTimeDC;					// Double Click Time Interval
	DWORD		m_dBtnBgn[MAX_INPUT_BTN];	// Double Click Start
	INT			m_dBtnCnt[MAX_INPUT_BTN];	// Double Click Count


public:
	CLcInput();
	virtual ~CLcInput();

	virtual	INT		Create(HWND	hWnd);
	virtual	INT		FrameMove();
	virtual	LRESULT	MsgProc(HWND, UINT, WPARAM, LPARAM);

	virtual	BOOL	KeyDown	(INT nKey);
	virtual	BOOL	KeyUp	(INT nKey);
	virtual	BOOL	KeyPress(INT nKey);
	virtual	INT		KeyState(INT nKey);

	virtual	BOOL	BtnDown	(INT nBtn);
	virtual	BOOL	BtnUp	(INT nBtn);
	virtual	BOOL	BtnPress(INT nBtn);
	virtual	INT		BtnState(INT nBtn);

	virtual	const D3DXVECTOR3* GetMousePos() const;
	virtual	const D3DXVECTOR3* GetMouseEps() const;

protected:
	void	AddZ(INT d);
};


#endif

