// Implementation of the CGLTexture class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <d3dx9math.h>

#include <gl/gl.h>
#include <gl/glu.h>

#include "../_pnglib/include/png.h"

#include "IGLImage.h"
#include "IGLTexture.h"
#include "GLTexture.h"


#define SAFE_DELETE_ARRAY(p)       { if(p) { delete [] (p);     (p)=NULL; } }


CGLTexture::CGLTexture()
{
	m_nTex	= 0;
	m_Fmt	= 0;
	m_Type	= 0;
	
	m_ImgW	= 0;
	m_ImgH	= 0;
}


CGLTexture::~CGLTexture()
{
	Destroy();
}

void CGLTexture::Destroy()
{
	if(0 == m_nTex)
		return;

	glDeleteTextures (1, &m_nTex);
	m_nTex = 0;
}


INT CGLTexture::Create(void* p1, void* p2, void* p3, void* p4)
{
	char*		sFile	= (char*)p1;
	void*		pMem	= p2;

	DWORD		colorKey= (DWORD)p3;
	DWORD		dFilter	= (DWORD)p4;
	IGLImage*	pImg	= NULL;


	BYTE*		pPxl	= NULL;


	if(sFile)
	{
		if(FAILED(LgDev_CreateImage(NULL, &pImg, sFile)))
			return -1;

		m_ImgW	= pImg->GetImgW();
		m_ImgH	= pImg->GetImgH();
		m_dKey	= colorKey;				// Color Key

		pPxl	= pImg->GetPixel();

		// Alpha channel�� �����.
		if(0x0 != m_dKey)
		{
			BYTE	color[4];
			memcpy(color, &m_dKey, sizeof(BYTE)*4);

			for(INT y=0; y<m_ImgH; ++y)
			{
				for(INT x=0; x<m_ImgW; ++x)
				{
					INT n1 = (y*m_ImgW + x)* 4;

					BYTE R = pPxl[n1+0];
					BYTE G = pPxl[n1+1];
					BYTE B = pPxl[n1+2];
					BYTE A = pPxl[n1+3];

					if( color[3] == A &&  color[2] == R &&  color[1] == G &&  color[0] == B)
						pPxl[n1+3] = 0x0;
				}
			}
		}

	}

	if(pMem)
	{
		m_ImgW	= (DWORD)p3;
		m_ImgH	= (DWORD)p4;
		pPxl	= (BYTE*)pMem;
	}

	m_Fmt	= GL_RGBA;
	m_Type	= GL_UNSIGNED_BYTE;

	

	glGenTextures (1,&m_nTex);
	glBindTexture (GL_TEXTURE_2D, m_nTex);

	glTexImage2D(GL_TEXTURE_2D, 0, m_Fmt, m_ImgW, m_ImgH, 0, m_Fmt, m_Type, pPxl);	// Load Pixel to Texture Name

	// ���Ͽ��� �Ӹ��� �䱸�Ǹ�
	if(dFilter && sFile)
		gluBuild2DMipmaps(GL_TEXTURE_2D, m_Fmt, m_ImgW, m_ImgH, m_Fmt, m_Type, pPxl);	// Mipmap Load

	glBindTexture (GL_TEXTURE_2D, 0);

	if(pImg)
		delete pImg;

	return 0;
}


void CGLTexture::SetTexture(INT modulate)
{
	if(0 == modulate)
	{
		glBindTexture (GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);
		return;
	}

	glEnable(GL_TEXTURE_2D);
	glBindTexture (GL_TEXTURE_2D, m_nTex);

	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

	glTexEnvi (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, modulate);
}


void CGLTexture::DrawPixel(RECT* rc					// Image rect
						, D3DXVECTOR2* vcScl		// Scaling
						, D3DXVECTOR2* vcRot		// Rotation Center
						, FLOAT fRot				// Angle(Radian)
						, D3DXVECTOR2* vcTrn		// Position
						, D3DXCOLOR dcolor			// color
						)
{
	FLOAT f[ 4]={0};


	D3DXVECTOR2	st0(0,0);	// �ؽ�ó ��ǥ �� �ϴ�
	D3DXVECTOR2	st1(1,1);	// �ؽ�ó ��ǥ �� ���

	FLOAT	PosL = 0;		// ��ġ Left
	FLOAT	PosT = 0;		// ��ġ Top
	FLOAT	PosR = 0;		// ��ġ Right
	FLOAT	PosB = 0;		// ��ġ Bottom

	FLOAT	ImgW = (FLOAT)this->GetImgW();
	FLOAT	ImgH = (FLOAT)this->GetImgH();
	INT		nTex = this->GetName();

	FLOAT	rcW= ImgW;
	FLOAT	rcH= ImgH;


	D3DXVECTOR2	vScl(1,1);
	D3DXVECTOR2	vRot(0,0);
	D3DXVECTOR2	vTrn(0,0);

	// ������ �̹��� ������ ���ؼ� UV�� ����Ѵ�.
	if(rc)
	{
		rcW= FLOAT(rc->right - rc->left);
		rcH= FLOAT(rc->bottom- rc->top);

		st0.x = rc->left/ImgW;				// �� �ϴ� S
		st0.y = 1.0f - rc->bottom/ImgH;		// �� �ϴ� T

		st1.x = rc->right /ImgW;			// �� ��� S
		st1.y = 1.0f - rc->top/ImgH;		// �� ��� T
	}

	if(vcScl)	vScl = *vcScl;
	if(vcRot)	vRot = *vcRot;
	if(vcTrn)	vTrn = *vcTrn;


	// ����Ʈ���� ȭ���� ũ�⸦ ��´�.
	glGetFloatv(GL_VIEWPORT, f);

	
	// ���� ��ȯ�� x, y�� ����� �Ѵ�.
	PosL =  2.0f * vTrn.x/f[2] - 1.0f;		// Left
	PosT = -2.0f * vTrn.y/f[3] + 1.0f;		// Top
	PosR = PosL + 2.0f * rcW * vScl.x/f[2];	// Right
	PosB = PosT - 2.0f * rcH * vScl.y/f[3];	// Bottom


	// ��ȯ ��� ����
	float	mtPrj[16]={0};
	float	mtViw[16]={0};
	glGetFloatv(GL_PROJECTION_MATRIX, (GLfloat*)mtPrj);
	glGetFloatv(GL_MODELVIEW_MATRIX, (GLfloat*)mtViw);

	// ��ȯ ��� ���� �ʱ�ȭ
	glMatrixMode(GL_PROJECTION);	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);		glLoadIdentity();

	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	// ���� �ؽ�Ʈ, ���� �׽�Ʈ, ����, �Ȱ� ��Ȱ��ȭ
	glDisable(GL_ALPHA_TEST);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDisable(GL_FOG);

	// Blending Ȱ��ȭ
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glEnable(GL_TEXTURE_2D);
	glBindTexture (GL_TEXTURE_2D, nTex);

	// Texture ȯ�� ����
	// Filtering:Nearst Address Mode: Clamp
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexEnvi (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);	// ���� * �ؽ�ó

	glBegin(GL_TRIANGLE_FAN);
		glColor4f(dcolor.r, dcolor.g, dcolor.b, dcolor.a);
		glTexCoord2f(st0.x, st0.y); glVertex3f(PosL, PosB, 0);
		glTexCoord2f(st1.x, st0.y); glVertex3f(PosR, PosB, 0);	
		glTexCoord2f(st1.x, st1.y); glVertex3f(PosR, PosT, 0);
		glTexCoord2f(st0.x, st1.y); glVertex3f(PosL, PosT, 0);
	glEnd();




	// ��ȯ ��� �ǵ��� ���´�.
	glMatrixMode(GL_PROJECTION);	glLoadMatrixf(mtPrj);
	glMatrixMode(GL_MODELVIEW);		glLoadMatrixf(mtViw);

	glColor4f(1,1,1,1);
	glBindTexture (GL_TEXTURE_2D, 0);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
}



INT LgDev_CreateTexture(char* sCmd
					, IGLTexture** pData
					, void* sFile
					, void* pMemoey
					, DWORD dcolor
					, DWORD dFilter)
{
	*pData = NULL;

	CGLTexture* pObj = new CGLTexture;

	if(FAILED(pObj->Create( sFile, pMemoey, (void*)dcolor, (void*)dFilter)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}