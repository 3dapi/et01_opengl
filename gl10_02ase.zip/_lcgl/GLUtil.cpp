// Implementation of the GLUtil Functions.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include <gl/gl.h>
#include <gl/glu.h>

#include <d3dx9math.h>

#include "GLUtil.h"


#define D3DFVF_XYZ			0x002
#define D3DFVF_DIFFUSE      0x040
#define D3DFVF_TEX1			0x100


void LcGL_SetStreamSource(DWORD dFVF, void* pVtx, INT dStride)
{
	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);


	if( dFVF&D3DFVF_XYZ )
		glEnableClientState(GL_VERTEX_ARRAY);

	if( dFVF&D3DFVF_DIFFUSE)
		glEnableClientState(GL_COLOR_ARRAY);

	if( dFVF&D3DFVF_TEX1)
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);


	// pVtx + sizeof(D3DXVECTOR3) ==> �̷��� �ϸ�
	// Pointer ��ġ�� pVtx += (VtxDUV) * sizeof(D3DXVECTOR3)�� ���� �ȴ�.
	// glColorPointer (4, GL_FLOAT, sizeof(VtxDUV), pVtx + sizeof(D3DXVECTOR3));

	char* p = (char*)pVtx;
	
	if( dFVF|D3DFVF_XYZ )
		glVertexPointer(3, GL_FLOAT, dStride, p);


	if( dFVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE) )
	{
		p += sizeof(D3DXVECTOR3);
		glColorPointer(4, GL_FLOAT, dStride, p);
	}

	else if( dFVF = (D3DFVF_XYZ|D3DFVF_TEX1) )
	{
		p += sizeof(D3DXVECTOR3);
		glTexCoordPointer(2, GL_FLOAT, dStride, p);
	}

	else if( dFVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1) )
	{
		p += sizeof(D3DXVECTOR3);
		glColorPointer(4, GL_FLOAT, dStride, p);

		p += sizeof(D3DXCOLOR);
		glTexCoordPointer(2, GL_FLOAT, dStride, p);
	}
}



void LcGL_DrawPrimitive(INT mode, INT first, INT nVtx)
{
	glDrawArrays(mode, first, nVtx);

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
}


void LcGL_DrawIndexedPrimitive(INT mode, INT nFace, const void *indices)
{
	glDrawElements(mode, nFace * 3, GL_UNSIGNED_SHORT, indices);

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
}

void LcGL_DrawIndexedPrimitiveUP(INT mode, INT nFace, const void *indices,	DWORD dFVF, const void* pVtx, INT dStride)
{
	if(!pVtx)
		return;

	if( D3DFVF_XYZ & dFVF)
		glEnableClientState(GL_VERTEX_ARRAY);

	if( D3DFVF_DIFFUSE & dFVF)
		glEnableClientState(GL_COLOR_ARRAY);

	if( D3DFVF_TEX1 & dFVF)
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);



	char* p = (char*)pVtx;

	if( D3DFVF_XYZ & dFVF)
		glVertexPointer(3, GL_FLOAT, dStride, p);


	if( (D3DFVF_XYZ|D3DFVF_DIFFUSE) == dFVF)
	{
		p += sizeof(D3DXVECTOR3);
		glColorPointer(4, GL_FLOAT, dStride, p);
	}

	else if( (D3DFVF_XYZ|D3DFVF_TEX1) == dFVF)
	{
		p += sizeof(D3DXVECTOR3);
		glTexCoordPointer(2, GL_FLOAT, dStride, p);
	}

	else if( (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1) == dFVF)
	{
		p += sizeof(D3DXVECTOR3);
		glColorPointer(4, GL_FLOAT, dStride, p);

		p += sizeof(D3DXCOLOR);
		glTexCoordPointer(2, GL_FLOAT, dStride, p);
	}

	glDrawElements(mode, nFace * 3, GL_UNSIGNED_SHORT, indices);

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
}

