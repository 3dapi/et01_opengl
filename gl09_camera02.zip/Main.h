// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef _Main_H_
#define _Main_H_


class CMain : public CApplicationGL
{
protected:
	IGLFont*	m_pLXFont;
	ILgxObj*	m_pGrid;
	ILcCam*		m_pCam;

	CMcScene*	m_pScene;

public:
	CMain();

protected:
	virtual	INT		Init();
	virtual	INT		Destroy();
	virtual	INT		FrameMove();
	virtual	INT		Render();
	virtual	LRESULT	MsgProc(HWND,UINT,WPARAM,LPARAM);
};


extern CMain*	g_pApp;
#define MAINAPP	g_pApp

#endif

