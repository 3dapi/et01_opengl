// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pLXFont	= NULL;
	m_pGrid		= NULL;
	m_pCam		= NULL;

	m_pScene	= NULL;
}


INT CMain::Init()
{
	INT hr =0;
	
	IGLFont::TFont	hFont(18, FW_BOLD, FALSE, 0, "Arial��ü");
	hr = LgDev_CreateFont(NULL, &m_pLXFont, &hFont);
	if(FAILED(hr))
		return -1;


	hr = LgxObj_Create("Grid", &m_pGrid);
	if(FAILED(hr))
		return -1;


	hr = LcEnt_CreateCamera(NULL, &m_pCam, m_ScnW, m_ScnH);
	if(FAILED(hr))
		return -1;


	m_pScene = new CMcScene;
	
	if(FAILED(m_pScene->Init()))
	{
		delete m_pScene;
		return -1;
	}

	return 0;
}

INT CMain::Destroy()
{
	SAFE_DELETE(	m_pLXFont	);
	SAFE_DELETE(	m_pGrid		);
	SAFE_DELETE(	m_pScene	);

	return 0;
}

INT CMain::FrameMove()
{
	FLOAT fCamMoveSpeed = 1.f;
	FLOAT fCamYaw		= -1.f;
	FLOAT fCamPitch		= -1.f;

	if(::GetAsyncKeyState('A') &0x8000)
		m_pCam->MoveSideward(-fCamMoveSpeed);

	if(::GetAsyncKeyState('D') &0x8000)
		m_pCam->MoveSideward(fCamMoveSpeed);


	if(::GetAsyncKeyState('W') &0x8000)
		m_pCam->MoveForward(fCamMoveSpeed);

	if(::GetAsyncKeyState('S') &0x8000)
		m_pCam->MoveForward(-fCamMoveSpeed);


	if(::GetAsyncKeyState(VK_LEFT) &0x8000)
		m_pCam->Rotation(fCamYaw, 0, fCamMoveSpeed*0.1f);
	if(::GetAsyncKeyState(VK_RIGHT) &0x8000)
		m_pCam->Rotation(-fCamYaw, 0, fCamMoveSpeed*0.1f);


	if(::GetAsyncKeyState(VK_DOWN) &0x8000)
		m_pCam->Rotation(0, fCamPitch, fCamMoveSpeed*0.1f);
	if(::GetAsyncKeyState(VK_UP) &0x8000)
		m_pCam->Rotation(0, -fCamPitch, fCamMoveSpeed*0.1f);


	SAFE_FRMOV(	m_pCam		);
	SAFE_FRMOV(	m_pGrid		);
	SAFE_FRMOV(	m_pScene	);

	return 0;
}

INT CMain::Render()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT |GL_STENCIL_BUFFER_BIT);

	glShadeModel(GL_SMOOTH);
	glEnable(GL_CULL_FACE);
	glFrontFace(GL_CCW);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);


	m_pCam->TransformProj();
	m_pCam->TransformView();


	m_pGrid->Render();
	m_pScene->Render();

	char	sMsg[128]={0};
	const D3DXVECTOR3* vcCamEye = m_pCam->GetEye();
	const D3DXVECTOR3* vcCamLook= m_pCam->GetLook();
	sprintf(sMsg, "Camera Pos: %4.f %4.f %4.f", vcCamEye->x, vcCamEye->y, vcCamEye->z);
	m_pLXFont->SetString(sMsg);
	m_pLXFont->DrawTxt(NULL, NULL, 0, &D3DXVECTOR2(5, 5), D3DXCOLOR(1, 0.f, 1.f,1));

	sprintf(sMsg, "Camera LooAt: %4.f %4.f %4.f", vcCamLook->x, vcCamLook->y, vcCamLook->z);
	m_pLXFont->SetString(sMsg);
	m_pLXFont->DrawTxt(NULL, NULL, 0, &D3DXVECTOR2(5, 25), D3DXCOLOR(1, 0.f, 1.f,1));

	

	glFlush();
	return 0;
}

LRESULT	CMain::MsgProc(HWND hWnd,UINT uMsg,WPARAM wParam, LPARAM lParam)
{
	if(WM_KEYDOWN == uMsg)
	{
		if(VK_ESCAPE == wParam)
		{
			SendMessage(hWnd, WM_DESTROY, 0, 0);
			return 0;
		}
	}

	return CApplicationGL::MsgProc(hWnd, uMsg, wParam, lParam);
}
