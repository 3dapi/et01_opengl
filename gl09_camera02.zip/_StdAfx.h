//
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef __StdAfx_H_
#define __StdAfx_H_


#pragma warning(disable: 4996)
#pragma warning(disable: 4018)

#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "OpenGL32.Lib")
#pragma comment(lib, "Glu32.lib")
#pragma comment(lib, "GlAux.Lib")
#pragma comment(lib, "./_gl/Glut32.Lib")

#pragma comment(lib, "d3dx9.lib")


#ifdef NDEBUG
#pragma comment(lib, "./_pnglib/lib/zlib123.lib")
#pragma comment(lib, "./_pnglib/lib/png124.lib")
#else
#pragma comment(lib, "./_pnglib/lib/zlib123_.lib")
#pragma comment(lib, "./_pnglib/lib/png124_.lib")
#endif


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <d3dx9.h>

#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/GLAux.h>
#include "./_gl/glut.h"
#include "./_lcgl/IGLImage.h"
#include "./_lcgl/IGLTexture.h"
#include "./_lcgl/IGLSprite.h"
#include "./_lcgl/IGLFont.h"
#include "./_lcgl/GLUtil.h"

#include "./_lgx/ILgxObj.h"
#include "./_lgx/ILcCam.h"



#include "AppGL.h"
#include "McScene.h"



#include "Main.h"

#endif


