// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
}


CMcScene::~CMcScene()
{
	Destroy();
}

void CMcScene::Destroy()
{
}

INT CMcScene::Init()
{
	INT	hr=0;

	return 0;
}

INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
}


