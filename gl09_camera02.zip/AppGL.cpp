// Implementation of the CApplicationGL class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning(disable: 4996)


#include <windows.h>
#include <commctrl.h>
#include <d3dxmath.h>

#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/GLAux.h>
#include "_gl/glext.h"
#include "_gl/wglext.h"

#include "AppGL.h"
#include "resource.h"


CApplicationGL* CApplicationGL::m_pAppGL = NULL;
	
CApplicationGL::CApplicationGL()
{
	CApplicationGL::m_pAppGL	 = this;

	m_hInst		= NULL;
	m_hWnd		= NULL;
	m_hAccl		= NULL;

	m_ScnX		= 0;
	m_ScnY		= 0;

	m_ScnW		= 640;
	m_ScnH		= 480;
	m_ScnD		= 24;
	m_ScnS		=  8;
	m_ScnC		= 32;
	m_ScnA		=  8;
	m_ScnM		= 16;	// 16 Sampling

	m_dWinStyle	= WS_OVERLAPPED| WS_CAPTION|WS_SYSMENU|WS_VISIBLE;
	m_dWinAccl	= IDR_ACCELERATOR;
	m_dWinMode	= IDA_CHANGE_WINDOW;
	m_dWinExit	= IDA_EXIT;
	m_bWindow	= TRUE;
	m_bActive	= TRUE;

	
	memset(m_sCls, 0, sizeof(m_sCls));
	strcpy(m_sCls, "LxAppGL");

	m_hDC		= NULL;
	m_hRC		= NULL;
	m_bChkMulti = 0;

	m_fElapsed	= 0;
	m_fFPS		= 60;

	m_dClear	= D3DXCOLOR(0.9f, 1.0f, 1.0f, 1.0f);
	m_dClear	= D3DXCOLOR(1,1,1,1);
}


INT CApplicationGL::Create(HINSTANCE)
{
	InitCommonControls();

	m_hInst = (HINSTANCE)::GetModuleHandle(NULL);

	WNDCLASS wc =
	{
		CS_CLASSDC
			, WndProc
			, 0
			, 0
			, m_hInst
			, LoadIcon(NULL, IDI_APPLICATION)
			, LoadCursor(NULL,IDC_ARROW)
			, (HBRUSH)GetStockObject(WHITE_BRUSH)
			, NULL
			, m_sCls
	};

	if( 0==	::RegisterClass(&wc))
		return -1;

	if(FAILED(WindowCreate()))
		return -1;

	if(FAILED(Init3DEnvironment()))
		return -1;

	return 0;
}


INT CApplicationGL::Run()
{
	BOOL	bMsg=0;
	MSG		msg={0};
	m_hAccl = LoadAccelerators( m_hInst, MAKEINTRESOURCE(m_dWinAccl) );

	while(1)
	{
		if(m_bActive)
			bMsg = PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE);
		else
			bMsg = GetMessage(&msg, NULL, NULL, 0);
		
		
		if(bMsg)
		{
			if(WM_QUIT == msg.message)
				break;

			if(m_hWnd)
				TranslateAccelerator( m_hWnd, m_hAccl, &msg );

			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}

		if (m_bActive)
			Render3DEnvironment();
	}


	if( m_hAccl)
		DestroyAcceleratorTable( m_hAccl );

	Cleanup3DEnvironment();

	return 0;
}


LRESULT CALLBACK CApplicationGL::WndProc(HWND hWnd,UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(CApplicationGL::m_pAppGL)
		return CApplicationGL::m_pAppGL->MsgProc(hWnd, uMsg, wParam, lParam);

	return ::DefWindowProc(hWnd, uMsg, wParam, lParam);
}


LRESULT CApplicationGL::MsgProc(HWND hWnd,UINT uMsg,WPARAM wParam, LPARAM lParam)
{
	if(WM_CREATE == uMsg)
			return 0;

	else if(WM_ACTIVATE == uMsg)
	{
		if (LOWORD(wParam) == WA_INACTIVE)
			m_bActive = FALSE;
		else
			m_bActive = TRUE;

		if(!m_bActive)
		{
			if(!m_bWindow)
				WindowChange();
			
			SendMessage(m_hWnd, WM_SYSCOMMAND, SC_MINIMIZE, 0);
		}

		return 0;
	}

	else if(WM_SIZE == uMsg)
	{
		WindowResize(LOWORD(lParam), HIWORD(lParam));
		return 0;
	}

	else if(WM_COMMAND == uMsg)
	{
		if( m_dWinMode && m_dWinMode == LOWORD(wParam) )
		{
			WindowChange();
			return 0;
		}
			
		else if( m_dWinExit && m_dWinExit == LOWORD(wParam) )
		{
			PostMessage( hWnd, WM_CLOSE, 0, 0 );
			return 0;
		}
		
		return 0;
	}

	else if(WM_CLOSE == uMsg || WM_DESTROY == uMsg)
	{
		if(m_hWnd)
		{
			if(!m_bChkMulti)
			{
				HMENU hMenu;
				hMenu = GetMenu(hWnd);
				
				if( hMenu != NULL )
					DestroyMenu( hMenu );
			
				PostQuitMessage(0);
			}

			m_hWnd = NULL;
		}

		return 0;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}




INT CApplicationGL::Init3DEnvironment()
{
	memset(&m_DevFull,0,sizeof(m_DevFull));
	m_DevFull.dmSize       = sizeof(m_DevFull);	

	EnumDisplaySettings(NULL, ENUM_CURRENT_SETTINGS, &m_DevWin);

	m_DevFull.dmPelsWidth  = m_ScnW;
	m_DevFull.dmPelsHeight = m_ScnH;
//	m_DevFull.dmBitsPerPel = m_ScnC;
	m_DevFull.dmDisplayFrequency = m_DevWin.dmDisplayFrequency;
	m_DevFull.dmFields     = DM_DISPLAYFREQUENCY | DM_PELSWIDTH | DM_PELSHEIGHT;

	m_DevWin.dmDisplayFrequency	= 0;


	if(FAILED(GLCreate()))
		return -1;

	::ShowWindow( m_hWnd, SW_SHOWNORMAL );
	WindowResize(m_ScnW, m_ScnH);
	
	::SetForegroundWindow(m_hWnd);
	::SetFocus(m_hWnd);
	::UpdateWindow( m_hWnd );
	::ShowCursor(TRUE);

	GLVSync(1);

	glClearColor(m_dClear.r, m_dClear.g, m_dClear.b, m_dClear.a);

	
	if(FAILED(Init()))
		return -1;

	return 0;
}


INT CApplicationGL::Cleanup3DEnvironment()
{
	if(FALSE == m_bWindow)
	{
		ChangeDisplaySettings(NULL, 0);
		ShowCursor(TRUE);
		m_bWindow = TRUE;
	}


	Destroy();
	GLDestroy();

	UnregisterClass(m_sCls, m_hInst);

	return 0;
}

INT CApplicationGL::Render3DEnvironment()
{
	INT hr =0;

	if(!m_hWnd)
		return 0;
	
	hr  = FrameMove();

	if(FAILED(hr))
	{
		SendMessage(m_hWnd, WM_DESTROY, 0, 0);
		return 0;
	}

	hr = Render();

	if(FAILED(hr))
	{
		SendMessage(m_hWnd, WM_DESTROY, 0, 0);
		return 0;
	}

	hr = SwapBuffers(m_hDC);

	if(FALSE ==hr)
	{
		SendMessage(m_hWnd, WM_DESTROY, 0, 0);
		return 0;
	}


	UpdateFPS();

	return hr;
}



void CApplicationGL::UpdateFPS()
{
	static DOUBLE	dTimeTck= 0;
	static DOUBLE	dTimeBgn= 0;
	static DOUBLE	dTimeBfr= 0;
	static DOUBLE	dTimeCur= 0;
	static INT		bHards	= -1;
	static INT		nCount	= -1;


	++nCount;

	// ���� �Լ� ȣ���
	if(-1 == bHards)
	{
		LARGE_INTEGER	Tick={0};
		bHards = QueryPerformanceFrequency((LARGE_INTEGER*)&Tick);
//		bHards	= 0;

		// �ϵ���� ������ �ȵ� �ܿ�
		if(0 == bHards)
		{
			dTimeBgn	= timeGetTime();
			dTimeTck	= 1000.;
		}
		else
		{
			LARGE_INTEGER	dBgn={0};
			QueryPerformanceCounter((LARGE_INTEGER*)&dBgn);
			dTimeTck	= DOUBLE(Tick.QuadPart);
			dTimeBgn	= DOUBLE(dBgn.QuadPart);
		}

		return;
	}

	// �ϵ���� ������ �ȵǴ� ��� timeGetTime�� �̿�
	if(0 == bHards)
	{
		dTimeCur = timeGetTime();
	}
	else
	{
		LARGE_INTEGER	dCur={0};
		QueryPerformanceCounter((LARGE_INTEGER*)&dCur);
		dTimeCur	= DOUBLE(dCur.QuadPart);
	}


	m_fElapsed	= (dTimeCur - dTimeBfr)/dTimeTck;
	dTimeBfr	= dTimeCur;


	// 24Frame�� ����
	if(24<nCount)
	{
		DOUBLE fElapsed	= (dTimeCur - dTimeBgn)/dTimeTck;
		m_fFPS	= FLOAT(nCount/fElapsed);
		dTimeBgn = dTimeCur;
		nCount = 0;
	}
}



INT	CApplicationGL::WindowCreate()
{
	RECT rc;
	
	::SetRect( &rc, 0, 0, m_ScnW, m_ScnH);
	::AdjustWindowRect( &rc, m_dWinStyle, FALSE );

	INT iScnSysW = ::GetSystemMetrics(SM_CXSCREEN);
	INT iScnSysH = ::GetSystemMetrics(SM_CYSCREEN);
	m_ScnX	= (iScnSysW - (rc.right-rc.left))/2;
	m_ScnY	= (iScnSysH - (rc.bottom-rc.top))/2;

	m_hWnd = ::CreateWindow( m_sCls
					, m_sCls
					, m_dWinStyle
					, m_ScnX
					, m_ScnY
					, (rc.right-rc.left)
					, (rc.bottom-rc.top)
					, GetDesktopWindow()
					, NULL
					, m_hInst
					, NULL );

	if(!m_hWnd)
		return -1;

	GetWindowRect( m_hWnd, &m_rcWin );
	
	return 0;
}



void CApplicationGL::WindowResize(INT width, INT height)
{
	if (height==0)
		height=1;
	
	glViewport(0, 0, width, height);	// set the viewport to the new dimensions
}



INT CApplicationGL::WindowChange()
{
	if(m_bWindow)
	{
		m_bWindow = FALSE;
		if ( DISP_CHANGE_SUCCESSFUL == ChangeDisplaySettings(&m_DevFull, CDS_FULLSCREEN) )
		{
			SetWindowLong( m_hWnd, GWL_STYLE, WS_POPUP|WS_VISIBLE );
			SetWindowPos(m_hWnd, HWND_TOP, 0, 0, m_ScnW, m_ScnH, SWP_SHOWWINDOW);
		}
		else
			return -1;
	}
	else
	{
		m_bWindow = TRUE;
		if ( DISP_CHANGE_SUCCESSFUL == ChangeDisplaySettings(&m_DevWin, 0) )
		{
			SetWindowLong(m_hWnd, GWL_STYLE, m_dWinStyle);
			SetWindowPos(m_hWnd, HWND_TOP, m_ScnX, m_ScnY, m_rcWin.right - m_rcWin.left, m_rcWin.bottom	- m_rcWin.top, SWP_SHOWWINDOW);
		}
		else
			return -1;
	}

	
	
	return 0;
}



INT CApplicationGL::GLCreate()
{
	m_hDC = GetDC(m_hWnd);

	PIXELFORMATDESCRIPTOR pfd = {0};
	pfd.nSize		= sizeof(PIXELFORMATDESCRIPTOR);
	pfd.nVersion	= 1;
	pfd.dwFlags		= PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL |PFD_DOUBLEBUFFER;	//|PFD_GENERIC_ACCELERATED;
	pfd.iPixelType	= PFD_TYPE_RGBA;
	pfd.cColorBits	= m_ScnC;
	pfd.cDepthBits	= m_ScnD;
	pfd.cStencilBits= m_ScnS;
	pfd.iLayerType	= PFD_MAIN_PLANE;


	UINT PixelFormat = ChoosePixelFormat(m_hDC, &pfd);

	if(0 == PixelFormat)
		return -1;

	if(0 == SetPixelFormat(m_hDC, PixelFormat,&pfd))
		return -1;


	m_hRC = wglCreateContext(m_hDC);
	if(NULL == m_hRC)
		return -1;


	if(0 == wglMakeCurrent(m_hDC, m_hRC))
		return -1;


	PixelFormat = GLMultisample(m_hWnd);
	if(SUCCEEDED(PixelFormat))
	{
		m_bChkMulti = 1;
		wglMakeCurrent(NULL,NULL);
		wglDeleteContext(m_hRC);
		ReleaseDC(m_hWnd, m_hDC);
		DestroyWindow(m_hWnd);

		m_bChkMulti = 0;

		if(FAILED(WindowCreate()))
			return -1;

		
		if(0 == SetPixelFormat(m_hDC, PixelFormat,&pfd))
			return -1;

		m_hRC = wglCreateContext(m_hDC);
		if(NULL == m_hRC)
			return -1;
		
		if(0 ==wglMakeCurrent(m_hDC, m_hRC))
			return -1;

		// Enable Our Multisampling
		glEnable(GL_MULTISAMPLE_ARB);
	}


	return 0;
}


INT CApplicationGL::GLDestroy()
{
	if(m_hDC)
	{
		wglMakeCurrent(m_hDC, NULL);
		wglDeleteContext(m_hRC);

		ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}

	return 0;
}


void CApplicationGL::GLVSync(BOOL bVsynOff)
{
	//get extensions of graphics card
	char* extensions = (char*)glGetString(GL_EXTENSIONS);
	
	//is WGL_EXT_swap_control in the string? VSync switch possible?
	if (strstr(extensions,"WGL_EXT_swap_control"))
	{
		//function pointer typdefs
		typedef void (APIENTRY *PFNWGLEXTSWAPCONTROLPROC)(INT);
		typedef INT (*PFNWGLEXTGETSWAPINTERVALPROC)(void);
		
		//declare functions
		PFNWGLEXTSWAPCONTROLPROC wglSwapIntervalEXT = NULL;
		PFNWGLEXTGETSWAPINTERVALPROC wglGetSwapIntervalEXT = NULL;
		
		//get address's of both functions and save them
		wglSwapIntervalEXT	= (PFNWGLEXTSWAPCONTROLPROC)	wglGetProcAddress("wglSwapIntervalEXT");
		wglGetSwapIntervalEXT= (PFNWGLEXTGETSWAPINTERVALPROC)wglGetProcAddress("wglGetSwapIntervalEXT");
	
		if(wglGetSwapIntervalEXT())
		{
			if(bVsynOff)
				wglSwapIntervalEXT(0);
			else
				wglSwapIntervalEXT(1);
		}
		
	}
}




#define WGL_SAMPLE_BUFFERS_ARB		 0x2041
#define WGL_SAMPLES_ARB			     0x2042


INT WGLisExtensionSupported(const char *extension);


INT CApplicationGL::GLMultisample(HWND hWnd)
{  
	 // See If The String Exists In WGL!
	if(FAILED(WGLisExtensionSupported("WGL_ARB_multisample")))
		return -1;

	// Get Our Pixel Format
	PFNWGLCHOOSEPIXELFORMATARBPROC wglChoosePixelFormatARB =
		(PFNWGLCHOOSEPIXELFORMATARBPROC)wglGetProcAddress("wglChoosePixelFormatARB");

	if (!wglChoosePixelFormatARB) 
		return -1;



	HDC hDC = GetDC(hWnd);

	// Get Our Current Device Context
	INT		pixelFormat=-1;
	INT		valid;
	UINT	numFormats;
	float	fAttributes[] = {0,0};

	INT iAttributes[] =
	{
		WGL_DRAW_TO_WINDOW_ARB,		GL_TRUE,
		WGL_SUPPORT_OPENGL_ARB,		GL_TRUE,
		WGL_ACCELERATION_ARB,		WGL_FULL_ACCELERATION_ARB,
		WGL_COLOR_BITS_ARB,			m_ScnC,
		WGL_ALPHA_BITS_ARB,			m_ScnA,
		WGL_DEPTH_BITS_ARB,			m_ScnD,
		WGL_STENCIL_BITS_ARB,		m_ScnS,

		WGL_DOUBLE_BUFFER_ARB,		GL_TRUE,
		WGL_SAMPLE_BUFFERS_ARB,		GL_TRUE,

		WGL_SAMPLES_ARB,			m_ScnM,	// m_ScnM is m_ScnM - sampling
		0,0
	};


	// sampling�� 16 �ƴϸ� 4... 8�� 4�� ���� ���

	for(INT smp=16; smp>0; smp -=2)
	{
		iAttributes[19] = smp;
		valid = wglChoosePixelFormatARB(hDC,iAttributes,fAttributes,1,&pixelFormat,&numFormats);
		if (valid && numFormats >= 1)
		{
			break;
		}
	}
	  
	ReleaseDC(hWnd, hDC);
	return pixelFormat;
}



INT WGLisExtensionSupported(const char *extension)
{
	const size_t extlen = strlen(extension);
	const char *supported = NULL;

	// Try To Use wglGetExtensionStringARB On Current DC, If Possible
	PROC wglGetExtString = wglGetProcAddress("wglGetExtensionsStringARB");

	if (wglGetExtString)
		supported = ((char*(__stdcall*)(HDC))wglGetExtString)(wglGetCurrentDC());

	// If That Failed, Try Standard Opengl Extensions String
	if (supported == NULL)
		supported = (char*)glGetString(GL_EXTENSIONS);

	// If That Failed Too, Must Be No Extensions Supported
	if (supported == NULL)
		return -1;

	// Begin Examination At Start Of String, Increment By 1 On False Match
	for (const char* p = supported; ; p++)
	{
		// Advance p Up To The Next Possible Match
		p = strstr(p, extension);

		if (p == NULL)
			return -1;															// No Match

		// Make Sure That Match Is At The Start Of The String Or That
		// The Previous Char Is A Space, Or Else We Could Accidentally
		// Match "wglFunkywglExtension" With "wglExtension"

		// Also, Make Sure That The Following Character Is Space Or NULL
		// Or Else "wglExtensionTwo" Might Match "wglExtension"
		if ((p==supported || p[-1]==' ') && (p[extlen]=='\0' || p[extlen]==' '))
			return 0;															// Match
	}


	return -1;
}