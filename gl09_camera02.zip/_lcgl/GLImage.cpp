// Implementation of the CGLImage class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning(disable: 4996)


#include <windows.h>
#include <stdio.h>

#include <d3dx9math.h>

#include <gl/gl.h>

#include "../_pnglib/include/png.h"

#include "IGLImage.h"
#include "GLImage.h"


#define SAFE_DELETE_ARRAY(p) { if(p) { delete [] (p); (p)=NULL; } }


CGLImage::CGLImage()
{
	m_Type	= 0;
	m_ImgW	= 0;
	m_ImgH	= 0;
	m_ImgD	= 0;
	m_pPxl	= NULL;
}


CGLImage::~CGLImage()
{
	Destroy();
}


void CGLImage::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pPxl	);
}


INT CGLImage::Create(char *sFile)
{
	m_Type = IMG_UNKNOWN;

	char Ext[MAX_PATH];

	char* p  = strrchr(sFile, '.');

	if(p)
		strcpy(Ext, p+1);

	if(0==_stricmp(Ext, "bmp"))
		m_Type =IMG_BMP;
	else if(0==_stricmp(Ext, "tga"))
		m_Type =IMG_TGA;

	else if(0==_stricmp(Ext, "png"))
		m_Type =IMG_PNG;
	else
		return -1;

	switch(m_Type)
	{
	case IMG_BMP:
		return LoadBitmapFile(sFile);
	case IMG_TGA:
		return LoadTGAFile(sFile);
	case IMG_PNG:
		return LoadPngFile(sFile);
	}
	
	return -1;
}


INT CGLImage::LoadBitmapFile(char* sFile)
{
	FILE*	fp;
	long	lSize;
	INT		nImgB;				// Bit Count
	BYTE*	pData = NULL;
	BYTE*	pPxlT = NULL;

	fp= fopen(sFile, "rb");

	if(NULL == fp)
		return -1;

	fseek(fp, 0, SEEK_END);
	lSize = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	if(lSize<10)
	{
		fclose(fp);
		return -1;
	}

	pData = new BYTE[lSize];

	fread(pData, sizeof(BYTE), lSize, fp);
	fclose(fp);

	BITMAPFILEHEADER*	fh		= (BITMAPFILEHEADER *)pData;
	BITMAPINFOHEADER*	ih		= (BITMAPINFOHEADER *)(pData + sizeof(BITMAPFILEHEADER));
	
	pPxlT	= pData + fh->bfOffBits;
	nImgB	= ih->biBitCount>>3;

	m_ImgW	= ih->biWidth;
	m_ImgH	= ih->biHeight;
	m_pPxl	= new BYTE[m_ImgW * m_ImgH * 4];// 4byte�� �����.

	// BGR Mode
	if(3 == nImgB)
	{
//		m_Fmt = GL_RGB;

		for(INT y=0; y<m_ImgH; ++y)
		{
			for(INT x=0; x<m_ImgW; ++x)
			{
				INT n1 = (y*m_ImgW + x)* 3;
				INT n2 = (y*m_ImgW + x)* 4;
				
				INT B = pPxlT[n1+0];
				INT G = pPxlT[n1+1];
				INT R = pPxlT[n1+2];

				m_pPxl[n2+0] = R;
				m_pPxl[n2+1] = G;
				m_pPxl[n2+2] = B;
				m_pPxl[n2+3] = 0xFF;
			}
		}
	}

	// BGRA Mode
	else if(4 == nImgB)
	{
//		m_Fmt = GL_RGBA;

		for(INT y=0; y<m_ImgH; ++y)
		{
			for(INT x=0; x<m_ImgW; ++x)
			{
				INT n1 = (y*m_ImgW + x)* 4;
				INT n2 = (y*m_ImgW + x)* 4;
				
				INT B = pPxlT[n1+0];
				INT G = pPxlT[n1+1];
				INT R = pPxlT[n1+2];
				INT A = pPxlT[n1+3];

				m_pPxl[n2+0] = R;
				m_pPxl[n2+1] = G;
				m_pPxl[n2+2] = B;
				m_pPxl[n2+3] = A;
			}
		}
	}

	delete [] pData;

	return 0;
}



INT CGLImage::LoadTGAFile(char *sFile)
{
	FILE*		fp;
	BYTE		charBad;					// garbage data
	SHORT		sintBad;					// garbage data
	long		imageSize;					// size of TGA image

	TGAHEADER	Tga;

	INT			nImgB;
	BYTE*		pPxlT = NULL;
		
	// open the TGA file
	fp = fopen(sFile, "rb");

	if (!fp)
		return NULL;
	
	// read first two bytes of garbage
	fread(&charBad, sizeof(BYTE), 1, fp);
	fread(&charBad, sizeof(BYTE), 1, fp);

	// read in the image type
	fread(&Tga.ImgT, sizeof(Tga.ImgT), 1, fp);

	// for our purposes, the image type should be either a 2 or a 3
	if ((Tga.ImgT != 2) && (Tga.ImgT != 3))
	{
		fclose(fp);
		return NULL;
	}

	// read 13 bytes of garbage data
	fread(&sintBad, sizeof(SHORT), 1, fp);
	fread(&sintBad, sizeof(SHORT), 1, fp);
	fread(&charBad, sizeof(BYTE ), 1, fp);
	fread(&sintBad, sizeof(SHORT), 1, fp);
	fread(&sintBad, sizeof(SHORT), 1, fp);

	// read image dimensions
	fread(&Tga.ImgW, sizeof(SHORT), 1, fp);
	fread(&Tga.ImgH, sizeof(SHORT), 1, fp);

	// read bit depth
	fread(&Tga.ImgB, sizeof(BYTE), 1, fp);

	// read garbage
	fread(&charBad, sizeof(BYTE), 1, fp);


	// colormode -> 3 = BGR, 4 = BGRA
	nImgB		= Tga.ImgB>>3;
	imageSize	= Tga.ImgW * Tga.ImgH * nImgB;
	pPxlT		= new BYTE[imageSize];

	fread(pPxlT, sizeof(BYTE), imageSize, fp);
	fclose(fp);

	m_ImgW	= Tga.ImgW;
	m_ImgH	= Tga.ImgH;
	m_ImgD	= 4;

	m_pPxl	= new BYTE[Tga.ImgW * Tga.ImgH* 4];

	// BGR
	if(3 == nImgB)
	{
		for(INT y=0; y<m_ImgH; ++y)
		{
			for(INT x=0; x<m_ImgW; ++x)
			{
				INT n1 = (y*m_ImgW + x)* 3;
				INT n2 = (y*m_ImgW + x)* 4;
				
				BYTE B = pPxlT[n1+0];
				BYTE G = pPxlT[n1+1];
				BYTE R = pPxlT[n1+2];

				m_pPxl[n2+0] = R;
				m_pPxl[n2+1] = G;
				m_pPxl[n2+2] = B;
				m_pPxl[n2+3] = 0xFF;
			}
		}
	}

	// BGRA
	else if(4 == nImgB)
	{
		for(INT y=0; y<m_ImgH; ++y)
		{
			for(INT x=0; x<m_ImgW; ++x)
			{
				INT n1 = (y*m_ImgW + x)* 4;
				INT n2 = (y*m_ImgW + x)* 4;
				
				BYTE B = pPxlT[n1+0];
				BYTE G = pPxlT[n1+1];
				BYTE R = pPxlT[n1+2];
				BYTE A = pPxlT[n1+3];

				m_pPxl[n2+0] = R;
				m_pPxl[n2+1] = G;
				m_pPxl[n2+2] = B;
				m_pPxl[n2+3] = A;
			}
		}
	}

	delete [] pPxlT;

	return 0;
}



INT CGLImage::LoadPngFile(char* sFile)
{
	PNG_PIXEL	PngPxl;

	if(FAILED(LoadPngFile(&PngPxl, sFile)))
		return -1;

	INT		ImgW	= PngPxl.nWidth;
	INT		ImgH	= PngPxl.nHeight;
	INT		ImgD	= 4;
	BYTE*	pSrc	= PngPxl.pPixel;
	BYTE*	pDst	= NULL;

	pDst = new BYTE[ImgW * ImgH * ImgD];

	// for 32 or 24 bit
	// R,G, B to B, G, R
	// PNG Order: r, g, b, a
	// Window, B, G, R
	// BGR
	if(3 == PngPxl.nChannel)
	{
		for(INT y=0; y<ImgH; ++y)
		{
			for(INT x=0; x<ImgW; ++x)
			{
				INT n1 = (y*ImgW + x)* 3;
				INT n2 = (y*ImgW + x)* 4;
				
				BYTE B = pSrc[n1+0];
				BYTE G = pSrc[n1+1];
				BYTE R = pSrc[n1+2];

				pDst[n2+0] = B;
				pDst[n2+1] = G;
				pDst[n2+2] = R;
				pDst[n2+3] = 0xFF;
			}
		}
	}

	// BGRA
	else if(4 == PngPxl.nChannel)
	{
		memcpy(pDst, pSrc, sizeof(BYTE)* ImgW * ImgH * ImgD);
//		for(INT y=0; y<ImgH; ++y)
//		{
//			for(INT x=0; x<ImgW; ++x)
//			{
//				INT n1 = (y*ImgW + x)* 4;
//				INT n2 = (y*ImgW + x)* 4;
//				
//				BYTE B = pSrc[n1+0];
//				BYTE G = pSrc[n1+1];
//				BYTE R = pSrc[n1+2];
//				BYTE A = pSrc[n1+3];
//
//				pDst[n2+0] = B;
//				pDst[n2+1] = G;
//				pDst[n2+2] = R;
//				pDst[n2+3] = A;
//			}
//		}
	}


	// PNG�� ���Ʒ��� �����Ѵ�.
	DWORD*	pT	= (DWORD*)pDst;
	for(INT y=0; y<ImgH/2; ++y)
	{
		for(INT x=0; x<ImgW; ++x)
		{
			INT n1 = ImgW * y + x;
			INT n2 = ImgW * (ImgH-y-1) + x;
			
			DWORD S = pT[n1];

			pT[n1] ^= pT[n2];
			pT[n2] ^= pT[n1];
			pT[n1] ^= pT[n2];
		}
	}

	delete [] PngPxl.pPixel;

	this->m_ImgW = ImgW;
	this->m_ImgH = ImgH;
	this->m_ImgD = ImgD;
	this->m_pPxl = pDst;

	return 0;
}



INT CGLImage::LoadPngFile(PNG_PIXEL* pPngOut, char* sFile)
{
	FILE*			fp;
	png_byte        pbSig[8];
	int             iBitDepth;
	int             iColorType;
	double          dGamma;
	png_color_16*	pBackground;
	png_uint_32		ulChannels;
	png_uint_32		ulRowBytes;
	png_byte*		pPixel		= NULL;
	png_byte**		ppbRowPointers = NULL;

	png_structp		png_ptr = NULL;
	png_infop		info_ptr = NULL;

	int i = 0;

	fp = fopen(sFile, "rb");

	if (NULL == fp)
		return -1;


	// first check the eight byte PNG signature
	fread(pbSig, 1, 8, fp);

	if (!png_check_sig(pbSig, 8))
		goto LOAD_IMAGE_ERROR;

	// create the two png(-info) structures
	png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, (png_error_ptr)NULL, (png_error_ptr)NULL);

	if (!png_ptr)
		goto LOAD_IMAGE_ERROR;


	info_ptr = png_create_info_struct(png_ptr);

	if (!info_ptr)
		goto LOAD_IMAGE_ERROR;


	// initialize the png structure
	png_set_read_fn(png_ptr, (png_voidp)fp, NULL);



	png_set_sig_bytes(png_ptr, 8);


	// read all PNG info up to image data
	png_read_info(png_ptr, info_ptr);

	// get width, height, bit-depth and color-type
	png_get_IHDR(png_ptr
		, info_ptr
		, (png_uint_32 *)&pPngOut->nWidth
		, (png_uint_32 *)&pPngOut->nHeight
		, &iBitDepth
		, &iColorType
		, NULL, NULL, NULL);

	// expand images of all color-type and bit-depth to 3x8 bit RGB images
	// let the library process things like alpha, transparency, background

	if (iBitDepth == 16)
		png_set_strip_16(png_ptr);
	
	if (iColorType == PNG_COLOR_TYPE_PALETTE)
		png_set_expand(png_ptr);
	
	if (iBitDepth < 8)
		png_set_expand(png_ptr);
	
	if (png_get_valid(png_ptr, info_ptr, PNG_INFO_tRNS))
		png_set_expand(png_ptr);

	if (iColorType == PNG_COLOR_TYPE_GRAY ||
		iColorType == PNG_COLOR_TYPE_GRAY_ALPHA)
		png_set_gray_to_rgb(png_ptr);

	// set the background color to draw transparent and alpha images over.
	if (png_get_bKGD(png_ptr, info_ptr, &pBackground))
	{
		png_set_background(png_ptr, pBackground, PNG_BACKGROUND_GAMMA_FILE, 1, 1.0);
		pPngOut->BgColorR	= (byte) pBackground->red;
		pPngOut->BgColorG	= (byte) pBackground->green;
		pPngOut->BgColorB	= (byte) pBackground->blue;
	}

	// if required set gamma conversion
	if (png_get_gAMA(png_ptr, info_ptr, &dGamma))
		png_set_gamma(png_ptr, (double) 2.2, dGamma);

	// after the transformations have been registered update info_ptr data
	png_read_update_info(png_ptr, info_ptr);

	// get again width, height and the new bit-depth and color-type
	png_get_IHDR(png_ptr
		, info_ptr
		, (png_uint_32 *)&pPngOut->nWidth
		, (png_uint_32 *)&pPngOut->nHeight
		, &iBitDepth
		, &iColorType
		, NULL, NULL, NULL);


	// row_bytes is the width x number of channels
	ulRowBytes = png_get_rowbytes(png_ptr, info_ptr);
	ulChannels = png_get_channels(png_ptr, info_ptr);


	// Setup Channel
	pPngOut->nChannel= ulChannels;


	// now we can allocate memory to store the image
	pPixel = new png_byte[ulRowBytes * pPngOut->nHeight];

	if(NULL == pPixel)
		goto LOAD_IMAGE_ERROR;


	// and allocate memory for an array of row-pointers
	ppbRowPointers = new png_bytep[pPngOut->nHeight];

	if( NULL == ppbRowPointers)
		goto LOAD_IMAGE_ERROR;




	// set the individual row-pointers to point at the correct offsets
	for(i = 0; i < pPngOut->nHeight; i++)
		ppbRowPointers[i] = pPixel + i * ulRowBytes;

	
	// now we can go ahead and just read the whole image
	png_read_image(png_ptr, ppbRowPointers);

	// read the additional chunks in the PNG file (not really needed)
	png_read_end(png_ptr, NULL);

	// yepp, done
	fclose (fp);


	
	// and we're done
	SAFE_DELETE_ARRAY(	ppbRowPointers	);

	// free
	png_destroy_read_struct(&png_ptr, &info_ptr, NULL);

	
	// Setup Output Data
	pPngOut->pPixel = pPixel;

	return 0;

LOAD_IMAGE_ERROR:
	
	fclose(fp);

	png_destroy_read_struct(&png_ptr, &info_ptr, NULL);
	SAFE_DELETE_ARRAY(	ppbRowPointers	);

	return -1;
}


INT LgDev_CreateImage(char* sCmd
					, IGLImage** pData
					, char* sFile)
{
	*pData = NULL;

	CGLImage* pObj = new CGLImage;

	if(FAILED(pObj->Create( sFile)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}


