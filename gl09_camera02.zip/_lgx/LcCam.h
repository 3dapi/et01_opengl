// Interface for the CLcCam class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _LcCam_H_
#define _LcCam_H_


class CLcCam : public ILcCam
{
protected:
	FLOAT		m_fFv;				// Field of View
    FLOAT		m_fAs;				// Aspect Ratio
    FLOAT		m_fNr;				// Near
    FLOAT		m_fFr;				// Far

	FLOAT		m_nScnW;			// Screen Width
	FLOAT		m_nScnH;			// Screen Height

	D3DXVECTOR3	m_vcEye;			// Camera position
	D3DXVECTOR3	m_vcLook;			// Look vector
	D3DXVECTOR3	m_vcUp;				// up vector

	FLOAT		m_fYaw;
	FLOAT		m_fPitch;

	D3DXMATRIX	m_mtViw;			// View Matrix
	D3DXMATRIX	m_mtPrj;			// Projection Matrix
	

public:
	CLcCam();
	virtual ~CLcCam();

	virtual	INT		Create(FLOAT ScnW, FLOAT ScnH);
	virtual	INT		FrameMove();

	virtual	const D3DXMATRIX*	GetMatrixViw()	const	{	return &m_mtViw;	}
	virtual	const D3DXMATRIX*	GetMatrixPrj()	const	{	return &m_mtPrj;	}

	virtual	const D3DXVECTOR3*	GetEye()	const		{	return &m_vcEye;	}
	virtual	const D3DXVECTOR3*	GetLook()	const		{	return &m_vcLook;	}
	virtual	const D3DXVECTOR3*	GetUp()		const		{	return &m_vcUp;		}

public:
	virtual	void	MoveSideward(FLOAT	fSpeed);
	virtual	void	MoveForward	(FLOAT	fSpeed, FLOAT fY=0);
	virtual	void	Rotation(FLOAT fYaw, FLOAT fPitch, FLOAT fSpeed);

	virtual	void	TransformProj();
	virtual	void	TransformView();
};

#endif
