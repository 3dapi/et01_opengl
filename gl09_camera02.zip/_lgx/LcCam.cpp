// Implementation of the CLcCam class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include <gl/gl.h>						// standard OpenGL include
#include <gl/glu.h>						// OpenGL utilties
#include <gl/glaux.h>					// OpenGL auxiliary functions

#include <d3dx9math.h>

#include "ILcCam.h"
#include "LcCam.h"


CLcCam::CLcCam()
{

}

CLcCam::~CLcCam()
{

}


INT CLcCam::Create(FLOAT ScnW, FLOAT ScnH)
{
	m_fYaw		= 0.f;
	m_fPitch	= 0.f;

	m_vcEye		= D3DXVECTOR3(100, -350, 150);
	m_vcLook	= D3DXVECTOR3(100,0,50);
	m_vcUp		= D3DXVECTOR3(0,0,1);

	m_nScnW		= ScnW;
	m_nScnH		= ScnH;

	m_fFv		= 45.f;
	m_fAs		= FLOAT(m_nScnW )/FLOAT(m_nScnH );
	m_fNr		= 1.f;
	m_fFr		= 5000.f;


	D3DXMatrixPerspectiveFovRH(&m_mtPrj
				, D3DXToRadian(m_fFv), m_fAs, m_fNr, m_fFr);
	m_mtPrj._33 =  (m_fNr+m_fFr)/(m_fNr	-m_fFr);
	m_mtPrj._43 =  2.f*m_fNr*m_fFr/(m_fNr-m_fFr);

	D3DXMatrixLookAtRH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);

	return 0;
}


INT CLcCam::FrameMove()
{
	D3DXMatrixLookAtRH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);

	glMatrixMode(GL_PROJECTION);
	glLoadMatrixf((FLOAT*)&m_mtPrj);

	glMatrixMode(GL_MODELVIEW);
	glLoadMatrixf((FLOAT*)&m_mtViw);

	return 0;
}

void CLcCam::MoveSideward(FLOAT fSpeed)
{
	D3DXVECTOR3 vcZ = m_vcLook - m_vcEye;
	D3DXVec3Normalize(&vcZ, &vcZ);

	D3DXVECTOR3	vcX;
	D3DXVec3Cross(&vcX, &vcZ, &m_vcUp);
	D3DXVec3Normalize(&vcX, &vcX);
	m_vcEye  += vcX * fSpeed;
	m_vcLook += vcX * fSpeed;

	D3DXMatrixLookAtRH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
}


void CLcCam::MoveForward(FLOAT fSpeed, FLOAT fD)
{
	D3DXVECTOR3 vcZ;

//	vcZ =D3DXVECTOR3(m_mtViw._12, m_mtViw._22, m_mtViw._32);
//	vcZ = -D3DXVECTOR3(m_mtViw._13, m_mtViw._23, m_mtViw._33);

	vcZ = m_vcLook - m_vcEye;
	D3DXVec3Normalize(&vcZ, &vcZ);

	m_vcEye  += vcZ * fSpeed;
	m_vcLook += vcZ * fSpeed;

	D3DXMatrixLookAtRH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
}



void CLcCam::Rotation(FLOAT fYaw, FLOAT fPitch, FLOAT fSpeed)
{
	m_fYaw   =  D3DXToRadian(fYaw  * fSpeed);
	m_fPitch =  D3DXToRadian(fPitch* fSpeed);
	
	D3DXMATRIX rot;
	D3DXVECTOR3 vcZ;
	D3DXVECTOR3 vcX;

	// Yaw�� ���� ȸ��
	vcZ = m_vcLook - m_vcEye;
	D3DXMatrixRotationZ(&rot, m_fYaw);

	D3DXVec3TransformCoord(&vcZ, &vcZ, &rot);
	D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);

	m_vcLook = vcZ + m_vcEye;
	D3DXMatrixLookAtRH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);


	// Pitch�� ���� ȸ��
	vcZ = m_vcLook - m_vcEye;
	vcX =D3DXVECTOR3(m_mtViw._11, m_mtViw._21, m_mtViw._31);

	D3DXMatrixRotationAxis(&rot, &vcX, m_fPitch);
	D3DXVec3TransformCoord(&vcZ, &vcZ, &rot);
	D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);

	m_vcLook = vcZ + m_vcEye;
	D3DXMatrixLookAtRH(&m_mtViw, &m_vcEye, &m_vcLook, &m_vcUp);
}


void CLcCam::TransformProj()
{
	glViewport(0, 0, INT(m_nScnW), INT(m_nScnH) );
	glMatrixMode(GL_PROJECTION);
	glLoadMatrixf((FLOAT*)&m_mtPrj);
}


void CLcCam::TransformView()
{
	glMatrixMode(GL_MODELVIEW);
	glLoadMatrixf((FLOAT*)&m_mtViw);
}




INT LcEnt_CreateCamera(char* sCmd, ILcCam** pData, FLOAT ScnW, FLOAT ScnH)
{
	*pData = NULL;

	CLcCam* pObj = new CLcCam;

	if(FAILED(pObj->Create(ScnW, ScnH)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}