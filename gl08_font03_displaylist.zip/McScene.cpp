// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
}


CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Init()
{
	m_nGeo = glGenLists(1);

glNewList(m_nGeo, GL_COMPILE);

	glBegin(GL_TRIANGLE_FAN);
		glColor4f( 1, 1, 1, 1);		glVertex3f(  0.0f,  0.0f, 0);
		glColor4f( 1, 0, 0, 1);		glVertex3f(  1.0f,  0.0f, 0);
		glColor4f( 1, 0, 1, 1);		glVertex3f(  0.7f,  0.7f, 0);
		glColor4f( 0, 0, 1, 1);		glVertex3f(  0.0f,  1.0f, 0);
		glColor4f( 0, 1, 1, 1);		glVertex3f( -0.7f,  0.7f, 0);
		glColor4f( 0, 1, 0, 1);		glVertex3f( -1.0f,  0.0f, 0);
		glColor4f( 1, 1, 0, 1);		glVertex3f( -0.7f, -0.7f, 0);
		glColor4f( 0, 0, 1, 1);		glVertex3f(  0.0f, -1.0f, 0);
		glColor4f( 0, 1, 1, 1);		glVertex3f(  0.7f, -0.7f, 0);
		glColor4f( 1, 0, 0, 1);		glVertex3f(  1.0f,  0.0f, 0);
	glEnd();

glEndList();

	return 0;
}

void CMcScene::Destroy()
{
	glDeleteLists(m_nGeo, 1);
}

INT CMcScene::FrameMove()
{
	float fAngle = GetTickCount() * 0.1f;

	
	D3DXMATRIX	mtScl1;
	D3DXMATRIX	mtRot1;
	D3DXMATRIX	mtTrn1;
	D3DXMatrixScaling(&mtScl1, 1.0f, 1.0f, 1.0f);
	D3DXMatrixRotationAxis(&mtRot1, &D3DXVECTOR3(0, 0, 1), D3DXToRadian(fAngle*1.2f));
	D3DXMatrixTranslation(&mtTrn1, 0, 0, 0);

	m_mtObj1 = mtScl1 * mtRot1 * mtTrn1;



	D3DXMATRIX	mtScl2;
	D3DXMATRIX	mtRot2;
	D3DXMATRIX	mtTrn2;
	FLOAT	r = 4.f;
	FLOAT	X = r * cosf(D3DXToRadian(fAngle*1.0f));
	FLOAT	Y = r * sinf(D3DXToRadian(fAngle*1.0f));
	FLOAT	Z = 0;

	D3DXMatrixScaling(&mtScl2, .6f, .6f, .6f);
	D3DXMatrixRotationAxis(&mtRot2, &D3DXVECTOR3(0, 0, 1), D3DXToRadian(fAngle*4.5f));
	D3DXMatrixTranslation(&mtTrn2, X, Y, Z);

	mtTrn2 *= mtTrn1;
	m_mtObj2 = mtScl2 * mtRot2 * mtTrn2;


	D3DXMATRIX	mtScl3;
	D3DXMATRIX	mtRot3;
	D3DXMATRIX	mtTrn3;

	r = 1.5f;
	X = r * cosf(D3DXToRadian(fAngle*3.5f+100));
	Y = r * sinf(D3DXToRadian(fAngle*3.5f+100));
	Z = 0;

	D3DXMatrixScaling(&mtScl3, 0.3f, 0.3f, 0.3f);
	D3DXMatrixRotationAxis(&mtRot3, &D3DXVECTOR3(0, 0, 1), D3DXToRadian(fAngle*10.2f));
	D3DXMatrixTranslation(&mtTrn3, X, Y, Z);

	mtTrn3 *= mtTrn2;
	m_mtObj3 = mtScl3 * mtRot3 * mtTrn3;


	return 0;
}

void CMcScene::Render()
{
	DrawModel(&m_mtObj1);
	DrawModel(&m_mtObj2);
	DrawModel(&m_mtObj3);
}



void CMcScene::DrawModel(D3DXMATRIX* mtWorld)
{
	glPushMatrix();
		glMultMatrixf((FLOAT*)mtWorld);
		glCallList(m_nGeo);
	glPopMatrix();
	
}