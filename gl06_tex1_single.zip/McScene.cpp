// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_nTex	= 0;
}


CMcScene::~CMcScene()
{
	Destroy();
}

void CMcScene::Destroy()
{
	glDeleteTextures (1, &m_nTex);		// delete texture
}



INT CMcScene::Init()
{
	INT hr;

	IGLImage*	pImg;
	hr = LgDev_CreateImage(NULL, &pImg, "texture/check.png");

	if(FAILED(hr))
		return -1;

	INT		nImgW = pImg->GetImgW();
	INT		nImgH = pImg->GetImgH();
	BYTE*	pPxl  = pImg->GetPixel();

	// Generate Texture Name
	glGenTextures (1,&m_nTex);

	// Binding to Texture Name
	glBindTexture (GL_TEXTURE_2D, m_nTex);
	{
		// Load Pixel to Texture Name
		glTexImage2D(GL_TEXTURE_2D, 0, 4, nImgW, nImgH, 0, GL_RGBA, GL_UNSIGNED_BYTE, pPxl);

		// Mipmap Load
		gluBuild2DMipmaps(GL_TEXTURE_2D, 4, nImgW, nImgH, GL_RGBA, GL_UNSIGNED_BYTE, pPxl);
	}
	glBindTexture (GL_TEXTURE_2D, 0);

	delete pImg;

	return 0;
}

INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	glShadeModel(GL_SMOOTH);
	glEnable(GL_CULL_FACE);			// Culling Ȱ��ȭ
	glEnable(GL_DEPTH_TEST);		// ���� �׽�Ʈ Ȱ��ȭ
	glFrontFace(GL_CCW);			// ������ CCW�� �׸���.

	glDisable(GL_LIGHTING);
	
	glColor4f(1,1,1,1);
	glPushMatrix();

		glEnable(GL_TEXTURE_2D);				// Enable 2D texturing
		glBindTexture (GL_TEXTURE_2D, m_nTex);	// Binding Texture to Rendering Machine

		if(::GetAsyncKeyState('N')&0x8000)
		{
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
		}
		else
		{
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		}

		if(::GetAsyncKeyState('R')&0x8000)
		{
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		}
		else
		{
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
			glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
		}


		glBegin(GL_TRIANGLE_FAN);
			glTexCoord2f(-1,-1);	glVertex3f(-1, -1, 0);
			glTexCoord2f( 2,-1);	glVertex3f( 1, -1, 0);
			glTexCoord2f( 2, 2);	glVertex3f( 1,  1, 0);
			glTexCoord2f(-1, 2);	glVertex3f(-1,  1, 0);
		glEnd();

		glBindTexture(GL_TEXTURE_2D, 0);	// Bind Null
		glDisable(GL_TEXTURE_2D);			// Disable

	glPopMatrix();
}



