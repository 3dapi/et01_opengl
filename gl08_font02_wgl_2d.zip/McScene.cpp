// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_hFnt		= NULL;
	m_pTex		= NULL;
}


CMcScene::~CMcScene()
{
	Destroy();
}

void CMcScene::Destroy()
{
	if(m_hFnt)
	{
		DeleteObject(m_hFnt);
		m_hFnt = NULL;
	}

	if(!m_vStr.empty())
	{
		// ���÷��� ��� ����
		for(INT i=0; i<m_vStr.size(); ++i)
			glDeleteLists (m_vStr[i].l, 1);

		m_vStr.clear();
	}

	SAFE_DELETE(	m_pTex	);
}


INT CMcScene::Init()
{
	INT	hr=0;

	hr = LgDev_CreateTexture(NULL, &m_pTex, "texture/title_06.png", NULL, 0, 0);
	if(FAILED(hr))
		return -1;

	INT	nFontH = 72;

	// Font ����.
	LOGFONT lFont=
	{
		-nFontH
		, 0
		, 0
		, 0
		, FW_BOLD
		, FALSE
		, FALSE
		, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS
		, CLIP_DEFAULT_PRECIS
		, NONANTIALIASED_QUALITY	// ANTIALIASED_QUALITY
		, FF_DONTCARE
	};

	strcpy(lFont.lfFaceName, "�ü�ü");

	m_hFnt = CreateFontIndirect(&lFont);

	if(!m_hFnt)
		return -1;


	INT		i;

	// 1. ������ ��Ʈ ����
	HDC		hDC = GetDC(NULL);
	HFONT	hFontOld = (HFONT)SelectObject(hDC, m_hFnt);


	// 2. 2����Ʈ ���ڿ��� ��ȯ
	char	sMsg[]="�ȳ��ϼ��� wgl �ѱ�����Դϴ�.";
	char*	s=sMsg;

	for(i=0; i<strlen(sMsg); ++i)
	{
		WCHAR	t=0;

		if(*s>0)
		{
			MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, s, -1, &t, 1);
			++s;
		}
		else
		{
			MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, s, -1, &t, 2);
			s+=2;
		}

		m_vStr.push_back( TwcharLst(t,0));
	}


	// 3. ���÷��� ����� ����� �� ���ھ� Binding
	for(i=0; i<m_vStr.size(); ++i)
	{
		UINT uList = glGenLists(1);
		wglUseFontBitmapsW(hDC, m_vStr[i].c, 1, uList);

		m_vStr[i].l = uList;
	}


	SelectObject(hDC, hFontOld);
	ReleaseDC(NULL, hDC);	

	return 0;
}

INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	glShadeModel(GL_SMOOTH);
	glEnable(GL_CULL_FACE);
	glFrontFace(GL_CCW);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	m_pTex->DrawPixel(NULL, &D3DXVECTOR2(2,2), NULL, 0, NULL, D3DXCOLOR(1,1,1,1));


	glMatrixMode(GL_PROJECTION);	glLoadIdentity();
	glMatrixMode(GL_MODELVIEW);		glLoadIdentity();


	FLOAT		fW	= 96/72.f;
	float		xPos=-1;
	D3DXCOLOR	xColor(1,0,1,1);
	D3DXVECTOR2	vcP(0, 0);


	// �� �÷��� ����� ���
	for(INT i=0; i<m_vStr.size(); ++i)
	{
		glPushMatrix();
			glTranslatef(xPos, 0, 0.f);
			glColor4fv(xColor);
			glRasterPos2fv(vcP);

			glPushAttrib(GL_LIST_BIT);
				glCallList (m_vStr[i].l);
			glPopAttrib();

		glPopMatrix();

		if(256>m_vStr[i].c)
			xPos += 0.2f;
		else
			xPos += 0.2f * fW;
	}
}



