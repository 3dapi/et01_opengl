// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef _McScene_H_
#define _McScene_H_


#include <vector>
using namespace std;


struct TwcharLst
{
	WCHAR	c;
	GLuint	l;

	TwcharLst():c(0), l(0){}
	TwcharLst(WCHAR C, GLuint L):c(C), l(L){}
};

class CMcScene
{
protected:
	HFONT				m_hFnt;
	vector<TwcharLst>	m_vStr;

	IGLTexture*	m_pTex;


public:
	CMcScene();
	virtual ~CMcScene();

	INT		Init();
	void	Destroy();
	INT		FrameMove();
	void	Render();
};


#endif

