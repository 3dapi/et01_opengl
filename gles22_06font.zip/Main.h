// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef _Main_H_
#define _Main_H_


class CMain : public CApplicationGL
{
protected:
	IGLSprite*	m_pSprite;
	IGLFont*	m_pLXFont;
	CMcScene*	m_pScene;

public:
	CMain();

protected:
	virtual	INT		Init();
	virtual	INT		Destroy();
	virtual	INT		FrameMove();
	virtual	INT		Render();
	virtual	LRESULT	MsgProc(HWND,UINT,WPARAM,LPARAM);

public:
	IGLSprite*	GetSprite()	{	return m_pSprite;	}
};


extern CMain*	g_pApp;
#define GMAIN	g_pApp

#endif

