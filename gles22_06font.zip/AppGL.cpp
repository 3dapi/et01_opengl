// Implementation of the CApplicationGL class.
//
////////////////////////////////////////////////////////////////////////////////


#pragma warning(disable: 4996)


#include <Windows.h>
#include <stdio.h>

#include "GLES2/gl2.h"
#include "GLES2/gl2ext.h"
#include "EGL/egl.h"

#include "_lcgl/GLMath.h"
#include "_lcgl/IGLFont.h"

#include "AppGL.h"


CApplicationGL* CApplicationGL::m_pAppGL = NULL;
	
CApplicationGL::CApplicationGL()
{
	CApplicationGL::m_pAppGL	 = this;

	m_hInst		= NULL;
	m_hWnd		= NULL;
	memset(m_sCls, 0, sizeof(m_sCls));
	strcpy(m_sCls, "LxAppGL");
	m_dWinStyle	= WS_OVERLAPPED| WS_CAPTION|WS_SYSMENU|WS_VISIBLE;


	m_ScnW		= 640;
	m_ScnH		= 480;
	m_ScnX		= 0;
	m_ScnY		= 0;

	m_PxlR		= 8;
	m_PxlG		= 8;
	m_PxlB		= 8;
	m_PxlA		= 8;
	m_PxlD		= 0;
	m_PxlS		= 0;

	m_pEgDsp	= EGL_NO_DISPLAY;
	m_pEgSrf	= EGL_NO_SURFACE;
	m_pEgCtx	= EGL_NO_CONTEXT;


	m_fElapsed	= 0;
	m_fFPS		= 60;
	m_TimeLive	= 10 * 60 * 1000;		// 10���� ����

	m_dClear[0]	= 0.9f;
	m_dClear[1]	= 1.0f;
	m_dClear[2]	= 1.0f;
	m_dClear[3]	= 1.0f;

	m_dClear[0]	= 0.95f;
}


INT CApplicationGL::Create()
{
	m_hInst = (HINSTANCE)::GetModuleHandle(NULL);

	WNDCLASS wc =
	{
		CS_CLASSDC
			, WndProc
			, 0
			, 0
			, m_hInst
			, LoadIcon(NULL, IDI_APPLICATION)
			, LoadCursor(NULL,IDC_ARROW)
			, (HBRUSH)GetStockObject(WHITE_BRUSH)
			, NULL
			, m_sCls
	};

	if( 0==	::RegisterClass(&wc))
		return -1;

	if(FAILED(WindowCreate()))
		return -1;

	if(FAILED(Init3DEnvironment()))
		return -1;

	return 0;
}


INT CApplicationGL::Run()
{
	MSG		msg={0};

	while(WM_QUIT != msg.message)
	{
		if(PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			if(FAILED(WindowCloseTimer()))
			{
				SendMessage(m_hWnd, WM_DESTROY, 0, 0);
				continue;
			}

			Render3DEnvironment();
		}
	}


	Cleanup3DEnvironment();

	return 0;
}


LRESULT CALLBACK CApplicationGL::WndProc(HWND hWnd,UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(CApplicationGL::m_pAppGL)
		return CApplicationGL::m_pAppGL->MsgProc(hWnd, uMsg, wParam, lParam);

	return ::DefWindowProc(hWnd, uMsg, wParam, lParam);
}


LRESULT CApplicationGL::MsgProc(HWND hWnd,UINT uMsg,WPARAM wParam, LPARAM lParam)
{
	if(WM_CREATE == uMsg)
	{
		return 0;
	}
	else if(WM_SIZE == uMsg)
	{
		WindowResize(LOWORD(lParam), HIWORD(lParam));
		return 0;
	}
	else if(WM_COMMAND == uMsg)
	{
		return 0;
	}

	else if(WM_CLOSE == uMsg || WM_DESTROY == uMsg)
	{
		if(m_hWnd)
		{
			HMENU hMenu;
			hMenu = GetMenu(hWnd);
				
			if( hMenu != NULL )
				DestroyMenu( hMenu );
			
			PostQuitMessage(0);
		}

		return 0;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}




INT CApplicationGL::Init3DEnvironment()
{
	if(FAILED(GLCreate()))
		return -1;

	::ShowWindow( m_hWnd, SW_SHOWNORMAL );
	WindowResize(m_ScnW, m_ScnH);
	
	::SetForegroundWindow(m_hWnd);
	::SetFocus(m_hWnd);
	::UpdateWindow( m_hWnd );
	::ShowCursor(TRUE);


	if(FAILED(LgxDev_FontInit()))
		return -1;

	
	glClearColor(m_dClear[0], m_dClear[1], m_dClear[2], m_dClear[3]);


	
	if(FAILED(Init()))
		return -1;

	return 0;
}


INT CApplicationGL::Cleanup3DEnvironment()
{
	Destroy();
	LgxDev_FontDestroy();

	GLDestroy();

	m_hWnd = NULL;
	UnregisterClass(m_sCls, m_hInst);

	return 0;
}

INT CApplicationGL::Render3DEnvironment()
{
	INT hr =0;

	if(!m_hWnd)
		return 0;
	
	hr  = FrameMove();

	if(FAILED(hr))
	{
		SendMessage(m_hWnd, WM_DESTROY, 0, 0);
		return 0;
	}

	hr = Render();

	if(FAILED(hr))
	{
		SendMessage(m_hWnd, WM_DESTROY, 0, 0);
		return 0;
	}

	hr = eglSwapBuffers(m_pEgDsp, m_pEgSrf);

	if(0 == hr)
	{
		SendMessage(m_hWnd, WM_DESTROY, 0, 0);
		return 0;
	}


	UpdateFPS();

	return hr;
}



void CApplicationGL::UpdateFPS()
{
	static DOUBLE	dTimeTck= 0;
	static DOUBLE	dTimeBgn= 0;
	static DOUBLE	dTimeBfr= 0;
	static DOUBLE	dTimeCur= 0;
	static INT		bHards	= -1;
	static INT		nCount	= -1;


	++nCount;

	// ���� �Լ� ȣ���
	if(-1 == bHards)
	{
		LARGE_INTEGER	Tick={0};
		bHards = QueryPerformanceFrequency((LARGE_INTEGER*)&Tick);
//		bHards	= 0;

		// �ϵ���� ������ �ȵ� �ܿ�
		if(0 == bHards)
		{
			dTimeBgn	= GetTickCount();
			dTimeTck	= 1000.;
		}
		else
		{
			LARGE_INTEGER	dBgn={0};
			QueryPerformanceCounter((LARGE_INTEGER*)&dBgn);
			dTimeTck	= DOUBLE(Tick.QuadPart);
			dTimeBgn	= DOUBLE(dBgn.QuadPart);
		}

		return;
	}

	// �ϵ���� ������ �ȵǴ� ��� GetTickCount�� �̿�
	if(0 == bHards)
	{
		dTimeCur = GetTickCount();
	}
	else
	{
		LARGE_INTEGER	dCur={0};
		QueryPerformanceCounter((LARGE_INTEGER*)&dCur);
		dTimeCur	= DOUBLE(dCur.QuadPart);
	}


	m_fElapsed	= (dTimeCur - dTimeBfr)/dTimeTck;
	dTimeBfr	= dTimeCur;


	// 24Frame�� ����
	if(24<nCount)
	{
		DOUBLE fElapsed	= (dTimeCur - dTimeBgn)/dTimeTck;
		m_fFPS	= FLOAT(nCount/fElapsed);
		dTimeBgn = dTimeCur;
		nCount = 0;
	}
}



INT	CApplicationGL::WindowCreate()
{
	RECT rc;
	
	::SetRect( &rc, 0, 0, m_ScnW, m_ScnH);
	::AdjustWindowRect( &rc, m_dWinStyle, FALSE );

	INT iScnSysW = ::GetSystemMetrics(SM_CXSCREEN);
	INT iScnSysH = ::GetSystemMetrics(SM_CYSCREEN);
	m_ScnX	= (iScnSysW - (rc.right-rc.left))/2;
	m_ScnY	= (iScnSysH - (rc.bottom-rc.top))/2;

	m_hWnd = ::CreateWindow( m_sCls
					, m_sCls
					, m_dWinStyle
					, m_ScnX
					, m_ScnY
					, (rc.right-rc.left)
					, (rc.bottom-rc.top)
					, GetDesktopWindow()
					, NULL
					, m_hInst
					, NULL );

	if(!m_hWnd)
		return -1;

	GetWindowRect( m_hWnd, &m_rcWin );
	
	return 0;
}



void CApplicationGL::WindowResize(INT width, INT height)
{
	if (height==0)
		height=1;

	if(m_pEgCtx)
		glViewport(0, 0, width, height);
}



INT CApplicationGL::WindowCloseTimer()
{
	static DWORD	dBgn	= GetTickCount();
	DWORD			dEnd	= GetTickCount();

	if(dEnd - dBgn>m_TimeLive)
		return -1;

	return 0;
}


INT CApplicationGL::GLCreate()
{
	INT	hr = 0;

	EGLint contextAttrs[] = 
	{
		EGL_CONTEXT_CLIENT_VERSION, 2,
		EGL_NONE
	};

	// m_pEgDsp = eglGetDisplay( (EGLNativeDisplayType) m_hDC);	// OpenGL 1.x
	m_pEgDsp = eglGetDisplay(EGL_DEFAULT_DISPLAY);

	if(EGL_NO_DISPLAY == m_pEgDsp)
		return -1;

	hr = eglInitialize(m_pEgDsp, 0, 0);
	if(0 == hr) 
		return -1;


	EGLBoolean exactMatchOnly	= 0;
	EGLBoolean hasDepth			= 1;
	EGLBoolean hasStencil		= 0;

	typedef struct
	{
		EGLint redSize;
		EGLint greenSize;
		EGLint blueSize;
		EGLint alphaSize;
		EGLint depthSize;
		EGLint stencilSize;
	} NvTglConfigRequest;
	NvTglConfigRequest request;

	memset(&request, 0, sizeof(request));

	request.redSize		= m_PxlR;
	request.greenSize	= m_PxlG;
	request.blueSize	= m_PxlB;
	request.alphaSize	= m_PxlA;

	if (hasDepth)
		request.depthSize = 1;   // accept any size

	if (hasStencil)
		request.stencilSize = 1;   // accept any size

#define MAX_CONFIG_ATTRS_SIZE 32
#define MAX_MATCHING_CONFIGS 64

	EGLint configAttrs[MAX_CONFIG_ATTRS_SIZE];
	EGLint i = 0;
	// construct attribute request
	configAttrs[i] = EGL_RENDERABLE_TYPE;
	configAttrs[++i] = EGL_OPENGL_ES2_BIT;
	configAttrs[++i] = EGL_BUFFER_SIZE;
	configAttrs[++i] = request.redSize + request.greenSize + request.blueSize + request.alphaSize;
	configAttrs[++i] = EGL_RED_SIZE;
	configAttrs[++i] = request.redSize;
	configAttrs[++i] = EGL_GREEN_SIZE;
	configAttrs[++i] = request.greenSize;
	configAttrs[++i] = EGL_BLUE_SIZE;
	configAttrs[++i] = request.blueSize;
	configAttrs[++i] = EGL_ALPHA_SIZE;
	configAttrs[++i] = request.alphaSize;
	configAttrs[++i] = EGL_DEPTH_SIZE;
	configAttrs[++i] = request.depthSize;
	configAttrs[++i] = EGL_STENCIL_SIZE;
	configAttrs[++i] = request.stencilSize;
	configAttrs[++i] = EGL_NONE;

	if(i >= MAX_CONFIG_ATTRS_SIZE)
		return-1;

	// choose configs
	EGLConfig matchingConfigs[MAX_MATCHING_CONFIGS];
	EGLint numMatchingConfigs = 0;

	hr = eglChooseConfig(m_pEgDsp, configAttrs, matchingConfigs, MAX_MATCHING_CONFIGS, &numMatchingConfigs);
	if(0 == hr)
		return -1;

	if(0 == numMatchingConfigs)
		return -1;



	EGLConfig config;

	// look for exact match
	for (i = 0; i < numMatchingConfigs; i++)
	{
		EGLConfig testConfig = matchingConfigs[i];

		// query attributes from config
		NvTglConfigRequest cfg;
		EGLBoolean ok = EGL_TRUE;
		ok &= eglGetConfigAttrib(m_pEgDsp, testConfig, EGL_RED_SIZE, &cfg.redSize);
		ok &= eglGetConfigAttrib(m_pEgDsp, testConfig, EGL_GREEN_SIZE, &cfg.greenSize);
		ok &= eglGetConfigAttrib(m_pEgDsp, testConfig, EGL_BLUE_SIZE, &cfg.blueSize);
		ok &= eglGetConfigAttrib(m_pEgDsp, testConfig, EGL_ALPHA_SIZE, &cfg.alphaSize);
		ok &= eglGetConfigAttrib(m_pEgDsp, testConfig, EGL_DEPTH_SIZE, &cfg.depthSize);
		ok &= eglGetConfigAttrib(m_pEgDsp, testConfig, EGL_STENCIL_SIZE, &cfg.stencilSize);

		if (!ok)
		{
			printf("eglGetConfigAttrib failed!\n");
			break;
		}

		// depthSize == 1 indicates to accept any non-zero depth
		EGLBoolean depthMatches =
			((request.depthSize == 1) && (cfg.depthSize > 0)) || (cfg.depthSize == request.depthSize);

		// stencilSize == 1 indicates to accept any non-zero stencil
		EGLBoolean stencilMatches =
			((request.stencilSize == 1) && (cfg.stencilSize > 0)) || (cfg.stencilSize == request.stencilSize);

		// compare to request
		if (cfg.redSize == request.redSize &&
			cfg.greenSize == request.greenSize &&
			cfg.blueSize == request.blueSize &&
			cfg.alphaSize == request.alphaSize &&
			depthMatches && stencilMatches)
		{
			config = testConfig;

			m_PxlR	= cfg.redSize;
			m_PxlG	= cfg.greenSize;
			m_PxlB	= cfg.blueSize;
			m_PxlA	= cfg.alphaSize;
			m_PxlD	= cfg.depthSize;
			m_PxlS	= cfg.stencilSize;

			break;
		}
	}

	if (i >= numMatchingConfigs)
	{
		if (exactMatchOnly)
			return -1;

		config = matchingConfigs[0];
	}


	m_pEgCtx = eglCreateContext(m_pEgDsp, config, EGL_NO_CONTEXT, contextAttrs);
	if(NULL == m_pEgCtx)
		return -1;

	m_pEgSrf = eglCreateWindowSurface(m_pEgDsp, config, m_hWnd, 0);
	if(NULL == m_pEgSrf)
		return -1;

	if(0 == eglMakeCurrent(m_pEgDsp, m_pEgSrf, m_pEgSrf, m_pEgCtx))
		return -1;

	if(0 == eglSwapInterval(m_pEgDsp, 0)) 
		return -1;

	return 0;
}

INT CApplicationGL::GLDestroy()
	{
	if(0 == m_pEgDsp)
		return 0;

	eglMakeCurrent(m_pEgDsp, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);

	eglDestroyContext(m_pEgDsp, m_pEgCtx);
	eglDestroySurface(m_pEgDsp, m_pEgSrf);
	eglTerminate(m_pEgDsp);

	m_pEgDsp = 0;

	return 0;
}



