// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef _McScene_H_
#define _McScene_H_


class CMcScene
{
protected:
	IGLEffect*	m_pEft;

	GLfloat s_vtx[3 * 4];

public:
	CMcScene();
	virtual ~CMcScene();

	virtual	INT		Create();
	virtual	void	Destroy();
	virtual	INT		FrameMove();
	virtual	void	Render();
};


#endif

