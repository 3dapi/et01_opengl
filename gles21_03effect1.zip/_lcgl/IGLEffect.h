// Interface for the IGLEffect class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _IGLEffect_H_
#define _IGLEffect_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
	virtual ~CLASS_NAME(){}
#endif


interface IGLEffect
{
	LC_CLASS_DESTROYER(	IGLEffect	);

	virtual	INT		Create(void* =0, void* =0, void* =0, void* =0)=0;
	virtual	void	Destroy()=0;
	virtual	INT		Begin()=0;
	virtual	INT		End()=0;
	virtual	INT		SetAttribIndex(char* attName, INT nIndex) =0;
};


INT LgDev_CreateEffect(char* sCmd
					, IGLEffect** pData
					, void* p1				// Vertex Shader Source
					, void* p2				// Fragment Shader Source
					, void* p3				// Bind Positon Attrib Location
					, void* p4	= NULL		// No Use
					);


#endif


