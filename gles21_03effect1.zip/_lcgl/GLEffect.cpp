// Implementation of the CGLEffect class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include "GLES2/gl2.h"
#include "GLES2/gl2ext.h"
#include "EGL/egl.h"

#include "IGLEffect.h"


class CGLEffect : public IGLEffect
{
protected:
	GLuint	m_eProg;
public:
	CGLEffect();
	virtual ~CGLEffect();

	virtual	INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual	void	Destroy();

	virtual	INT		Begin();
	virtual	INT		End();

	virtual	INT	SetAttribIndex(char* attName, INT nIndex);
};



CGLEffect::CGLEffect()
{
	m_eProg = 0;
}


CGLEffect::~CGLEffect()
{
	Destroy();
}


void CGLEffect::Destroy()
{
	if(m_eProg)
	{
		glDeleteProgram(m_eProg);
		m_eProg	= 0;
	}
}

INT CGLEffect::Create(void* p1, void* p2, void* p3, void* p4)
{
	INT		hr = 0;
	char*	sShaderVtx = (char* )p1;
	char*	sShaderFrg = (char* )p2;
	char*	sBindAttLoc= (char* )p3;

	GLuint ShaderVtx = 0;
	GLuint ShaderFrg = 0;
	const char* sSrc = 0;
	INT			iLen = 0;

	// Create Vertex Shader
	ShaderVtx = glCreateShader(GL_VERTEX_SHADER);
	if(0 == ShaderVtx)
	{
		printf("Couldn't Create Shader.\n\n");
		return -1;
	}

	sSrc = sShaderVtx;
	iLen = strlen(sSrc);

	glShaderSource(ShaderVtx, 1, (const char**)&sSrc, &iLen);
	glCompileShader(ShaderVtx);
	glGetShaderiv(ShaderVtx, GL_COMPILE_STATUS, &hr);
	if(!hr) 
	{
		glGetShaderiv(ShaderVtx, GL_INFO_LOG_LENGTH, &hr);
		char* sLog = (char*)malloc (sizeof(char) * (hr+4) );
		memset(sLog, 0, hr+4);
		glGetShaderInfoLog ( ShaderVtx, hr, NULL, sLog );
		printf("Compile Shader Failed: %s.\n\n", sLog);
		free(sLog);
	}


	// Create Fragment Shader
	ShaderFrg = glCreateShader(GL_FRAGMENT_SHADER);
	if(0 == ShaderFrg)
	{
		printf("Couldn't Create Shader.\n\n");
		return -1;
	}

	sSrc = sShaderFrg;
	iLen = strlen(sSrc);

	glShaderSource(ShaderFrg, 1, (const char**)&sSrc, &iLen);
	glCompileShader(ShaderFrg);
	glGetShaderiv(ShaderFrg, GL_COMPILE_STATUS, &hr);
	if(!hr) 
	{
		glGetShaderiv(ShaderFrg, GL_INFO_LOG_LENGTH, &hr);
		char* sLog = (char*)malloc (sizeof(char) * (hr+4) );
		memset(sLog, 0, hr+4);
		glGetShaderInfoLog (ShaderFrg, hr, NULL, sLog );
		printf("Compile Shader Failed: %s.\n\n", sLog);
		free(sLog);
	}


	// Create Program Object
	m_eProg = glCreateProgram();

	if(0 == m_eProg)
		return -1;


	// Attach
	glAttachShader(m_eProg, ShaderVtx);
	glAttachShader(m_eProg, ShaderFrg);


	// Setup Position Attribute
	glBindAttribLocation(m_eProg, 0, sBindAttLoc);


	// Linking
	glLinkProgram(m_eProg);
	glGetProgramiv(m_eProg, GL_LINK_STATUS, &hr);
	if(!hr) 
	{
		printf("Couldn't link shader! Exiting...\n");
		return -1;
	}

	return 0;
}


INT CGLEffect::Begin()
{
	glUseProgram(m_eProg);
	return 0;
}


INT CGLEffect::End()
{
	glUseProgram(0);
	return 0;
}


INT	CGLEffect::SetAttribIndex(char* attName, INT nIndex)
{
	glBindAttribLocation(m_eProg, nIndex, attName);
//	glEnableVertexAttribArray(nIndex);
	
	return 0;
}




INT LgDev_CreateEffect(char* sCmd
					, IGLEffect** pData
					, void* p1			// Vertex Shader Source
					, void* p2			// Fragment Shader Source
					, void* p3			// Bind Positon Attrib Location
					, void* p4			// No Use
					)
{
	*pData = NULL;

	CGLEffect* pObj = new CGLEffect;

	if(FAILED(pObj->Create(p1, p2, p3, p4)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}