// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_esProgram	 = 0;
}


CMcScene::~CMcScene()
{
	Destroy();
}


void CMcScene::Destroy()
{
	if(m_esProgram)
	{
		glDeleteProgram(m_esProgram);
		m_esProgram = 0;
	}
}


INT CMcScene::Create()
{
	INT hr =0;

	GLuint ShaderVtx = 0;
	const char* sSrc = 0;
	INT			iLen = 0;

	char	sShaderVtx[] =
	"attribute vec2 att_pos;			\n"
	"									\n"
	"void main()						\n"
	"{									\n"
	"	gl_Position.x = att_pos.x;		\n"
	"	gl_Position.y = att_pos.y;		\n"
	"	gl_Position.z = 0.0;			\n"
	"	gl_Position.w = 1.0;			\n"
	"}									\n"
	;

	// Create Vertex Shader

	ShaderVtx = glCreateShader(GL_VERTEX_SHADER);
	if(0 == ShaderVtx)
	{
		printf("Couldn't Create Shader.\n\n");
		return -1;
	}

	sSrc = sShaderVtx;	// glShaderSource() �Լ� ���ο��� �����͸� �̵��ϴ°� ����. �迭�� �ּҸ� ���� ������ Error
	iLen = strlen(sSrc);

	glShaderSource(ShaderVtx, 1, (const char**)&sSrc, &iLen);
	glCompileShader(ShaderVtx);
	glGetShaderiv(ShaderVtx, GL_COMPILE_STATUS, &hr);
	if(!hr) 
	{
		glGetShaderiv(ShaderVtx, GL_INFO_LOG_LENGTH, &hr);
		char* sLog = (char*)malloc (sizeof(char) * (hr+4) );
		memset(sLog, 0, hr+4);
		glGetShaderInfoLog ( ShaderVtx, hr, NULL, sLog );
		printf("Compile Shader Failed: %s.\n\n", sLog);
		free(sLog);
	}


	GLuint ShaderFrg= 0;
	char	sShaderFrg[] =
	"										\n"
	"void main()							\n"
	"{										\n"
	"	gl_FragColor = vec4(1, 0, 0, 1);	\n"
	"}										\n"
	;


	// Create Fragment Shader

	ShaderFrg = glCreateShader(GL_FRAGMENT_SHADER);
	if(0 == ShaderFrg)
	{
		printf("Couldn't Create Shader.\n\n");
		return -1;
	}

	sSrc = sShaderFrg;
	iLen = strlen(sSrc);

	glShaderSource(ShaderFrg, 1, (const char**)&sSrc, &iLen);
	glCompileShader(ShaderFrg);
	glGetShaderiv(ShaderFrg, GL_COMPILE_STATUS, &hr);
	if(!hr) 
	{
		glGetShaderiv(ShaderFrg, GL_INFO_LOG_LENGTH, &hr);
		char* sLog = (char*)malloc (sizeof(char) * (hr+4) );
		memset(sLog, 0, hr+4);
		glGetShaderInfoLog (ShaderFrg, hr, NULL, sLog );
		printf("Compile Shader Failed: %s.\n\n", sLog);
		free(sLog);
	}



	// Create Program Object
	m_esProgram = glCreateProgram();

	if(0 == m_esProgram)
		return -1;


	// Attach
	glAttachShader(m_esProgram, ShaderVtx);
	glAttachShader(m_esProgram, ShaderFrg);

	// Setup Position Attribute
	glBindAttribLocation(m_esProgram, 0, "att_pos");


	// Linking
	glLinkProgram(m_esProgram);
	glGetProgramiv(m_esProgram, GL_LINK_STATUS, &hr);
	if(!hr) 
	{
		printf("Couldn't link shader! Exiting...\n");
		return -1;
	}

	return 0;
}


INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	GLfloat s_vtx[] =
	{
		-1.0f, -1.0f,
		 1.0f, -1.0f,
		 0.0f,  1.0f, 
	};

	// Use the program object
	glUseProgram(m_esProgram);
	glEnableVertexAttribArray(0);	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, s_vtx);

	glDrawArrays(GL_TRIANGLE_FAN, 0, 3);

	glUseProgram (0);
}

