//
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef __StdAfx_H_
#define __StdAfx_H_


#pragma warning(disable: 4996)
#pragma warning(disable: 4018)

#pragma comment(linker, "/subsystem:console")

#pragma comment(lib, "libEGL.lib")
#pragma comment(lib, "libGLESv2.lib")


#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "GLES2/gl2.h"
#include "GLES2/gl2ext.h"
#include "EGL/egl.h"


#include "AppGL.h"

#include "McScene.h"



#include "Main.h"

#endif


