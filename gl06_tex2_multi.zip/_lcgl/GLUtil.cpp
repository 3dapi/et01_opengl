// Implementation of the GLUtil Functions.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include <gl/gl.h>

#include "GLUtil.h"


