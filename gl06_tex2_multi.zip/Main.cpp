// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pScene	= NULL;
}


INT CMain::Init()
{
	m_pScene = new CMcScene;
	
	if(FAILED(m_pScene->Init()))
	{
		delete m_pScene;
		return -1;
	}

	return 0;
}

INT CMain::Destroy()
{
	SAFE_DELETE(	m_pScene	);

	return 0;
}

INT CMain::FrameMove()
{
	FLOAT	fAspt	=float(m_ScnW)/float(m_ScnH);
	FLOAT	fNear = 1.0f;
	FLOAT	fFar  = 5000.f;


	D3DXMatrixIdentity(&m_mtPrj);
	D3DXMatrixIdentity(&m_mtViw);

	D3DXMatrixPerspectiveFovRH(&m_mtPrj, D3DXToRadian(45), fAspt, fNear, fFar);
	m_mtPrj._33 =  (fNear+fFar)/(fNear	-fFar);
	m_mtPrj._43 =  2.f*fNear*fFar/(fNear-fFar);

	D3DXMatrixLookAtRH(&m_mtViw, &D3DXVECTOR3(0,0, 16), &D3DXVECTOR3(0,0,0), &D3DXVECTOR3(0,1,0));



	m_pScene->FrameMove();

	return 0;
}

INT CMain::Render()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT |GL_STENCIL_BUFFER_BIT);

//	glMatrixMode(GL_PROJECTION);
//	glLoadIdentity();
//	gluPerspective( 45, float(m_ScnW)/float(m_ScnH), 1.f, 5000.f);
//
//	D3DXMATRIX mtT;
//	glGetFloatv(GL_PROJECTION_MATRIX, (FLOAT*)&mtT);
//	GLenum err = glGetError();

	glMatrixMode(GL_PROJECTION);
	glLoadMatrixf((FLOAT*)&m_mtPrj);


	glMatrixMode(GL_MODELVIEW);
	glLoadMatrixf((FLOAT*)&m_mtViw);

	m_pScene->Render();



	glFlush();
	return 0;
}

LRESULT	CMain::MsgProc(HWND hWnd,UINT uMsg,WPARAM wParam, LPARAM lParam)
{
	if(WM_KEYDOWN == uMsg)
	{
		if(VK_ESCAPE == wParam)
		{
			SendMessage(hWnd, WM_DESTROY, 0, 0);
			return 0;
		}
	}

	return CApplicationGL::MsgProc(hWnd, uMsg, wParam, lParam);
}
