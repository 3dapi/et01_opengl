// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"



PFNGLMULTITEXCOORD2FARBPROC			glMultiTexCoord2fARB = NULL;
PFNGLACTIVETEXTUREARBPROC			glActiveTextureARB = NULL;
PFNGLCLIENTACTIVETEXTUREARBPROC		glClientActiveTextureARB = NULL;



INT EnumExtension(char* sCheck, char* sGetStrings)
{
	char*	sSrc= sGetStrings;
	char	seps[]   = " ";
	char*	token;

	token = strtok( sSrc, seps );
	while( token != NULL )
	{
		if(0 == _stricmp(sCheck, token))
			return 0;

		token = strtok( NULL, seps );
	}

	return -1;

//	sExtension
//	GL_ARB_multitexture
//	GL_EXT_texture_env_add
//	GL_EXT_compiled_vertex_array
//	GL_S3_s3tc
//	GL_ARB_depth_texture
//	GL_ARB_fragment_program
//	GL_ARB_fragment_program_shadow
//	GL_ARB_fragment_shader
//	GL_ARB_multisample
//	GL_ARB_occlusion_query
//	GL_ARB_point_param
}





CMcScene::CMcScene()
{
	m_nTexD	= 0;
	m_nTexL	= 0;
}


CMcScene::~CMcScene()
{
	Destroy();
}

void CMcScene::Destroy()
{
	if(m_nTexD)	{	glDeleteTextures (1, &m_nTexD);	m_nTexD	= 0;	}
	if(m_nTexL)	{	glDeleteTextures (1, &m_nTexL);	m_nTexL	= 0;	}
}



INT CMcScene::Init()
{
	INT hr;

	char* sExtension = (char*)glGetString(GL_EXTENSIONS);

	hr = EnumExtension("GL_EXT_compiled_vertex_array", sExtension);

	if(FAILED(hr))
		return -1;


	glActiveTextureARB			= (PFNGLACTIVETEXTUREARBPROC) wglGetProcAddress("glActiveTextureARB");
	glMultiTexCoord2fARB		= (PFNGLMULTITEXCOORD2FARBPROC) wglGetProcAddress("glMultiTexCoord2fARB");
	glClientActiveTextureARB	= (PFNGLCLIENTACTIVETEXTUREARBPROC)wglGetProcAddress("glClientActiveTextureARB");


	{
		IGLImage*	pImg;
		hr = LgDev_CreateImage(NULL, &pImg, "texture/stones.png");

		if(FAILED(hr))
			return -1;

		INT		nImgW = pImg->GetImgW();
		INT		nImgH = pImg->GetImgH();
		BYTE*	pPxl  = pImg->GetPixel();

		glGenTextures (1,&m_nTexD);
		glBindTexture (GL_TEXTURE_2D, m_nTexD);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, nImgW, nImgH, 0, GL_RGBA, GL_UNSIGNED_BYTE, pPxl);
		gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, nImgW, nImgH, GL_RGBA, GL_UNSIGNED_BYTE, pPxl);
		glBindTexture (GL_TEXTURE_2D, 0);
		delete pImg;
	}

	{
		IGLImage*	pImg;
		hr = LgDev_CreateImage(NULL, &pImg, "texture/env0.png");

		if(FAILED(hr))
			return -1;

		INT		nImgW = pImg->GetImgW();
		INT		nImgH = pImg->GetImgH();
		BYTE*	pPxl  = pImg->GetPixel();

		glGenTextures (1,&m_nTexL);
		glBindTexture (GL_TEXTURE_2D, m_nTexL);
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, nImgW, nImgH, 0, GL_RGBA, GL_UNSIGNED_BYTE, pPxl);
		gluBuild2DMipmaps(GL_TEXTURE_2D, GL_RGBA, nImgW, nImgH, GL_RGBA, GL_UNSIGNED_BYTE, pPxl);
		glBindTexture (GL_TEXTURE_2D, 0);
		delete pImg;
	}


	return 0;
}

INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	glShadeModel(GL_SMOOTH);
	glEnable(GL_CULL_FACE);			// Culling Ȱ��ȭ
	glEnable(GL_DEPTH_TEST);		// ���� �׽�Ʈ Ȱ��ȭ
	glFrontFace(GL_CCW);			// ������ CCW�� �׸���.

	glDisable(GL_LIGHTING);
	
	glColor4f(0,1,1,1);
	glPushMatrix();
		glActiveTextureARB(GL_TEXTURE0_ARB);
		glEnable(GL_TEXTURE_2D);
		glBindTexture (GL_TEXTURE_2D, m_nTexD);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);


		glActiveTextureARB(GL_TEXTURE1_ARB);
		glEnable(GL_TEXTURE_2D);
		glBindTexture (GL_TEXTURE_2D, m_nTexL);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);


		D3DXMATRIX	mtWld;
		D3DXMATRIX	mtScl;
		D3DXMATRIX	mtTrn;
		D3DXMatrixScaling(&mtScl, 4, 4, 4);
		D3DXMatrixTranslation(&mtTrn, 0, 0, 0);

		mtWld = mtScl * mtTrn;
		
		DrawModel(&mtWld);



		glActiveTextureARB(GL_TEXTURE0_ARB);	glBindTexture (GL_TEXTURE_2D, 0);
		glActiveTextureARB(GL_TEXTURE1_ARB);	glBindTexture (GL_TEXTURE_2D, 0);

	glPopMatrix();
}


void CMcScene::DrawModel(D3DXMATRIX* mtWorld)
{
	glPushMatrix();
		glMultMatrixf((FLOAT*)mtWorld);

		glBegin(GL_TRIANGLE_FAN);
			glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0, 0);	glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0, 0);	glVertex3f(-2.6f, -2, 0);
			glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 1, 0);	glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 1, 0);	glVertex3f( 2.6f, -2, 0);
			glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 1, 1);	glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 1, 1);	glVertex3f( 2.6f,  2, 0);
			glMultiTexCoord2fARB(GL_TEXTURE0_ARB, 0, 1);	glMultiTexCoord2fARB(GL_TEXTURE1_ARB, 0, 1);	glVertex3f(-2.6f,  2, 0);
		glEnd();

	glPopMatrix();
}


