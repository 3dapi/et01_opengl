// Interface for the CGLImage class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _GLImage_H_
#define _GLImage_H_


class CGLImage : public IGLImage
{
public:
	struct TGAHEADER
	{
		BYTE	ImgT;				// imageTypeCode
		SHORT	ImgW;				// Width
		SHORT	ImgH;				// Height
		BYTE	ImgB;				// Bit Count
	};


	struct PNG_PIXEL
	{
		BYTE*	pPixel;
		INT		nWidth;
		INT		nHeight;
		INT		nChannel;

		BYTE	BgColorR;
		BYTE	BgColorG;
		BYTE	BgColorB;

		PNG_PIXEL() : pPixel(NULL), nWidth(0), nHeight(0), nChannel(0), BgColorR(0), BgColorG(0), BgColorB(0){}
	};

protected:
	INT		m_Type;			// Image Type
	INT		m_ImgW;			// Image Width
	INT		m_ImgH;			// Image Height
	INT		m_ImgD;			// Image Depth(or Channel
	BYTE*	m_pPxl;			// Pixel Data

public:
	CGLImage ();
	virtual ~CGLImage();

	virtual	INT		Create(char* sFile);
	virtual	void	Destroy();

	virtual	INT		GetType() {	return m_Type;	}
	virtual	INT		GetImgW() {	return m_ImgW;	}
	virtual	INT		GetImgH() {	return m_ImgH;	}
	virtual	BYTE* const	GetPixel() const{	return m_pPxl;	}

protected:
	INT		LoadBitmapFile(char* sFile);
	INT		LoadTGAFile(char* sFile);
	INT		LoadPngFile(char* sFile);
	INT		LoadPngFile(PNG_PIXEL*pPngOut, char* sFile);
};




#endif