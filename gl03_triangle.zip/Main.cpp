// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{

}


INT CMain::Init()
{
	return 0;
}

INT CMain::Destroy()
{
	return 0;
}

INT CMain::FrameMove()
{
	return 0;
}

INT CMain::Render()
{
	glClearColor( 0.f, 0.6f, 0.8f, 1.f);
//	glClearColor( 1.0f, 1.0f, 1.0f, 1.f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT |GL_STENCIL_BUFFER_BIT);

//	glColor4f( 1, 0, 0, 1);

	glBegin(GL_TRIANGLES);
		glVertex3f( -1, -1, 0);
		glVertex3f(  1, -1, 0);
		glVertex3f(  0,  1, 0);
	glEnd();

//	glBegin(GL_TRIANGLE_FAN);
//		glColor4f( 1, 0, 0, 1);		glVertex3f( -1.0F, -1.0F, 0);
//		glColor4f( 0, 1, 0, 1);		glVertex3f(  1.0F, -1.0F, 0);
//		glColor4f( 0, 0, 1, 1);		glVertex3f(  1.0F,  1.0F, 0);
//		glColor4f( 1, 0, 1, 1);		glVertex3f( -1.0F,  1.0F, 0);
//	glEnd();


	glFlush();
	return 0;
}




LRESULT	CMain::MsgProc(HWND hWnd,UINT uMsg,WPARAM wParam, LPARAM lParam)
{
	if(WM_KEYDOWN == uMsg)
	{
		if(VK_ESCAPE == wParam)
		{
			SendMessage(hWnd, WM_DESTROY, 0, 0);
			return 0;
		}
	}

	return CApplicationGL::MsgProc(hWnd, uMsg, wParam, lParam);
}
