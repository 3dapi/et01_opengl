//
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef __StdAfx_H_
#define __StdAfx_H_


#pragma comment(lib, "OpenGL32.Lib")
#pragma comment(lib, "Glu32.lib")
#pragma comment(lib, "GlAux.Lib")


#include <windows.h>

#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/GLAux.h>


#include "AppGL.h"



#include "Main.h"

#endif


