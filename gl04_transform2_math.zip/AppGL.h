// Interface for the CApplicationGL class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef _AppGL_H_
#define _AppGL_H_


class CApplicationGL
{
protected:
	HINSTANCE	m_hInst;
	HWND		m_hWnd;
	HDC			m_hDC;
	INT			m_ScnW;
	INT			m_ScnH;
	char		m_sCls[128];

	HGLRC		m_hGlDC;

public:
	CApplicationGL();
	INT		Create(HINSTANCE);
	INT		Cleanup();
	INT		Run();
	INT		Render3D();

protected:
	virtual	INT		Init()		{	return 0;	}
	virtual	INT		Destroy()	{	return 0;	}
	virtual	INT		FrameMove()	{	return 0;	}
	virtual	INT		Render()	{	return 0;	}
	virtual	LRESULT	MsgProc(HWND,UINT,WPARAM,LPARAM);

protected:
	INT		GLCreate();
	INT		GLDestroy();
public:
	static CApplicationGL* m_pAppGL;
	static LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);
};

#endif


