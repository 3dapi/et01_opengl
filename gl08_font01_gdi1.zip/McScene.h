// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef _McScene_H_
#define _McScene_H_


class CMcScene
{
protected:
	HFONT		m_hFnt;
	IGLTexture*	m_pFont;	// Texture
	D3DXCOLOR	m_ColF;		// Font Front Color

	
	IGLTexture*	m_pTex;


public:
	CMcScene();
	virtual ~CMcScene();

	INT		Init();
	void	Destroy();
	INT		FrameMove();
	void	Render();
};


#endif

