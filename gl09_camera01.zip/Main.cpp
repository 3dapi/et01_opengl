// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_pLXFont	= NULL;
	m_pGrid		= NULL;
	m_pScene	= NULL;
}


INT CMain::Init()
{
	INT hr =0;
	
	IGLFont::TFont	hFont(18, FW_BOLD, FALSE, 0, "Arial��ü");
	hr = LgDev_CreateFont(NULL, &m_pLXFont, &hFont);
	if(FAILED(hr))
		return -1;


	hr = LgxObj_Create("Grid", &m_pGrid);
	if(FAILED(hr))
		return -1;
	
	
	m_pScene = new CMcScene;
	
	if(FAILED(m_pScene->Init()))
	{
		delete m_pScene;
		return -1;
	}

	return 0;
}

INT CMain::Destroy()
{
	SAFE_DELETE(	m_pLXFont	);
	SAFE_DELETE(	m_pGrid		);
	SAFE_DELETE(	m_pScene	);

	return 0;
}

INT CMain::FrameMove()
{
	FLOAT	fAspt	=float(m_ScnW)/float(m_ScnH);
	FLOAT	fNear = 1.0f;
	FLOAT	fFar  = 5000.f;


	D3DXMatrixIdentity(&m_mtPrj);
	D3DXMatrixIdentity(&m_mtViw);

	D3DXMatrixPerspectiveFovRH(&m_mtPrj, D3DXToRadian(45), fAspt, fNear, fFar);
	m_mtPrj._33 =  (fNear+fFar)/(fNear	-fFar);
	m_mtPrj._43 =  2.f*fNear*fFar/(fNear-fFar);

	D3DXMatrixLookAtRH(&m_mtViw, &D3DXVECTOR3(150,150, 150), &D3DXVECTOR3(0,20,0), &D3DXVECTOR3(0,1,0));


	m_pGrid->FrameMove();
	m_pScene->FrameMove();


	FLOAT	fTime = MAINAPP->GetFPS();

	char	sMsg[128]={0};
	sprintf(sMsg, "FPS: %4.f", fTime);
	m_pLXFont->SetString(sMsg);

	return 0;
}

INT CMain::Render()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT |GL_STENCIL_BUFFER_BIT);

	glShadeModel(GL_SMOOTH);
	glEnable(GL_CULL_FACE);
	glFrontFace(GL_CCW);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);


//	glMatrixMode(GL_PROJECTION);
//	glLoadIdentity();
//	gluPerspective( 45, float(m_ScnW)/float(m_ScnH), 1.f, 5000.f);
//
//	D3DXMATRIX mtT;
//	glGetFloatv(GL_PROJECTION_MATRIX, (FLOAT*)&mtT);
//	GLenum err = glGetError();





	glMatrixMode(GL_PROJECTION);
	glLoadMatrixf((FLOAT*)&m_mtPrj);


	glMatrixMode(GL_MODELVIEW);
	glLoadMatrixf((FLOAT*)&m_mtViw);


	m_pGrid->Render();
	m_pScene->Render();

//	m_pLXFont->DrawTxt(NULL, NULL, 0, &D3DXVECTOR2(5, 5), D3DXCOLOR(1,1,0,1));

	glFlush();
	return 0;
}

LRESULT	CMain::MsgProc(HWND hWnd,UINT uMsg,WPARAM wParam, LPARAM lParam)
{
	if(WM_KEYDOWN == uMsg)
	{
		if(VK_ESCAPE == wParam)
		{
			SendMessage(hWnd, WM_DESTROY, 0, 0);
			return 0;
		}
	}

	return CApplicationGL::MsgProc(hWnd, uMsg, wParam, lParam);
}
