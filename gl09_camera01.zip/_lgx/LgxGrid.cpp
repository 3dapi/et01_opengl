// Implementation of the CLgxGrid class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include <gl/gl.h>
#include <gl/glu.h>

#include "ILgxObj.h"
#include "LgxGrid.h"



CLgxGrid::CLgxGrid()
{
	m_nID = 0;
}

CLgxGrid::~CLgxGrid()
{
	Destroy();
}

void CLgxGrid::Destroy()
{
	if(m_nID)
	{
		glDeleteLists(m_nID, 1);
		m_nID = 0;
	}
}

INT CLgxGrid::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_nID = glGenLists(1);

	glNewList(m_nID, GL_COMPILE);
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_LIGHTING);
				
//		glEnable(GL_LINE_SMOOTH);
//		glEnable(GL_LINE_STIPPLE_PATTERN);

		glLineWidth(1.2f);

		glBegin(GL_LINES);
			for(INT i = -10; i <=10; i++)
			{
				if(0==i)
					continue;

				glColor3f(.5f, .5f, .5f);
				glVertex3f(i*20.f, 0.f, -200.f);	glVertex3f(i*20.f, 0.f, 0.f   );
				glVertex3f(i*20.f, 0.f,  200.f);	glVertex3f(i*20.f, 0.f, 0.f   );

				glVertex3f(-200.f, 0.f, i*20.f);	glVertex3f(   0.f, 0.f, i*20.f);
				glVertex3f( 200.f, 0.f, i*20.f);	glVertex3f(   0.f, 0.f, i*20.f);
			}

			glColor3f(.5f, 0.f, 0.f);	glVertex3f(-5000.f,    0.f,    0.f);	glVertex3f(0.f, 0.f, 0.f);
			glColor3f(1.f, 0.f, 0.f);	glVertex3f( 5000.f,    0.f,    0.f);	glVertex3f(0.f, 0.f, 0.f);

			glColor3f(0.f, .5f, 0.f);	glVertex3f(	   0.f,-5000.f,    0.f);	glVertex3f(0.f, 0.f, 0.f);
			glColor3f(0.f, 1.f, 0.f);	glVertex3f(	   0.f, 5000.f,    0.f);	glVertex3f(0.f, 0.f, 0.f);
			
			glColor3f(0.f, 0.f, .5f);	glVertex3f(	   0.f,    0.f,-5000.f);	glVertex3f(0.f, 0.f, 0.f);
			glColor3f(0.f, 0.f, 1.f);	glVertex3f(	   0.f,    0.f, 5000.f);	glVertex3f(0.f, 0.f, 0.f);

		glEnd();

		glColor3f(1.f, 1.f, 1.f);

	glEndList();

	return 0;
}


INT CLgxGrid::FrameMove()
{
	return 0;
}

void CLgxGrid::Render()
{
	glCallList(m_nID);

	return;

	glDisable(GL_TEXTURE_2D);
	glDisable(GL_LIGHTING);
			
//	glEnable(GL_LINE_SMOOTH);
//	glEnable(GL_LINE_STIPPLE_PATTERN);

	glLineWidth(1.2f);

	glBegin(GL_LINES);
		for(INT i = -10; i <=10; i++)
		{
			if(0==i)
				continue;

			glColor3f(.5f, .5f, .5f);
			glVertex3f(i*20.f, -200.f, 0.f);	glVertex3f(i*20.f, 0.f   , 0.f);
			glVertex3f(i*20.f,  200.f, 0.f);	glVertex3f(i*20.f, 0.f   , 0.f);

			glVertex3f(-200.f, i*20.f, 0.f);	glVertex3f(   0.f, i*20.f, 0.f);
			glVertex3f( 200.f, i*20.f, 0.f);	glVertex3f(   0.f, i*20.f, 0.f);
		}

		glColor3f(.5f, 0.f, 0.f);	glVertex3f(-5000.f,    0.f,    0.f);	glVertex3f(0.f, 0.f, 0.f);
		glColor3f(1.f, 0.f, 0.f);	glVertex3f( 5000.f,    0.f,    0.f);	glVertex3f(0.f, 0.f, 0.f);

		glColor3f(0.f, .5f, 0.f);	glVertex3f(	   0.f,-5000.f,    0.f);	glVertex3f(0.f, 0.f, 0.f);
		glColor3f(0.f, 1.f, 0.f);	glVertex3f(	   0.f, 5000.f,    0.f);	glVertex3f(0.f, 0.f, 0.f);
		
		glColor3f(0.f, 0.f, .5f);	glVertex3f(	   0.f,    0.f,-5000.f);	glVertex3f(0.f, 0.f, 0.f);
		glColor3f(0.f, 0.f, 1.f);	glVertex3f(	   0.f,    0.f, 5000.f);	glVertex3f(0.f, 0.f, 0.f);

	glEnd();

	glColor3f(1.f, 1.f, 1.f);
}



INT LgxObj_Create(char* sCmd, ILgxObj** pData, void* p1, void* p2, void* p3, void* p4)
{
	*pData = NULL;

	ILgxObj* pObj = NULL;

	if(0 ==_stricmp(sCmd, "Grid"))
		pObj = new CLgxGrid;
	else
		return -1;


	if(FAILED(pObj->Create(p1, p2, p3, p4)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}