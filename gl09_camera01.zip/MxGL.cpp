

#include "_StdAfx.h"


CMain*	g_pApp = NULL;


int WINAPI WinMain(HINSTANCE hInst, HINSTANCE, LPSTR, int)
{
	CMain AppMain;
	g_pApp = &AppMain;

	if(FAILED(AppMain.Create(hInst)))
		return 0;

	return AppMain.Run();
}


