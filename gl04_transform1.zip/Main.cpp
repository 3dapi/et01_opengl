// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{

}


INT CMain::Init()
{
	return 0;
}

INT CMain::Destroy()
{
	return 0;
}

INT CMain::FrameMove()
{
	return 0;
}

INT CMain::Render()
{
	glClearColor( 0.9f, 1.0f, 1.0f, 1.0f);
//	glClearColor( 1.0f, 1.0f, 1.0f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT |GL_STENCIL_BUFFER_BIT);


	glViewport(0, 0, m_ScnW, m_ScnH );			// ����Ʈ ����
	glMatrixMode(GL_PROJECTION);				// Projection ����
	glLoadIdentity();
	gluPerspective( 45, float(m_ScnW)/float(m_ScnH), 1.0f, 5000.0f);


	glMatrixMode(GL_MODELVIEW);					// Model View ����
	glLoadIdentity();
	gluLookAt(0,0, 8,    0,0,0,    0,1,0);


	float fAngle = GetTickCount() * 0.1f;

	
glPushMatrix();
	glTranslatef(-2, 0, 0);
	glRotatef(fAngle, 0, 1, 0);

	glBegin(GL_TRIANGLES);
		glColor4f( 1, 0, 0, 1);		glVertex3f( -2, -2, 0);
		glColor4f( 0, 1, 0, 1);		glVertex3f(  2, -2, 0);
		glColor4f( 0, 0, 1, 1);		glVertex3f(  0,  2, 0);
	glEnd();
glPopMatrix();

glPushMatrix();
//		glTranslatef(2, 0, 0);
//		glRotatef(fAngle, 0, 1, 0);

	D3DXMATRIX	mtTrn;
	D3DXMATRIX	mtRot;
	D3DXMatrixTranslation(&mtTrn, 2, 0, 0);
	D3DXMatrixRotationAxis(&mtRot, &D3DXVECTOR3(0, 1, 0), D3DXToRadian(fAngle));

	glMultMatrixf((FLOAT*)mtTrn);
	glMultMatrixf((FLOAT*)mtRot);

	glBegin(GL_TRIANGLES);
		glColor4f( 1, 0, 0, 1);		glVertex3f( -2, -2, 0);
		glColor4f( 0, 1, 0, 1);		glVertex3f(  2, -2, 0);
		glColor4f( 0, 0, 1, 1);		glVertex3f(  0,  2, 0);
	glEnd();
glPopMatrix();



	glFlush();
	return 0;
}

LRESULT	CMain::MsgProc(HWND hWnd,UINT uMsg,WPARAM wParam, LPARAM lParam)
{
	if(WM_KEYDOWN == uMsg)
	{
		if(VK_ESCAPE == wParam)
		{
			SendMessage(hWnd, WM_DESTROY, 0, 0);
			return 0;
		}
	}

	return CApplicationGL::MsgProc(hWnd, uMsg, wParam, lParam);
}
