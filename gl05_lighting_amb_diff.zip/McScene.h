// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef _McScene_H_
#define _McScene_H_


class CMcScene
{
protected:
	D3DXMATRIX	m_mtObj;

public:
	CMcScene();
	virtual ~CMcScene();

	INT		Init();
	void	Destroy();
	INT		FrameMove();
	void	Render();

protected:
	void	DrawModel(D3DXMATRIX* mtWorld);
};


#endif

