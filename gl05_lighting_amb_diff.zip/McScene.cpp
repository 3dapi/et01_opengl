// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
}


CMcScene::~CMcScene()
{
	Destroy();
}

INT CMcScene::Init()
{
	return 0;
}

void CMcScene::Destroy()
{
}

INT CMcScene::FrameMove()
{
	float fAngle = GetTickCount() * 0.1f;

	
	D3DXMATRIX	mtScl1;
	D3DXMATRIX	mtRot1;
	D3DXMATRIX	mtTrn1;

	D3DXMatrixIdentity(&m_mtObj);
	D3DXMatrixScaling(&mtScl1, 1.0f, 1.0f, 1.0f);
	D3DXMatrixRotationAxis(&mtRot1, &D3DXVECTOR3(0, 1, 0), D3DXToRadian(fAngle*.5f));
	D3DXMatrixTranslation(&mtTrn1, 0, 0, 0);

	m_mtObj = mtScl1 * mtRot1 * mtTrn1;


	return 0;
}

void CMcScene::Render()
{
	if(::GetAsyncKeyState('L') & 0x8000)
		glShadeModel(GL_FLAT);
	else
		glShadeModel(GL_SMOOTH);


	glEnable(GL_CULL_FACE);			// Culling Ȱ��ȭ
	glEnable(GL_DEPTH_TEST);		// ���� �׽�Ʈ Ȱ��ȭ
	glFrontFace(GL_CCW);			// ������ CCW�� �׸���.

	
	D3DXCOLOR	LgtAmbt( 0.05f,0.05f,0.05f, 1.0f);	// Ambient Lighting Color


	D3DXVECTOR4	LgtPos0( 1.0f, 1.0f,  1.0f, 0.0f);	// Lighting Direction
	D3DXCOLOR	LgtCol0( 1.0f, 0.0f,  0.0f, 1.0f);	// Lighting Color

	D3DXVECTOR4	LgtPos1(-1.0f, 1.0f,  1.0f, 0.0f);	// Lighting Direction
	D3DXCOLOR	LgtCol1( 0.0f, 0.0f,  1.0f, 1.0f);	// Lighting Color

	D3DXVECTOR4	LgtPos2(-1.0f,-1.0f,  1.0f, 0.0f);	// Lighting Direction
	D3DXCOLOR	LgtCol2( 0.0f, 1.0f,  0.0f, 1.0f);	// Lighting Color

	D3DXCOLOR	MtlCol( 1.0f, 1.0f, 1.0f, 1.0f);	// Material Color

	// Setup Lighting
	glLightfv(GL_LIGHT0, GL_AMBIENT,  (GLfloat*)LgtAmbt);	// Ambient Element
	glLightfv(GL_LIGHT0, GL_DIFFUSE,  (GLfloat*)LgtCol0);	// Diffuse Element
	glLightfv(GL_LIGHT0, GL_POSITION, (GLfloat*)LgtPos0);	// Lighting Position(or Direction)

	glLightfv(GL_LIGHT1, GL_AMBIENT,  (GLfloat*)LgtAmbt);	// Ambient Element
	glLightfv(GL_LIGHT1, GL_DIFFUSE,  (GLfloat*)LgtCol1);	// Diffuse Element
	glLightfv(GL_LIGHT1, GL_POSITION, (GLfloat*)LgtPos1);	// Lighting Position(or Direction)

	glLightfv(GL_LIGHT2, GL_AMBIENT,  (GLfloat*)LgtAmbt);	// Ambient Element
	glLightfv(GL_LIGHT2, GL_DIFFUSE,  (GLfloat*)LgtCol2);	// Diffuse Element
	glLightfv(GL_LIGHT2, GL_POSITION, (GLfloat*)LgtPos2);	// Lighting Position(or Direction)


	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, (GLfloat*)MtlCol);

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHT1);
	glEnable(GL_LIGHT2);
	glEnable(GL_COLOR_MATERIAL);


	glColor3f(1.0f, 1.0f, 1.0f);
	DrawModel(&m_mtObj);


	glDisable(GL_COLOR_MATERIAL);
	glDisable(GL_LIGHT0);
	glDisable(GL_LIGHT1);
	glDisable(GL_LIGHT2);
	glDisable(GL_LIGHTING);
}



void CMcScene::DrawModel(D3DXMATRIX* mtWorld)
{
	glPushMatrix();
		glMultMatrixf((FLOAT*)mtWorld);

		glutSolidTorus(2, 4, 20, 40);
	glPopMatrix();
}