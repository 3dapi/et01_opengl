// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_ScnW		= 640;
	m_ScnH		= 480;

	m_pSprite	= NULL;
	m_pLXFont	= NULL;
	m_pGrid		= NULL;
	m_pCam		= NULL;
	m_pInput	= NULL;

	m_pScene	= NULL;
}


INT CMain::Init()
{
	INT hr =0;
	
	// Create Effect
	hr = LgDev_CreateSprite(NULL, &m_pSprite);
	if(FAILED(hr))
		return -1;

	IGLFont::TFont	hFont(14, FW_BOLD, FALSE, 0, "Arial");
	hr = LgDev_CreateFont(NULL, &m_pLXFont, &hFont);
	if(FAILED(hr))
		return -1;


	hr = LcEnt_CreateCamera(NULL, &m_pCam, this);
	if(FAILED(hr))
		return -1;


	hr = LcEnt_CreateInput(NULL, &m_pInput, m_hWnd);
	if(FAILED(hr))
		return -1;

	hr = LcxObj_Create("Grid", &m_pGrid, this);
	if(FAILED(hr))
		return -1;

	

	m_pScene = new CMcScene;

	if(FAILED(m_pScene->Create()))
		return -1;

	return 0;
}

INT CMain::Destroy()
{
	SAFE_DELETE(	m_pScene	);
	SAFE_DELETE(	m_pLXFont	);
	SAFE_DELETE(	m_pGrid		);
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pSprite	);

	return 0;
}

INT CMain::FrameMove()
{
	SAFE_FRMOV(	m_pInput	);

	LCXVECTOR3	vcDelta = *m_pInput->GetMouseEps();


	FLOAT fCamMoveSpeed = 1.f;
	FLOAT fCamYaw		= -vcDelta.x;
	FLOAT fCamPitch		= vcDelta.y;

	if(m_pInput->KeyPress('W'))					// W
		m_pCam->MoveForward(fCamMoveSpeed);

	if(m_pInput->KeyPress('S'))					// S
		m_pCam->MoveForward(-fCamMoveSpeed);

	if(m_pInput->KeyPress('A'))					// A
		m_pCam->MoveSideward(-fCamMoveSpeed);

	if(m_pInput->KeyPress('D'))					// D
		m_pCam->MoveSideward(fCamMoveSpeed);


	if(m_pInput->BtnPress(1))
		m_pCam->Rotation(fCamYaw, fCamPitch, fCamMoveSpeed*0.1f);


	SAFE_FRMOV(	m_pCam		);
	SAFE_FRMOV(	m_pGrid		);
	SAFE_FRMOV(	m_pScene	);

	return 0;
}

INT CMain::Render()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glEnable(GL_CULL_FACE);
	glFrontFace(GL_CCW);


	m_pCam->TransformProj();
	m_pCam->TransformView();


	SAFE_RENDER(	m_pGrid		);
	SAFE_RENDER(	m_pScene	);


	char	sMsg[128]={0};
	FLOAT	fFPS = this->GetFPS();
	sprintf(sMsg, "������Ʃ���. FPS: %4.f", fFPS);
	m_pLXFont->SetString(sMsg);
	m_pLXFont->DrawTxt(NULL, NULL, 0, &LCXVECTOR2(5, 5), LCXCOLOR(1.0f, 0.0f, 1.f, 1.0f));
	
	glFlush();
	return 0;
}

LRESULT	CMain::MsgProc(HWND hWnd,UINT uMsg,WPARAM wParam, LPARAM lParam)
{
	if(m_pInput )
		m_pInput->MsgProc(hWnd, uMsg, wParam, lParam);
	
	if(WM_KEYDOWN == uMsg)
	{
		if(VK_ESCAPE == wParam)
		{
			SendMessage(hWnd, WM_DESTROY, 0, 0);
			return 0;
		}
	}

	return CApplicationGL::MsgProc(hWnd, uMsg, wParam, lParam);
}
