// Interface for the CApplicationGL class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef _AppGL_H_
#define _AppGL_H_


class CApplicationGL : public IGLDev
{
protected:
	HINSTANCE	m_hInst		;
	HWND		m_hWnd		;
	char		m_sCls[128]	;
	DWORD		m_dWinStyle	;

	INT			m_ScnW		;			// Width
	INT			m_ScnH		;			// Height
	INT			m_ScnX		;			// Screen X
	INT			m_ScnY		;			// Screen Y
	RECT		m_rcWin		;			// WinRect

	INT			m_PxlR		;			// Red Pixel Bit
	INT			m_PxlG		;			// Green Pixel Bit
	INT			m_PxlB		;			// Blue Pixel Bit
	INT			m_PxlA		;			// Alpha Pixel Bit
	INT			m_PxlD		;			// Depth Bit
	INT			m_PxlS		;			// Stencil Bit
	EGLDisplay	m_pEgDsp	;			// Egl Display
	EGLSurface	m_pEgSrf	;			// Egl Surface
	EGLContext	m_pEgCtx	;			// Egl Context


	DOUBLE		m_fElapsed	;			// Total Elapsed Time
	FLOAT		m_fFPS		;
	LCXCOLOR	m_dClear	;			// clear color

	FLOAT		m_TimeLive	;

public:
	CApplicationGL();
	INT		Create();
	INT		Run();

	static CApplicationGL* m_pAppGL;
	static LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);

protected:
	INT		Init3DEnvironment();
	INT		Cleanup3DEnvironment();
	INT		Render3DEnvironment();
	void	UpdateFPS();

	INT		WindowCreate();
	void	WindowResize(INT width, INT height);
	INT		WindowCloseTimer();

	INT		GLCreate();
	INT		GLDestroy();

protected:
	virtual	INT		Init()		{	return 0;	}
	virtual	INT		Destroy()	{	return 0;	}
	virtual	INT		FrameMove()	{	return 0;	}
	virtual	INT		Render()	{	return 0;	}
	virtual	LRESULT	MsgProc(HWND,UINT,WPARAM,LPARAM);
public:
	DOUBLE	GetElapsed()	{	return m_fElapsed;	}
	FLOAT	GetFPS()		{	return m_fFPS;		}

protected:
	LCXMATRIX	m_mtWld;
	LCXMATRIX	m_mtViw;
	LCXMATRIX	m_mtPrj;

public:
	virtual	INT		GetAttribute(INT nAtt, void* p);
	virtual	INT		SetAttribute(INT nAtt, void* p);

};

#endif


