// OpenGL Util functions
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _GLUtil_H_
#define _GLUtil_H_


#define SAFE_FREE(p)         { if(p) { free(p);     (p)=NULL; } }
#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }

#define SAFE_DESTROY(p)		{	if(p)	(p)->Destroy();			}
#define SAFE_INVALIDATE(p)	{	if(p)	(p)->Invalidate();		}
#define SAFE_RENDER(p)		{	if(p)	(p)->Render();			}


#define SAFE_NEWINIT(p, CLASSTYPE)								\
{																\
	if(NULL == (p))												\
	{															\
		p = new CLASSTYPE;										\
																\
		if(!(p))												\
		{														\
			return -1;											\
		}														\
																\
		if(FAILED((p)->Init()))									\
		{														\
			delete p;											\
			p = NULL;											\
			return -1;											\
		}														\
	}															\
}

	
#define SAFE_RESTORE(p)											\
{																\
	if(p)														\
	{															\
		if(FAILED((p)->Restore()))								\
			return -1;											\
	}															\
}



#define SAFE_FRMOV(p)											\
{																\
	if(p)														\
	{															\
		if(FAILED(	(p)->FrameMove()))							\
			return -1;											\
	}															\
}

#define SAFE_FRAMEMOVE(p)										\
{																\
	if(p)														\
	{															\
		if(FAILED(	(p)->FrameMove()))							\
			return -1;											\
	}															\
}


void LcGL_DrawPrimitive(INT mode, INT first, INT nVtx);
void LcGL_DrawIndexedPrimitive(INT mode, INT nFace, const void *indices);
void LcGL_DrawIndexedPrimitiveUP(INT mode, INT nFace, const void *indices,	DWORD dFVF, const void* pVtx, INT dStride);



#endif


