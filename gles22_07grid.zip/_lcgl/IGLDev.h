// Interface for the IGLDev class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _IGLDev_H_
#define _IGLDev_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
	virtual ~CLASS_NAME(){}
#endif


interface IGLDev
{
	LC_CLASS_DESTROYER(	IGLDev	);

	virtual	INT		GetAttribute(INT nAtt, void* p)=0;
	virtual	INT		SetAttribute(INT nAtt, void* p)=0;


	enum	EGLDev
	{
		LPTS_WORLD		= 0x00000100,
		LPTS_VIEW		= 0x00000200,
		LPTS_PROJ		= 0x00000300,
	};
};


#endif