//
//
////////////////////////////////////////////////////////////////////////////////

#if _MSC_VER > 1000
#pragma once
#endif


#ifndef _GLMath_H_
#define _GLMath_H_


#include <math.h>


typedef int					INT;
typedef unsigned char		BYTE;
typedef int					BOOL;
typedef float				FLOAT;
typedef short int			SHORT;
typedef unsigned short int	USHORT;
typedef unsigned short int	WORD;

#if defined(_WIN32)
typedef unsigned long		DWORD;
#else
typedef unsigned int		DWORD;
#endif

typedef int					GFIXED;	// for mobile solution.



#ifndef TRUE
#define TRUE	1
#endif

#ifndef FALSE
#define FALSE	0
#endif

#define LCX_PI				(3.1415926535897932384626433832795f)
#define LCXToRadian(deg)	((deg) * (LCX_PI / 180.f))
#define LCXToDegree(rad)	((rad) * (180.f / LCX_PI))

#define ONE_RADtoDEG		(57.295779513082321f)
#define ONE_DEGtoRAD		(0.0174532925199433f)
#define DEG90toRAD			(1.5707963267948966f)
#define RADtoDEG(p)			( (p)*ONE_RADtoDEG)
#define DEGtoRAD(p)			( (p)*ONE_DEGtoRAD)
#define LC_ROUNDING_DELTA	(0.0001f)

#define FIXED_PRECISION		(16)
#define FIXED_ONE			(1 << FIXED_PRECISION)
#define FIXED_ZERO			(0)

inline GFIXED FixedI(int   v)	{	return v<< FIXED_PRECISION;	};
inline GFIXED FixedF(float v)	{	return GFIXED(v * 65536.f);	}
inline GFIXED FixedD(double v)	{	return GFIXED(v * 65536.);	}


// short type 2D vector
////////////////////////////////////////////////////////////////////////////////

struct LCXVEC2s
{
	union {	struct { SHORT x; SHORT y; };	SHORT m[2];	};

	LCXVEC2s();
	LCXVEC2s(const SHORT* v);
	LCXVEC2s(const LCXVEC2s& v);
	LCXVEC2s(const LCXVEC2s* v);
	LCXVEC2s(SHORT X, SHORT Y);

	operator SHORT*();
	operator const SHORT*() const;
	SHORT& operator[](int n);

	// assignment operators
	LCXVEC2s& operator +=(const LCXVEC2s& v);
	LCXVEC2s& operator -=(const LCXVEC2s& v);
	LCXVEC2s& operator *=(SHORT v);
	LCXVEC2s& operator /=(SHORT v);

	// unary operators
	LCXVEC2s operator +() const;
	LCXVEC2s operator -() const;

	// binary operators
	LCXVEC2s operator +(const LCXVEC2s& v) const;
	LCXVEC2s operator -(const LCXVEC2s& v) const;
	LCXVEC2s operator *(SHORT v) const;
	LCXVEC2s operator /(SHORT v) const;

	friend LCXVEC2s operator *(SHORT f, const LCXVEC2s& v);
	friend LCXVEC2s operator /(SHORT f, const LCXVEC2s& v);

	BOOL operator ==(const LCXVEC2s& v) const;
	BOOL operator !=(const LCXVEC2s& v) const;
};


// short type 3d vector
struct LCXVEC3s
{
	union {	struct { SHORT x; SHORT y; SHORT z; };	SHORT m[3];	};

	LCXVEC3s();
	LCXVEC3s(const SHORT* v);
	LCXVEC3s(const LCXVEC3s& v);
	LCXVEC3s(const LCXVEC3s* v);
	LCXVEC3s(SHORT X, SHORT Y, SHORT Z);

	operator SHORT*();
	operator const SHORT*() const;
	SHORT& operator[](int n);

	// assignment operators
	LCXVEC3s& operator +=(const LCXVEC3s& v);
	LCXVEC3s& operator -=(const LCXVEC3s& v);
	LCXVEC3s& operator *=(SHORT v);
	LCXVEC3s& operator /=(SHORT v);

	// unary operators
	LCXVEC3s operator +() const;
	LCXVEC3s operator -() const;

	// binary operators
	LCXVEC3s operator +(const LCXVEC3s& v) const;
	LCXVEC3s operator -(const LCXVEC3s& v) const;
	LCXVEC3s operator *(SHORT v) const;
	LCXVEC3s operator /(SHORT v) const;

	friend LCXVEC3s operator *(SHORT f, const LCXVEC3s& v);
	friend LCXVEC3s operator /(SHORT f, const LCXVEC3s& v);

	BOOL operator ==(const LCXVEC3s& v) const;
	BOOL operator !=(const LCXVEC3s& v) const;
};


// unsigned short type 3d vector
struct LCXVEC3w
{
	union {	struct { WORD x; WORD y; WORD z; };	WORD m[3];	};

	LCXVEC3w();
	LCXVEC3w(const WORD* v);
	LCXVEC3w(const LCXVEC3w& v);
	LCXVEC3w(const LCXVEC3w* v);
	LCXVEC3w(WORD X, WORD Y, WORD Z);

	operator WORD*();
	operator const WORD*() const;
	WORD& operator[](int n);

	// assignment operators
	LCXVEC3w& operator +=(const LCXVEC3w& v);
	LCXVEC3w& operator -=(const LCXVEC3w& v);
	LCXVEC3w& operator *=(WORD v);
	LCXVEC3w& operator /=(WORD v);

	// unary operators
	LCXVEC3w operator +() const;
	LCXVEC3w operator -() const;

	// binary operators
	LCXVEC3w operator +(const LCXVEC3w& v) const;
	LCXVEC3w operator -(const LCXVEC3w& v) const;
	LCXVEC3w operator *(WORD v) const;
	LCXVEC3w operator /(WORD v) const;

	friend LCXVEC3w operator *(WORD f, const LCXVEC3w& v);
	friend LCXVEC3w operator /(WORD f, const LCXVEC3w& v);

	BOOL operator ==(const LCXVEC3w& v) const;
	BOOL operator !=(const LCXVEC3w& v) const;
};



// int type 2d vector
struct LCXVEC2i
{
	union {	struct { INT x; INT y; };	INT m[2];	};

	LCXVEC2i();
	LCXVEC2i(const INT* v);
	LCXVEC2i(const LCXVEC2i& v);
	LCXVEC2i(const LCXVEC2i* v);
	LCXVEC2i(INT X, INT Y);

	operator INT*();
	operator const INT*() const;
	INT& operator[](int n);

	// assignment operators
	LCXVEC2i& operator +=(const LCXVEC2i& v);
	LCXVEC2i& operator -=(const LCXVEC2i& v);
	LCXVEC2i& operator *=(INT v);
	LCXVEC2i& operator /=(INT v);

	// unary operators
	LCXVEC2i operator +() const;
	LCXVEC2i operator -() const;

	// binary operators
	LCXVEC2i operator +(const LCXVEC2i& v) const;
	LCXVEC2i operator -(const LCXVEC2i& v) const;
	LCXVEC2i operator *(INT v) const;
	LCXVEC2i operator /(INT v) const;

	friend LCXVEC2i operator *(INT f, const LCXVEC2i& v);
	friend LCXVEC2i operator /(INT f, const LCXVEC2i& v);

	BOOL operator ==(const LCXVEC2i& v) const;
	BOOL operator !=(const LCXVEC2i& v) const;
};


// int type 3d vector
struct LCXVEC3i
{
	union {	struct { INT x; INT y; INT z; };	INT m[3];	};

	LCXVEC3i();
	LCXVEC3i(const INT* v);
	LCXVEC3i(const LCXVEC3i& v);
	LCXVEC3i(const LCXVEC3i* v);
	LCXVEC3i(INT X, INT Y, INT Z);

	operator INT*();
	operator const INT*() const;
	INT& operator[](int n);

	// assignment operators
	LCXVEC3i& operator +=(const LCXVEC3i& v);
	LCXVEC3i& operator -=(const LCXVEC3i& v);
	LCXVEC3i& operator *=(INT v);
	LCXVEC3i& operator /=(INT v);

	// unary operators
	LCXVEC3i operator +() const;
	LCXVEC3i operator -() const;

	// binary operators
	LCXVEC3i operator +(const LCXVEC3i& v) const;
	LCXVEC3i operator -(const LCXVEC3i& v) const;
	LCXVEC3i operator *(INT v) const;
	LCXVEC3i operator /(INT v) const;

	friend LCXVEC3i operator *(INT f, const LCXVEC3i& v);
	friend LCXVEC3i operator /(INT f, const LCXVEC3i& v);

	BOOL operator ==(const LCXVEC3i& v) const;
	BOOL operator !=(const LCXVEC3i& v) const;
};


// unsigned int type 3d vector
struct LCXVEC3d
{
	union {	struct { DWORD x; DWORD y; DWORD z; };	DWORD m[3];	};

	LCXVEC3d();
	LCXVEC3d(const DWORD* v);
	LCXVEC3d(const LCXVEC3d& v);
	LCXVEC3d(const LCXVEC3d* v);
	LCXVEC3d(DWORD X, DWORD Y, DWORD Z);

	operator DWORD*();
	operator const DWORD*() const;
	DWORD& operator[](int n);

	// assignment operators
	LCXVEC3d& operator +=(const LCXVEC3d& v);
	LCXVEC3d& operator -=(const LCXVEC3d& v);
	LCXVEC3d& operator *=(DWORD v);
	LCXVEC3d& operator /=(DWORD v);

	// unary operators
	LCXVEC3d operator +() const;
	LCXVEC3d operator -() const;

	// binary operators
	LCXVEC3d operator +(const LCXVEC3d& v) const;
	LCXVEC3d operator -(const LCXVEC3d& v) const;
	LCXVEC3d operator *(DWORD v) const;
	LCXVEC3d operator /(DWORD v) const;

	friend LCXVEC3d operator *(DWORD f, const LCXVEC3d& v);
	friend LCXVEC3d operator /(DWORD f, const LCXVEC3d& v);

	BOOL operator ==(const LCXVEC3d& v) const;
	BOOL operator !=(const LCXVEC3d& v) const;
};


// byte type Color(r,g,b,a)
struct LCXCOLORb
{
	union {	struct { BYTE r; BYTE g; BYTE b; BYTE a; }; BYTE m[4]; };

	LCXCOLORb();
	LCXCOLORb( DWORD argb );
	LCXCOLORb( const BYTE * );
	LCXCOLORb( const LCXCOLORb& );
	LCXCOLORb( BYTE _R, BYTE _G, BYTE _B, BYTE _A );

	// casting
	operator DWORD () const;
	operator BYTE* ();
	operator const BYTE* () const;

	// assignment operators
	LCXCOLORb& operator += ( const LCXCOLORb& );
	LCXCOLORb& operator -= ( const LCXCOLORb& );
	LCXCOLORb& operator *= ( const LCXCOLORb& );
	LCXCOLORb& operator *= ( BYTE );
	LCXCOLORb& operator /= ( BYTE );

	// unary operators
	LCXCOLORb operator + () const;
	LCXCOLORb operator - () const;

	// binary operators
	LCXCOLORb operator + ( const LCXCOLORb& ) const;
	LCXCOLORb operator - ( const LCXCOLORb& ) const;
	LCXCOLORb operator * ( const LCXCOLORb& ) const;
	LCXCOLORb operator * ( BYTE ) const;
	LCXCOLORb operator / ( BYTE ) const;

	friend LCXCOLORb operator * (BYTE, const LCXCOLORb& );

	BOOL operator == ( const LCXCOLORb& ) const;
	BOOL operator != ( const LCXCOLORb& ) const;
};



//The following structures are float type vector, color for 3d in PC,
// or the machine can be applied.
////////////////////////////////////////////////////////////////////////////////


struct LCXVECTOR2
{
	union {	struct { FLOAT x; FLOAT y; };	FLOAT m[2];	};

	LCXVECTOR2();
	LCXVECTOR2(const FLOAT* v);
	LCXVECTOR2(const LCXVECTOR2& v);
	LCXVECTOR2(const LCXVECTOR2* v);
	LCXVECTOR2(FLOAT X, FLOAT Y);

	operator FLOAT*();
	operator const FLOAT*() const;

	FLOAT& operator[](int n);

	// assignment operators
	LCXVECTOR2& operator +=(const LCXVECTOR2& v);
	LCXVECTOR2& operator -=(const LCXVECTOR2& v);
	LCXVECTOR2& operator *=(FLOAT v);
	LCXVECTOR2& operator /=(FLOAT v);

	// unary operators
	LCXVECTOR2 operator +() const;
	LCXVECTOR2 operator -() const;

	// binary operators
	LCXVECTOR2 operator +(const LCXVECTOR2& v) const;
	LCXVECTOR2 operator -(const LCXVECTOR2& v) const;
	LCXVECTOR2 operator *(FLOAT v) const;
	LCXVECTOR2 operator /(FLOAT v) const;

	friend LCXVECTOR2 operator *(FLOAT f, const LCXVECTOR2& v);
	friend LCXVECTOR2 operator /(FLOAT f, const LCXVECTOR2& v);

	BOOL operator ==(const LCXVECTOR2& v) const;
	BOOL operator !=(const LCXVECTOR2& v) const;

	FLOAT operator *(const LCXVECTOR2& v);										// Dot Product
	friend FLOAT operator *(const LCXVECTOR2& v1, const LCXVECTOR2& v2);

	FLOAT operator ^(const LCXVECTOR2& v);										// Cross Product(Z-Value)
	friend FLOAT operator ^(const LCXVECTOR2& v1, const LCXVECTOR2& v2);

	LCXVECTOR2 operator *(const FLOAT* v);										// Transform: vector * Matrix
	friend LCXVECTOR2 operator *(const FLOAT* v1, const LCXVECTOR2& v2);			// Transform: Matrix * vector;

	FLOAT		Length();														// Length
	FLOAT		LengthSq();														// Length Square
	LCXVECTOR2	Normalize();
	LCXVECTOR2	Normalize(const LCXVECTOR2* v);

	FLOAT		Dot(const LCXVECTOR2* v);
	FLOAT		Cross(const LCXVECTOR2* v);
};


struct LCXVECTOR3
{
	union {	struct { FLOAT x; FLOAT y; FLOAT z; };	FLOAT m[3];	};

	LCXVECTOR3();
	LCXVECTOR3(const FLOAT* v);
	LCXVECTOR3(const LCXVECTOR3& v);
	LCXVECTOR3(const LCXVECTOR3* v);
	LCXVECTOR3(FLOAT X, FLOAT Y, FLOAT Z);

	operator FLOAT*();
	operator const FLOAT*() const;

	FLOAT& operator[](int n);

	// assignment operators
	LCXVECTOR3& operator +=(const LCXVECTOR3& v);
	LCXVECTOR3& operator -=(const LCXVECTOR3& v);
	LCXVECTOR3& operator *=(FLOAT v);
	LCXVECTOR3& operator /=(FLOAT v);

	// unary operators
	LCXVECTOR3 operator +() const;
	LCXVECTOR3 operator -() const;

	// binary operators
	LCXVECTOR3 operator +(const LCXVECTOR3& v) const;
	LCXVECTOR3 operator -(const LCXVECTOR3& v) const;
	LCXVECTOR3 operator *(FLOAT v) const;
	LCXVECTOR3 operator /(FLOAT v) const;

	friend LCXVECTOR3 operator *(FLOAT f, const LCXVECTOR3& v);
	friend LCXVECTOR3 operator /(FLOAT f, const LCXVECTOR3& v);

	BOOL operator ==(const LCXVECTOR3& v) const;
	BOOL operator !=(const LCXVECTOR3& v) const;

	FLOAT operator *(const LCXVECTOR3& v);										// Dot Product
	friend FLOAT operator *(const LCXVECTOR3& v1, const LCXVECTOR3& v2);

	LCXVECTOR3 operator ^(const LCXVECTOR3& v);									// Cross Product
	friend LCXVECTOR3 operator ^(const LCXVECTOR3& v1, const LCXVECTOR3& v2);

	LCXVECTOR3 operator *(const FLOAT* v);										// Transform: vector * Matrix
	friend LCXVECTOR3 operator *(const FLOAT* v1, const LCXVECTOR3& v2);		// Transform: Matrix * vector;

	FLOAT		Length();														// Length
	FLOAT		LengthSq();														// Length Square
	LCXVECTOR3	Normalize();
	LCXVECTOR3	Normalize(const LCXVECTOR3* v);

	FLOAT		Dot(const LCXVECTOR3* v);
	LCXVECTOR3	Cross(const LCXVECTOR3* v);
	void		Cross(const LCXVECTOR3* v1, const LCXVECTOR3* v2);
};



struct LCXVECTOR4
{
	union {	struct { FLOAT x; FLOAT y; FLOAT z; FLOAT w; };	FLOAT m[4];	};

	LCXVECTOR4();
	LCXVECTOR4(const FLOAT* v);
	LCXVECTOR4(const LCXVECTOR4& v);
	LCXVECTOR4(const LCXVECTOR4* v);
	LCXVECTOR4(FLOAT X, FLOAT Y, FLOAT Z, FLOAT W);

	operator FLOAT*();
	operator const FLOAT*() const;

	FLOAT& operator[](int n);

	// assignment operators
	LCXVECTOR4& operator +=(const LCXVECTOR4& v);
	LCXVECTOR4& operator -=(const LCXVECTOR4& v);
	LCXVECTOR4& operator *=(FLOAT v);
	LCXVECTOR4& operator /=(FLOAT v);

	// unary operators
	LCXVECTOR4 operator +() const;
	LCXVECTOR4 operator -() const;

	// binary operators
	LCXVECTOR4 operator +(const LCXVECTOR4& v) const;
	LCXVECTOR4 operator -(const LCXVECTOR4& v) const;
	LCXVECTOR4 operator *(FLOAT v) const;
	LCXVECTOR4 operator /(FLOAT v) const;

	friend LCXVECTOR4 operator *(FLOAT f, const LCXVECTOR4& v);
	friend LCXVECTOR4 operator /(FLOAT f, const LCXVECTOR4& v);

	BOOL operator ==(const LCXVECTOR4& v) const;
	BOOL operator !=(const LCXVECTOR4& v) const;

	FLOAT operator *(const LCXVECTOR4& v);										// Dot Product
	friend FLOAT operator *(const LCXVECTOR4& v1, const LCXVECTOR4& v2);

	LCXVECTOR4 operator *(const FLOAT* v);										// Transform: vector * Matrix
	friend LCXVECTOR4 operator *(const FLOAT* v1, const LCXVECTOR4& v2);		// Transform: Matrix * vector;

	FLOAT		Length();														// Length
	FLOAT		LengthSq();														// Length Square
	LCXVECTOR4	Normalize();
	LCXVECTOR4	Normalize(const LCXVECTOR4* v);

	FLOAT		Dot(const LCXVECTOR4* v);
};



struct LCXMATRIX
{
	union
	{
		struct
		{
			FLOAT _11, _12, _13, _14;
			FLOAT _21, _22, _23, _24;
			FLOAT _31, _32, _33, _34;
			FLOAT _41, _42, _43, _44;

		};
		FLOAT m[4][4];
	};

	LCXMATRIX();
	LCXMATRIX(const FLOAT* v);
	LCXMATRIX(const LCXMATRIX& v);
	LCXMATRIX(	FLOAT v11, FLOAT v12, FLOAT v13, FLOAT v14,
				FLOAT v21, FLOAT v22, FLOAT v23, FLOAT v24,
				FLOAT v31, FLOAT v32, FLOAT v33, FLOAT v34,
				FLOAT v41, FLOAT v42, FLOAT v43, FLOAT v44 );


	// access grants
	FLOAT& operator () ( int iRow, int iCol );
	FLOAT  operator () ( int iRow, int iCol ) const;

	// casting operators
	operator FLOAT* ();
	operator const FLOAT* () const;

	// assignment operators
	LCXMATRIX& operator *= (const LCXMATRIX& v);
	LCXMATRIX& operator += (const LCXMATRIX& v);
	LCXMATRIX& operator -= (const LCXMATRIX& v);
	LCXMATRIX& operator *= ( FLOAT v);
	LCXMATRIX& operator /= ( FLOAT v);

	LCXMATRIX operator +() const;												// unary operators
	LCXMATRIX operator -() const;

	LCXMATRIX operator * (const LCXMATRIX& v) const;
	LCXMATRIX operator + (const LCXMATRIX& v) const;
	LCXMATRIX operator - (const LCXMATRIX& v) const;
	LCXMATRIX operator * ( FLOAT v) const;
	LCXMATRIX operator / ( FLOAT v) const;


	friend LCXMATRIX operator * (FLOAT f, const LCXMATRIX& v);


	BOOL operator == (const LCXMATRIX& v) const;
	BOOL operator != (const LCXMATRIX& v) const;

	LCXMATRIX	Multiple(const LCXMATRIX* v) const;
	LCXMATRIX&	Identity();
	LCXMATRIX&	Transpose();
	LCXMATRIX&	Transpose(const LCXMATRIX* v);
	LCXMATRIX&	Inverse(INT nQuick=TRUE);
	LCXMATRIX&	Inverse(const LCXMATRIX* v, INT nQuick=TRUE);					// nQuick=TRUE is _14 or _24 or _34 is not zero
	FLOAT		Determinant();

	LCXMATRIX&	SetupScaling(FLOAT X, FLOAT Y, FLOAT Z);
	LCXMATRIX&	SetupViewLH(const LCXVECTOR3* vEye, const LCXVECTOR3* vLook, const LCXVECTOR3* vUp );
	LCXMATRIX&	SetupViewRH(const LCXVECTOR3* vEye, const LCXVECTOR3* vLook, const LCXVECTOR3* vUp );
	LCXMATRIX&	SetupPerspectiveLH(FLOAT fFOV, FLOAT fAspect, FLOAT fNear, FLOAT fFar);
	LCXMATRIX&	SetupPerspectiveRH(FLOAT fFOV, FLOAT fAspect, FLOAT fNear, FLOAT fFar);
	LCXMATRIX&	SetupPerspectiveGL(FLOAT fFOV, FLOAT fAspect, FLOAT fNear, FLOAT fFar);
	LCXMATRIX&	SetupRotationX(FLOAT fRad);
	LCXMATRIX&	SetupRotationY(FLOAT fRad);
	LCXMATRIX&	SetupRotationZ(FLOAT fRad);
	LCXMATRIX&	SetupRotationAxis(const LCXVECTOR3* vAxis, FLOAT fRad);
	LCXMATRIX&	SetupTranslation(const LCXVECTOR3* vTrs, BOOL bInit=TRUE);

	void		TransformCoord(LCXVECTOR3* p);
	void		TransformCoord(LCXVECTOR3* pOut, const LCXVECTOR3* pIn);
};






struct LCXQUATERNION
{
	union {	struct { FLOAT x; FLOAT y; FLOAT z;	 FLOAT w; }; FLOAT m[4]; };

	LCXQUATERNION();
	LCXQUATERNION( const FLOAT * );
	LCXQUATERNION( const LCXQUATERNION& );
	LCXQUATERNION( FLOAT x, FLOAT y, FLOAT z, FLOAT w );

	// casting
	operator FLOAT* ();
	operator const FLOAT* () const;

	// assignment operators
	LCXQUATERNION& operator += ( const LCXQUATERNION& );
	LCXQUATERNION& operator -= ( const LCXQUATERNION& );
	LCXQUATERNION& operator *= ( const LCXQUATERNION& );
	LCXQUATERNION& operator *= ( FLOAT );
	LCXQUATERNION& operator /= ( FLOAT );

	// unary operators
	LCXQUATERNION  operator + () const;
	LCXQUATERNION  operator - () const;

	// binary operators
	LCXQUATERNION operator + ( const LCXQUATERNION& ) const;
	LCXQUATERNION operator - ( const LCXQUATERNION& ) const;
	LCXQUATERNION operator * ( const LCXQUATERNION& ) const;
	LCXQUATERNION operator * ( FLOAT ) const;
	LCXQUATERNION operator / ( FLOAT ) const;

	friend LCXQUATERNION operator * (FLOAT, const LCXQUATERNION& );


	BOOL operator == ( const LCXQUATERNION& ) const;
	BOOL operator != ( const LCXQUATERNION& ) const;

	LCXQUATERNION	Multiple(const LCXQUATERNION* v) const;
	void SLerp(const LCXQUATERNION* q1, const LCXQUATERNION* q2, FLOAT t);
	void RotationMatrix(LCXMATRIX* pOut, BOOL bDX=TRUE);
};


// Planes
struct LCXPLANE
{
	union {	struct { FLOAT a; FLOAT b; FLOAT c;	 FLOAT d; }; FLOAT m[4]; };

	LCXPLANE();
	LCXPLANE( const FLOAT* );
	LCXPLANE( const LCXPLANE& );
	LCXPLANE( FLOAT a, FLOAT b, FLOAT c, FLOAT d );

	// casting
	operator FLOAT* ();
	operator const FLOAT* () const;

	// unary operators
	LCXPLANE operator + () const;
	LCXPLANE operator - () const;

	// binary operators
	BOOL operator == ( const LCXPLANE& ) const;
	BOOL operator != ( const LCXPLANE& ) const;

	void SetupFromPointNormal(const LCXVECTOR3* point, const LCXVECTOR3* normal);
	void SetupFromPoints(const LCXVECTOR3* p0, const LCXVECTOR3* p1, const LCXVECTOR3* p2);
};



// Colors
struct LCXCOLOR
{
	union {	struct { FLOAT r; FLOAT g; FLOAT b;	 FLOAT a; }; FLOAT m[4]; };

	LCXCOLOR();
	LCXCOLOR( DWORD argb );
	LCXCOLOR( const FLOAT * );
	LCXCOLOR( const LCXCOLOR& );
	LCXCOLOR( FLOAT r, FLOAT g, FLOAT b, FLOAT a );

	// casting
	operator DWORD () const;

	operator FLOAT* ();
	operator const FLOAT* () const;

	// assignment operators
	LCXCOLOR& operator += ( const LCXCOLOR& );
	LCXCOLOR& operator -= ( const LCXCOLOR& );
	LCXCOLOR& operator *= ( FLOAT );
	LCXCOLOR& operator /= ( FLOAT );

	// unary operators
	LCXCOLOR operator + () const;
	LCXCOLOR operator - () const;

	// binary operators
	LCXCOLOR operator + ( const LCXCOLOR& ) const;
	LCXCOLOR operator - ( const LCXCOLOR& ) const;
	LCXCOLOR operator * ( const LCXCOLOR& ) const;
	LCXCOLOR operator * ( FLOAT ) const;
	LCXCOLOR operator / ( FLOAT ) const;

	friend LCXCOLOR operator * (FLOAT, const LCXCOLOR& );

	BOOL operator == ( const LCXCOLOR& ) const;
	BOOL operator != ( const LCXCOLOR& ) const;
};



FLOAT LCXVec3Dot(const LCXVECTOR3* p1, const LCXVECTOR3* p2);
FLOAT LCXVec3Length(const LCXVECTOR3* v);
FLOAT LCXPlaneDotCoord(const LCXPLANE *pP, const LCXVECTOR3 *pV);



#endif



