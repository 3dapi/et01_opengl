// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pEft	= NULL;
	m_pTex	= NULL;
}


CMcScene::~CMcScene()
{
	Destroy();
}


void CMcScene::Destroy()
{
	SAFE_DELETE(	m_pEft	);
	SAFE_DELETE(	m_pTex	);
}


INT CMcScene::Create()
{
	INT hr =0;

	// Create Effect
	hr = LgDev_CreateEffect("File", &m_pEft, "shaders/vertex.glsl", "shaders/fragment.glsl", "att_pos");

	if(FAILED(hr))
		return -1;

	m_pEft->BindAttribLocation("att_pos", 0);
	m_pEft->BindAttribLocation("att_col", 1);
	m_pEft->BindAttribLocation("att_tex", 2);


	hr = LgDev_CreateTexture(NULL, &m_pTex, "texture/Fieldstone.tga", NULL, 0x00FFFFFF, 0);

	if(FAILED(hr))
		return -1;

	return 0;
}


INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	LCXVEC2i	s_pos[4];
	LCXCOLORb	s_col[4];
	LCXVEC2i	s_tex[4];

	s_pos[0] = LCXVEC2i(FixedD(-1.0f), FixedD(-1.0f) );
	s_pos[1] = LCXVEC2i(FixedD( 1.0f), FixedD(-1.0f) );
	s_pos[2] = LCXVEC2i(FixedD( 1.0f), FixedD( 1.0f) ); 
	s_pos[3] = LCXVEC2i(FixedD(-1.0f), FixedD( 1.0f) ); 

	s_col[0] = LCXCOLORb( LCXCOLOR(1.0F, 0.0F, 0.0F, 1.0F) );
	s_col[1] = LCXCOLORb( LCXCOLOR(0.0F, 1.0F, 0.0F, 1.0F) );
	s_col[2] = LCXCOLORb( LCXCOLOR(0.0F, 0.0F, 1.0F, 1.0F) );
	s_col[3] = LCXCOLORb( LCXCOLOR(1.0F, 0.0F, 1.0F, 1.0F) );


	s_tex[0] = LCXVEC2i(FixedD( 0.0f), FixedD( 0.0f) );
	s_tex[1] = LCXVEC2i(FixedD( 1.0f), FixedD( 0.0f) );
	s_tex[2] = LCXVEC2i(FixedD( 1.0f), FixedD( 1.0f) ); 
	s_tex[3] = LCXVEC2i(FixedD( 0.0f), FixedD( 1.0f) ); 


	m_pEft->Begin();

	m_pEft->SetVertexAttrib(0, 2, GL_FIXED,			GL_TRUE, 0, s_pos);		// FLOAT: GL_FALSE
	m_pEft->SetVertexAttrib(1, 4, GL_UNSIGNED_BYTE, GL_TRUE, 0, s_col);		// INTEGER: GL_TRUE
	m_pEft->SetVertexAttrib(2, 2, GL_FIXED,			GL_TRUE, 0, s_tex);


	GLuint	eProg = m_pEft->GetProgram();
	GLuint	nName = m_pTex->GetName();
	INT		nStage= 0;

	int		nSamp = glGetUniformLocation(eProg, "sampler");


	glActiveTexture(GL_TEXTURE0 + nStage);
	glBindTexture(GL_TEXTURE_2D, nName );

	glUniform1i(nSamp, nStage);
	glDrawArrays(GL_TRIANGLE_FAN, 0, 4);

	glBindTexture(GL_TEXTURE_2D, 0);

	
	m_pEft->End();
}




