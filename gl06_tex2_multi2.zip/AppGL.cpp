// Implementation of the CApplicationGL class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>

#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/GLAux.h>

#include "AppGL.h"


CApplicationGL* CApplicationGL::m_pAppGL = NULL;
	
CApplicationGL::CApplicationGL()
{
	CApplicationGL::m_pAppGL	 = this;

	m_hInst	= NULL;
	m_hWnd	= NULL;
	m_hDC	= NULL;
	m_ScnW	= 640;
	m_ScnH	= 480;
	
	memset(m_sCls, 0, sizeof(m_sCls));
	strcpy(m_sCls, "LxAppGL");

	
	m_hRC	= NULL;
}


INT CApplicationGL::Create(HINSTANCE)
{
	m_hInst = (HINSTANCE)::GetModuleHandle(NULL);

	WNDCLASS wc =
	{
		CS_CLASSDC
			, WndProc
			, 0
			, 0
			, m_hInst
			, LoadIcon(NULL, IDI_APPLICATION)
			, LoadCursor(NULL,IDC_ARROW)
			, (HBRUSH)GetStockObject(WHITE_BRUSH)
			, NULL
			, m_sCls
	};

	if( 0==	::RegisterClass(&wc))
		return -1;


	DWORD dStyle = WS_OVERLAPPED| WS_CAPTION|WS_SYSMENU|WS_VISIBLE;

	RECT rc;
	
	::SetRect( &rc, 0, 0, m_ScnW, m_ScnH);
	::AdjustWindowRect( &rc, dStyle, FALSE );

	INT iScnSysW = ::GetSystemMetrics(SM_CXSCREEN);
	INT iScnSysH = ::GetSystemMetrics(SM_CYSCREEN);
	INT ScnX	= (iScnSysW - (rc.right-rc.left))/2;
	INT	ScnY	= (iScnSysH - (rc.bottom-rc.top))/2;

	m_hWnd = ::CreateWindow( m_sCls, m_sCls
					, dStyle
					, ScnX
					, ScnY
					, (rc.right-rc.left)
					, (rc.bottom-rc.top)
					, GetDesktopWindow()
					, NULL
					, m_hInst
					, NULL );

	if(!m_hWnd)
		return -1;


	::ShowWindow( m_hWnd, SW_SHOWNORMAL );
	::UpdateWindow( m_hWnd );
	::ShowCursor(TRUE);



	if(FAILED(GLCreate()))
		return -1;


	glClearColor( 0.9f, 1.0f, 1.0f, 1.0f);
//	glClearColor( 0.f, 0.f, 0.f, 1.0f);

	if(FAILED(Init()))
		return -1;

	return 0;
}



INT CApplicationGL::Cleanup()
{
	Destroy();
	GLDestroy();

	return 0;
}


INT CApplicationGL::Run()
{
	MSG	msg={0};
	while(WM_QUIT != msg.message)
	{
		if(PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
			Render3D();
	}

	Cleanup();
	UnregisterClass(m_sCls, m_hInst);

	return 0;
}



INT CApplicationGL::Render3D()
{
	INT hr =0;

	hr  = FrameMove();

	if(FAILED(hr))
	{
		SendMessage(m_hWnd, WM_DESTROY, 0, 0);
		return 0;
	}

	hr = Render();

	if(FAILED(hr))
	{
		SendMessage(m_hWnd, WM_DESTROY, 0, 0);
		return 0;
	}

	hr = SwapBuffers(m_hDC);

	return hr;
}


INT CApplicationGL::GLCreate()
{
	m_hDC = GetDC(m_hWnd);

	PIXELFORMATDESCRIPTOR pfd = {0};
	pfd.nSize		= sizeof(PIXELFORMATDESCRIPTOR);
	pfd.nVersion	= 1;
	pfd.dwFlags		= PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL |PFD_DOUBLEBUFFER;	//|PFD_GENERIC_ACCELERATED;
	pfd.iPixelType	= PFD_TYPE_RGBA;
	pfd.cColorBits	= 32;
	pfd.cDepthBits	= 24;
	pfd.cStencilBits=  8;
	pfd.iLayerType	= PFD_MAIN_PLANE;


	UINT PixelFormat = ChoosePixelFormat(m_hDC, &pfd);

	if(0 == PixelFormat)
		return -1;

	if(0 == SetPixelFormat(m_hDC, PixelFormat,&pfd))
		return -1;


	m_hRC = wglCreateContext(m_hDC);
	if(NULL == m_hRC)
		return -1;


	if(0 == wglMakeCurrent(m_hDC, m_hRC))
		return -1;

	return 0;
}


INT CApplicationGL::GLDestroy()
{
	if(m_hDC)
	{
		wglMakeCurrent(m_hDC, NULL);
		wglDeleteContext(m_hRC);

		ReleaseDC(m_hWnd, m_hDC);
		m_hDC = NULL;
	}

	return 0;
}


LRESULT CALLBACK CApplicationGL::WndProc(HWND hWnd,UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(CApplicationGL::m_pAppGL)
		return CApplicationGL::m_pAppGL->MsgProc(hWnd, uMsg, wParam, lParam);

	return ::DefWindowProc(hWnd, uMsg, wParam, lParam);
}


LRESULT CApplicationGL::MsgProc(HWND hWnd,UINT uMsg,WPARAM wParam, LPARAM lParam)
{
	if(WM_DESTROY == uMsg)
	{
		PostQuitMessage(0);
		return 0;
	}

	return DefWindowProc(hWnd, uMsg, wParam, lParam);
}




