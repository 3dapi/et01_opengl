// Implementation of the CGLEffect class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include "GLES2/gl2.h"
#include "GLES2/gl2ext.h"
#include "EGL/egl.h"

#include "IGLEffect.h"


class CGLEffect : public IGLEffect
{
public:
	struct Teffect
	{
		char*	StrVtx;
		char*	StrFrg;
		char*	FileVtx;
		char*	FileFrg;
		Teffect(char* s1, char *s2, char* f1=NULL, char*f2=NULL) : StrVtx(s1), StrFrg(s2), FileVtx(f1), FileFrg(f2){}
	};

protected:
	GLuint	m_eProg;

public:
	CGLEffect();
	virtual ~CGLEffect();

	virtual	INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual	void	Destroy();

	virtual	INT		Begin();
	virtual	INT		End();

	virtual	INT		BindAttribLocation(char* attName, INT nIndex);
	virtual	INT		SetVertexAttrib(INT indx, INT size=0, INT type=0, INT normalized=0, INT stride=0, const void* ptr=0);

protected:
	INT		CompileShader(GLenum nType, const char*, INT iLen);
	INT		CompileShaderFromTextFile(GLenum nType, const char* sFile);
	char*	LoadFile(const char* filepath, INT* len);
};



CGLEffect::CGLEffect()
{
	m_eProg = 0;
}


CGLEffect::~CGLEffect()
{
	Destroy();
}


void CGLEffect::Destroy()
{
	if(m_eProg)
	{
		glDeleteProgram(m_eProg);
		m_eProg	= 0;
	}
}

INT CGLEffect::Create(void* p1, void* p2, void* p3, void* p4)
{
	INT			hr = 0;
	CGLEffect::Teffect*	teff = (CGLEffect::Teffect*)p1;
	char*		sBindAttLoc= (char* )p2;

	GLuint		ShaderVtx = 0;
	GLuint		ShaderFrg = 0;
	const char* sSrc = 0;
	INT			iLen = 0;


	if(teff->StrVtx)
	{
		sSrc = (const char*)teff->StrVtx;
		iLen = strlen(sSrc);
		hr = CompileShader(GL_VERTEX_SHADER, sSrc, iLen);
		if(FAILED(hr))
			return -1;

		ShaderVtx = hr;
	}
	else if(teff->FileVtx)
	{
		sSrc = (const char*)teff->FileVtx;
		hr = CompileShaderFromTextFile(GL_VERTEX_SHADER, sSrc);
		if(FAILED(hr))
			return -1;

		ShaderVtx = hr;
	}

	if(teff->StrFrg)
	{
		sSrc = (const char*)teff->StrFrg;
		iLen = strlen(sSrc);
		hr = CompileShader(GL_FRAGMENT_SHADER, sSrc, iLen);
		if(FAILED(hr))
			return -1;

		ShaderFrg = hr;
	}
	else if(teff->FileFrg)
	{
		sSrc = (const char*)teff->FileFrg;
		hr = CompileShaderFromTextFile(GL_FRAGMENT_SHADER, sSrc);
		if(FAILED(hr))
			return -1;

		ShaderFrg = hr;
	}


	// Create Program Object
	m_eProg = glCreateProgram();

	if(0 == m_eProg)
		return -1;


	// Attach
	glAttachShader(m_eProg, ShaderVtx);
	glAttachShader(m_eProg, ShaderFrg);


	// Setup Position Attribute
	glBindAttribLocation(m_eProg, 0, sBindAttLoc);


	// Linking
	glLinkProgram(m_eProg);
	glGetProgramiv(m_eProg, GL_LINK_STATUS, &hr);
	if(!hr) 
	{
		printf("Couldn't link shader! Exiting...\n");
		return -1;
	}

	return 0;
}


INT CGLEffect::Begin()
{
	glUseProgram(m_eProg);
	return 0;
}


INT CGLEffect::End()
{
	glDisableVertexAttribArray(0);
	glDisableVertexAttribArray(1);
	glDisableVertexAttribArray(2);
	glDisableVertexAttribArray(3);
	glDisableVertexAttribArray(4);
	glDisableVertexAttribArray(5);
	glDisableVertexAttribArray(6);
	glDisableVertexAttribArray(7);

	glUseProgram(0);
	return 0;
}


INT	CGLEffect::BindAttribLocation(char* attName, INT nIndex)
{
	glBindAttribLocation(m_eProg, nIndex, attName);
	
	return 0;
}


INT CGLEffect::SetVertexAttrib(INT indx, INT size/* =0 */, INT type/* =0 */, INT normalized/* =0 */, INT stride/* =0 */, const void* ptr/* =0 */)
{
	char*	pVtx = (char*)ptr;

	if(!size || !pVtx)
	{
		glDisableVertexAttribArray(indx);
	}
	else
	{
		glEnableVertexAttribArray(indx);
		glVertexAttribPointer(indx, size, type, normalized, stride, pVtx);		
	}

	return 0;
}




INT CGLEffect::CompileShader(GLenum nType, const char* sSrc, INT iLen)
{
	INT		hr		= 0;
	GLuint	Shader	= 0;

	// Create Shader
	Shader = glCreateShader(nType);
	if(0 == Shader)
	{
		printf("Couldn't Create Shader.\n\n");
		return -1;
	}

	glShaderSource(Shader, 1, (const char**)&sSrc, &iLen);
	glCompileShader(Shader);
	glGetShaderiv(Shader, GL_COMPILE_STATUS, &hr);
	if(!hr) 
	{
		glGetShaderiv(Shader, GL_INFO_LOG_LENGTH, &hr);
		
		char* sLog = (char*)malloc (sizeof(char) * (hr+4) );
		memset(sLog, 0, hr+4);

		glGetShaderInfoLog (Shader, hr, NULL, sLog );
		printf("Compile Shader Failed: %s.\n\n", sLog);
		free(sLog);

		return -1;
	}

	return Shader;
}



INT CGLEffect::CompileShaderFromTextFile(GLenum nType, const char* sFile)
{
	INT		hr	 = 0;
	INT		iLen = 0;
	char*	sSrc = LoadFile(sFile, &iLen);

	if (NULL == sSrc)
		return -1;

	hr  = CompileShader(nType, sSrc, iLen);
	delete[] sSrc;

	return hr;
}



char* CGLEffect::LoadFile(const char* filepath, INT* len)
{
	FILE* fp = ::fopen(filepath, "rb");

	if(NULL == fp)
		return NULL;

	::fseek(fp, 0, SEEK_END);
	
	long lFile = ::ftell(fp);

	::fseek(fp, 0, SEEK_SET);

	*len = INT( (lFile+3)/4) * 4;

	char *data = new char[*len];
	::memset(data, 0, *len);
	::fread(data, sizeof(char), lFile, fp);
	::fclose(fp);

	return data;
}




INT LgDev_CreateEffect(char* sCmd
					, IGLEffect** pData
					, void* p1			// Vertex Shader Source
					, void* p2			// Fragment Shader Source
					, void* p3			// Bind Positon Attrib Location
					, void* p4			// No Use
					)
{
	*pData = NULL;

	CGLEffect*			pObj = NULL;
	CGLEffect::Teffect	teff(NULL, NULL);

	if(0==_stricmp("String", sCmd))
	{
		teff = CGLEffect::Teffect((char*)p1, (char*)p2, NULL, NULL);
	}
	else if(0==_stricmp("File", sCmd))
	{
		teff = CGLEffect::Teffect(NULL, NULL, (char*)p1, (char*)p2);
	}
	else
		return -1;


	pObj = new CGLEffect;
	if(FAILED(pObj->Create(&teff, p3)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}