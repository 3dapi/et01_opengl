// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
}


INT CMain::Init()
{
	INT hr =0;

	return 0;
}

INT CMain::Destroy()
{
	return 0;
}

INT CMain::FrameMove()
{
	return 0;
}

INT CMain::Render()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glEnable(GL_CULL_FACE);
	glFrontFace(GL_CCW);

	
	glFlush();
	return 0;
}

LRESULT	CMain::MsgProc(HWND hWnd,UINT uMsg,WPARAM wParam, LPARAM lParam)
{
	if(WM_KEYDOWN == uMsg)
	{
		if(VK_ESCAPE == wParam)
		{
			SendMessage(hWnd, WM_DESTROY, 0, 0);
			return 0;
		}
	}

	return CApplicationGL::MsgProc(hWnd, uMsg, wParam, lParam);
}
