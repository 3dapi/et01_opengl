// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef _Main_H_
#define _Main_H_


class CMain : public CApplicationGL
{
protected:


public:
	CMain();

protected:
	virtual	INT		Init();
	virtual	INT		Destroy();
	virtual	INT		FrameMove();
	virtual	INT		Render();
	virtual	LRESULT	MsgProc(HWND,UINT,WPARAM,LPARAM);
};


extern CMain*	g_pApp;
#define GMAIN	g_pApp

#endif

