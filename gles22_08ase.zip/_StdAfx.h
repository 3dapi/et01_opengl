//
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef __StdAfx_H_
#define __StdAfx_H_


#pragma warning(disable: 4996)
#pragma warning(disable: 4018)

#pragma comment(linker, "/subsystem:console")

#pragma comment(lib, "libEGL.lib")
#pragma comment(lib, "libGLESv2.lib")


#ifdef NDEBUG
#pragma comment(lib, "./_pnglib/lib/zlib123.lib")
#pragma comment(lib, "./_pnglib/lib/png124.lib")
#else
#pragma comment(lib, "./_pnglib/lib/zlib123_.lib")
#pragma comment(lib, "./_pnglib/lib/png124_.lib")
#endif



#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "GLES2/gl2.h"
#include "GLES2/gl2ext.h"
#include "EGL/egl.h"

#include "_lcgl/GLMath.h"
#include "_lcgl/IGLDev.h"
#include "_lcgl/IGLEffect.h"
#include "_lcgl/IGLImage.h"
#include "_lcgl/IGLTexture.h"
#include "_lcgl/IGLSprite.h"
#include "_lcgl/IGLFont.h"
#include "_lcgl/GLUtil.h"

#include "_lcx/ILcCam.h"
#include "_lcx/ILcInput.h"
#include "_lcx/ILcxObj.h"

#include "_lcm/ILcMdl.h"

#include "AppGL.h"


#include "McScene.h"



#include "Main.h"

#endif


