

#include "_StdAfx.h"


void LcUtil_SetCurrentDirectory();


CMain*	g_pApp = NULL;


//int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd )
int main(int argc, char* argv[])
{
	LcUtil_SetCurrentDirectory();

	CMain AppMain;
	g_pApp = &AppMain;

	if(FAILED(AppMain.Create()))
		return 0;

	return AppMain.Run();
}


void LcUtil_SetCurrentDirectory()
{
	CHAR	sExe1[MAX_PATH]={0};
	CHAR	sExe2[MAX_PATH]={0};

	memset(sExe1, 0, sizeof(sExe1));
	memset(sExe2, 0, sizeof(sExe2));

	strcpy(sExe1, GetCommandLine());

	INT	iLen = strlen(sExe1);

	int k=0;

	for(INT i=0; i<iLen; ++i)
	{
		if('"' == sExe1[i])
		{
			++k;
			continue;
		}

		if(2==k)
			break;

		sExe2[i-k] = sExe1[i];
		if('\\' == sExe2[i-k])
			sExe2[i-k] ='/';
	}

	char*pdest;
	
	pdest = strrchr(sExe2, '/');

	int result;
	result = pdest - sExe2;

	sExe2[result] =0;

	BOOL hr = SetCurrentDirectory(sExe2);
}

