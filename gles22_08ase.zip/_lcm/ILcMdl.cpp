// Implementation of the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////


#include <stdio.h>
#include <windows.h>

#include "GLES2/gl2.h"

#include "../_lcgl/GLMath.h"
#include "../_lcgl/IGLDev.h"
#include "../_lcgl/IGLEffect.h"
#include "../_lcgl/IGLTexture.h"

#include "ILcMdl.h"
#include "LcAse.h"
#include "LcAseIns.h"

#include "LcAsg.h"
#include "LcAsgIns.h"



INT LcMdl_CreateAse(char* sCmd
				 , ILcMdl** pData		// Output data
				 , void* pDev			// Device
				 , void* sName			// Model File Name
				 , void* pOriginal		// Original ILcMdl Pointer for Clone Creating
				 , void* p4				// Not Use
				 , void* p5				// Not Use
				 )
{
	ILcMdl*	p= NULL;
	*pData	= NULL;

	if(NULL==sCmd)
		return -1;


	if(0==_stricmp(sCmd, "Ase Text PC"))
	{
		if(sName && !pOriginal)
		{
//			char*	sFile = (char*)sName;
//			char drive[_MAX_DRIVE]={0};
//			char dir[_MAX_DIR]={0};
//			char fname[_MAX_FNAME]={0};
//			char ext[_MAX_EXT]={0};
//
//			_splitpath( sFile, drive, dir, fname, ext );

			p= new CLcAse;

			if(FAILED(p->Create(pDev, sName)))
			{
				delete p;
				return -1;
			}
		}
		else
		{
			p= new CLcAseIns;

			if(FAILED(p->Create(pOriginal)))
			{
				delete p;
				return -1;
			}
		}
	}
	
	else if(0==_stricmp(sCmd, "Ase Bin PC"))
	{
		if(sName && !pOriginal)
		{
			p= new CLcAsg;

			if(FAILED(p->Create(pDev, sName)))
			{
				delete p;
				return -1;
			}
		}
		else
		{
			p= new CLcAsgIns;

			if(FAILED(p->Create(pOriginal)))
			{
				delete p;
				return -1;
			}
		}
	}


	*pData = p;
	
	return 0;
}