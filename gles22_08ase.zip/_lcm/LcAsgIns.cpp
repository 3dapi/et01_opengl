// Implementation of the CLcAsgIns class.
//
////////////////////////////////////////////////////////////////////////////////


#include <stdio.h>
#include <windows.h>

#include "GLES2/gl2.h"

#include "../_lcgl/GLMath.h"
#include "../_lcgl/IGLDev.h"
#include "../_lcgl/IGLEffect.h"
#include "../_lcgl/IGLTexture.h"
#include "../_lcgl/GLUtil.h"

#include "ILcMdl.h"
#include "LcAsg.h"
#include "LcAsgIns.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }


CLcAsgIns::TlinkTm::TlinkTm()
{
	nPrn	= -1;

	mtW.Identity();
	mtL.Identity();
}


CLcAsgIns::CLcAsgIns()
{
	m_nMtl	= 0;
	m_pMtl	= NULL;
	m_nGeo	= 0;
	m_pGeo	= NULL;

	m_pOrg	= NULL;


	m_nFrmF	= 0;
	m_nFrmL	= 0;
	m_nFrmS	= 0;
	m_nFrmT	= 0;

	m_dFrmCur = 0;
	m_dTimeCur= 0;

	m_mtWld.Identity();

	m_pDev	= NULL;
	m_pEft	= NULL;
}

CLcAsgIns::~CLcAsgIns()
{
	Destroy();
}


INT CLcAsgIns::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pOrg	= (CLcAsg*)p1;

	m_nMtl	= m_pOrg->GetNumMtl();
	m_pMtl	= m_pOrg->GetMtrl();

	m_nGeo	= m_pOrg->GetNumGeo();
	m_pGeo	= m_pOrg->GetGeometry();

	m_pDev	= (IGLDev*)m_pOrg->GetDevice();
	m_pEft	= (IGLEffect*)m_pOrg->GetEffect();


	m_pTM = new TlinkTm[m_nGeo]	;	// World and Animation Matrix


	// Original�� ������ ����
	for(INT i=0; i<m_nGeo; ++i)
	{
		m_pTM[i].mtL = m_pGeo[i].mtL;
		m_pTM[i].mtW = m_pGeo[i].mtW;

		m_pTM[i].nPrn= m_pGeo[i].nPrn;
	}


	struct Tscene
	{
		char sVer[16];	INT F; INT L; INT S; INT T;
	} t;

	memcpy(&t, m_pOrg->GetHeader(), sizeof(Tscene));

	m_nFrmF	= t.F;		// First Frame
	m_nFrmL	= t.L;		// Last Frame
	m_nFrmS	= t.S;		// Frame Speed
	m_nFrmT	= t.T;		// Tick per Frame

	return 0;
}


void CLcAsgIns::Destroy()
{
	m_pOrg = NULL;

	SAFE_DELETE_ARRAY(	m_pTM	);
}






INT CLcAsgIns::FrameMove()
{
	INT		i = 0;
	INT		nFrame	=0;

	// Frame = FrameSpeed * Time;
	m_dFrmCur = m_nFrmS * m_dTimeCur;

	nFrame	= INT(m_dFrmCur);

	if(nFrame>= m_nFrmL)
	{
		// ������ �ð��� ����ð����� �����Ѵ�.
		m_dTimeCur = m_dFrmCur - nFrame;
	}

	for(i=0; i<m_nGeo; ++i)
	{
		TlinkTm*	pTM = &m_pTM[i];
		
		m_pOrg->GetAniTrack(&pTM->mtL, i, m_dFrmCur);

		// �θ��� ���� ����� ���� �ڽ��� ���� ����� �ϼ��Ѵ�.
		LCXMATRIX	mtPrn =LCXMATRIX(1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1);

		if(0 <= pTM->nPrn)
			mtPrn	= m_pTM[pTM->nPrn].mtW;

		pTM->mtW = pTM->mtL * mtPrn;
	}


	return 0;
}




void CLcAsgIns::Render()
{
	if(!m_pGeo)
		return;

	INT			i=0;
	LCXMATRIX	mtW;

	LCXMATRIX	mtViw;
	LCXMATRIX	mtPrj;

	m_pDev->GetAttribute(IGLDev::LPTS_VIEW, &mtViw);
	m_pDev->GetAttribute(IGLDev::LPTS_PROJ, &mtPrj);

	m_pEft->Begin();

	m_pEft->SetMatrix4("mt_Viw", &mtViw);
	m_pEft->SetMatrix4("mt_Prj", &mtPrj);

	for(i=0; i<m_nGeo; ++i)
	{
		CLcAsg::Tgeo*		pGeo = &m_pGeo[i];

		if(NULL == pGeo->pVtx)
			continue;

		IGLTexture*	pTx=NULL;

		if(0 <= pGeo->nMtl)
			pTx = m_pMtl[pGeo->nMtl].pTex;
		
		if(NULL == pTx)
			continue;

		pTx->BindTexture(TRUE);

		mtW = m_pTM[i].mtW * m_mtWld;
		m_pEft->SetMatrix4("mt_Wld", &mtW);
		m_pEft->SetTexture("smp_tex", pTx);


		char*	pVtx = (char*)pGeo->pVtx;
		glEnableVertexAttribArray(0);	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, pGeo->dVtx, pVtx);	pVtx += sizeof(LCXVECTOR3);
		glEnableVertexAttribArray(1);	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, pGeo->dVtx, pVtx);
		
		glDrawElements(GL_TRIANGLES, pGeo->iNix * 3, GL_UNSIGNED_SHORT, pGeo->pIdx);

		pTx->BindTexture();
	}

	m_pEft->End();
}


INT CLcAsgIns::SetAttrib(char* sCmd, void* pData)
{
	if( 0 ==_stricmp("Advance Time", sCmd))
	{
		float	fElapsedTime = *((float*)pData);
		m_dTimeCur += fElapsedTime;
	}

	else if( 0 ==_stricmp("World Matrix", sCmd))
	{
		LCXMATRIX* pTM = (LCXMATRIX*)pData;
		m_mtWld	= *pTM;
	}
	else
	{
		return -1;
	}

	return 0;
}


INT CLcAsgIns::GetAttrib(char* sCmd, void* pData)
{
	return -1;
}




