// Implementation of the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////


#include <stdio.h>
#include <windows.h>

#include "GLES2/gl2.h"

#include "../_lcgl/GLMath.h"
#include "../_lcgl/IGLDev.h"
#include "../_lcgl/IGLEffect.h"
#include "../_lcgl/IGLTexture.h"
#include "../_lcgl/GLUtil.h"

#include "ILcMdl.h"
#include "LcAse.h"


#define MAX_PARSE_LINE	512


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }


CLcAse::CLcAse()
{
	m_nMtl	= 0;
	m_pMtl	= NULL;

	m_nGeo	= 0;
	m_pGeo	= NULL;

	m_dFrmCur = 0;
	m_dTimeCur= 0;

	m_mtWld.Identity();

	m_pDev	= NULL;
	m_pEft	= NULL;
}

CLcAse::~CLcAse()
{
	Destroy();
}


INT CLcAse::Create(void* p1, void* p2, void* p3, void* p4)
{
	strcpy(m_sFile, (char*)p2);

	if(FAILED(Load()))
		return -1;


	if(FAILED(SetupRenderData()))
		return -1;
	
	Confirm();

	SaveToAsmBin();
	SaveToAsmTxt();


	return 0;
}


void CLcAse::Destroy()
{
	m_nMtl	= 0;
	m_nGeo	= 0;

	SAFE_DELETE_ARRAY(	m_pGeo	);
	SAFE_DELETE_ARRAY(	m_pMtl	);
}



INT CLcAse::FrameMove()
{
	INT		i = 0;
	INT		nFrame	=0;

	// Frame = FrameSpeed * Time;
	m_dFrmCur = m_Scene.nFrmS * m_dTimeCur;

	nFrame	= INT(m_dFrmCur);

	if(nFrame>= m_Scene.nFrmL)
	{
		// ������ �ð��� ����ð����� �����Ѵ�.
		m_dTimeCur = m_dFrmCur - nFrame;
	}

	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*		pGeo = &m_pGeo[i];
		
		this->GetAniTrack(&pGeo->mtL, i, m_dFrmCur);

		// �θ��� ���� ����� ���� �ڽ��� ���� ����� �ϼ��Ѵ�.
		LCXMATRIX	mtPrn =LCXMATRIX(1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1);
	
		if(0 <= pGeo->nNodePrn)
			mtPrn	= m_pGeo[pGeo->nNodePrn].mtW;

		pGeo->mtW = pGeo->mtL * mtPrn;

		INT C;
		C=0;
	}

	return 0;
}




void CLcAse::Render()
{
	if(!m_pGeo)
		return;

	INT			i=0;
	LCXMATRIX	mtW;

	LCXMATRIX	mtViw;
	LCXMATRIX	mtPrj;

	m_pDev->GetAttribute(IGLDev::LPTS_VIEW, &mtViw);
	m_pDev->GetAttribute(IGLDev::LPTS_PROJ, &mtPrj);

	m_pEft->Begin();

	m_pEft->SetMatrix4("mt_Viw", &mtViw);
	m_pEft->SetMatrix4("mt_Prj", &mtPrj);

	for(i=0; i<m_nGeo; ++i)
	{
		AseGeo*		pGeo = &m_pGeo[i];

		if(NULL == pGeo->m_pVtx)
			continue;

		IGLTexture*	pTx=NULL;

		if(pGeo->nMtlRef>=0)
			pTx = m_pMtl[pGeo->nMtlRef].pTex;
		
		if(NULL == pTx)
			continue;

		pTx->BindTexture(TRUE);

		mtW = pGeo->mtW * m_mtWld;
		m_pEft->SetMatrix4("mt_Wld", &mtW);
		m_pEft->SetTexture("smp_tex", pTx);


		char*	pVtx = (char*)pGeo->m_pVtx;
		glEnableVertexAttribArray(0);	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, pGeo->m_dVtx, pVtx);	pVtx += sizeof(LCXVECTOR3);
		glEnableVertexAttribArray(1);	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, pGeo->m_dVtx, pVtx);

		glDrawElements(GL_TRIANGLES, pGeo->m_iNix * 3, GL_UNSIGNED_SHORT, pGeo->m_pIdx);

//		LcGL_DrawIndexedPrimitiveUP(GL_TRIANGLES, pGeo->m_iNix, pGeo->m_pIdx, pGeo->m_dFVF, pGeo->m_pVtx, pGeo->m_dVtx);

		pTx->BindTexture();
	}

	m_pEft->End();
}


INT CLcAse::SetAttrib(char* sCmd, void* pData)
{
	if( 0 ==_stricmp("Advance Time", sCmd))
	{
		float	fElapsedTime = *((float*)pData);
		m_dTimeCur += fElapsedTime;
	}

	else if( 0 ==_stricmp("World Matrix", sCmd))
	{
		LCXMATRIX* pTM = (LCXMATRIX*)pData;
		m_mtWld	= *pTM;
	}
	else if( 0 ==_stricmp("Device", sCmd))
	{
		m_pDev = (IGLDev*)pData;
	}
	else if( 0 ==_stricmp("Effect", sCmd))
	{
		m_pEft = (IGLEffect*)pData;
	}
	else
	{
		return -1;
	}


	return 0;
}


INT CLcAse::GetAttrib(char* sCmd, void* pData)
{
	if( 0 ==_stricmp("Current Time", sCmd))
	{
		*((float*)pData) = m_dTimeCur;
	}
	else
	{
		return -1;
	}

	return 0;
}


INT CLcAse::GetNumVtx(INT nGeo)
{
	AseGeo* pGeo = &m_pGeo[nGeo];
	
	return pGeo->m_iNvx;
}

INT CLcAse::GetNumIdx(INT nGeo)
{
	AseGeo* pGeo = &m_pGeo[nGeo];
	
	return pGeo->m_iNix;
}

void*  CLcAse::GetPtVtx(INT nGeo)
{
	AseGeo* pGeo = &m_pGeo[nGeo];
	
	return pGeo->m_pVtx;
}

void*  CLcAse::GetPtIdx(INT nGeo)
{
	AseGeo* pGeo = &m_pGeo[nGeo];

	return pGeo->m_pIdx;
}


INT CLcAse::GetAniTrack(void* mtOut, INT nGeo, FLOAT dFrame)
{
	INT			i=0;

	AseGeo*		pGeo	= &m_pGeo[nGeo];
	LCXMATRIX	mtA;

	INT			iSizeR = pGeo->vRot.size();
	INT			iSizeP = pGeo->vTrs.size();

	
	mtA.Identity();

	
	if(iSizeR && pGeo->vRot[0].nF <=dFrame)
	{
		INT nFrm = pGeo->vRot[0].nF;
		INT nIdx;

		if(1 == iSizeR)
		{
			LCXQUATERNION q;

			nIdx =0;

			q.x = pGeo->vRot[nIdx].x;
			q.y = pGeo->vRot[nIdx].y;
			q.z = pGeo->vRot[nIdx].z;
			q.w = pGeo->vRot[nIdx].w;

			q.RotationMatrix(&mtA, FALSE);
			//mtA.Transpose();
		}

		else if(pGeo->vRot[iSizeR-1].nF <=dFrame)
		{
			LCXQUATERNION q;

			nIdx = iSizeR-1;

			q.x = pGeo->vRot[nIdx].x;
			q.y = pGeo->vRot[nIdx].y;
			q.z = pGeo->vRot[nIdx].z;
			q.w = pGeo->vRot[nIdx].w;

			q.RotationMatrix(&mtA, FALSE);
			//mtA.Transpose();
		}

		else
		{
			for(i=0; i<iSizeR-1; ++i)
			{
				if(pGeo->vRot[i].nF <=dFrame && dFrame <pGeo->vRot[i+1].nF)
				{
					LCXQUATERNION q;
					LCXQUATERNION q1;
					LCXQUATERNION q2;

					nIdx = i;

					q1.x = pGeo->vRot[nIdx].x;
					q1.y = pGeo->vRot[nIdx].y;
					q1.z = pGeo->vRot[nIdx].z;
					q1.w = pGeo->vRot[nIdx].w;

					q2.x = pGeo->vRot[nIdx+1].x;
					q2.y = pGeo->vRot[nIdx+1].y;
					q2.z = pGeo->vRot[nIdx+1].z;
					q2.w = pGeo->vRot[nIdx+1].w;

					FLOAT	w = (dFrame - pGeo->vRot[i].nF)/(pGeo->vRot[i+1].nF- pGeo->vRot[i].nF);

					q.SLerp(&q1, &q2, w);
					q.RotationMatrix(&mtA, FALSE);
					//mtA.Transpose();

					break;
				}
			}
		}
	}

	else
	{
		mtA = pGeo->TmInf.mtL;
	}


	if(iSizeP && pGeo->vTrs[0].nF <=dFrame)
	{
		INT nIdx;

		if(1 == iSizeP)
		{
			LCXVECTOR3 p;

			nIdx =0;
			p.x = pGeo->vTrs[nIdx].x;
			p.y = pGeo->vTrs[nIdx].y;
			p.z = pGeo->vTrs[nIdx].z;

			mtA._41 = p.x;
			mtA._42 = p.y;
			mtA._43 = p.z;
		}

		else if(pGeo->vTrs[iSizeP-1].nF <=dFrame)
		{
			LCXVECTOR3 p;

			nIdx = iSizeP-1;
			p.x = pGeo->vTrs[nIdx].x;
			p.y = pGeo->vTrs[nIdx].y;
			p.z = pGeo->vTrs[nIdx].z;

			mtA._41 = p.x;
			mtA._42 = p.y;
			mtA._43 = p.z;
		}

		else
		{
			for(i=0; i<iSizeP-1; ++i)
			{
				if(pGeo->vTrs[i].nF <=dFrame && dFrame <pGeo->vTrs[i+1].nF)
				{
					LCXVECTOR3 p;
					LCXVECTOR3 p1;
					LCXVECTOR3 p2;

					nIdx = i;

					p1.x = pGeo->vTrs[nIdx].x;
					p1.y = pGeo->vTrs[nIdx].y;
					p1.z = pGeo->vTrs[nIdx].z;

					p2.x = pGeo->vTrs[nIdx+1].x;
					p2.y = pGeo->vTrs[nIdx+1].y;
					p2.z = pGeo->vTrs[nIdx+1].z;


					FLOAT	w = (dFrame- pGeo->vTrs[i].nF)/(pGeo->vTrs[i+1].nF- pGeo->vTrs[i].nF);

					p = p1  + w * (p2-p1);
					mtA._41 = p.x;	mtA._42 = p.y;	mtA._43 = p.z;
					break;
				}
			}
		}
	}
	else
	{
		mtA._41 = pGeo->TmInf.mtL._41;
		mtA._42 = pGeo->TmInf.mtL._42;
		mtA._43 = pGeo->TmInf.mtL._43;
	}


	*((LCXMATRIX*) mtOut) = mtA;
	
	return 0;
}



INT CLcAse::Load()
{
	FILE*	fp;

	fp = fopen(m_sFile, "rt");
	
	if(NULL == fp)
		return -1;


	ParseScene(fp);
	ParseMaterial(fp);
	ParseGeometry(fp);
	ParseAnimation(fp);

	fclose(fp);

	return 0;
}
