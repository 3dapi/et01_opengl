// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef _McScene_H_
#define _McScene_H_


class CMcScene
{
protected:
	IGLDev*			m_pDev		;

	ILcMdl*			m_pMdlOrg1	;		// Original
	ILcMdl*			m_pMdlIns1	;		// Instance

	ILcMdl*			m_pMdlOrg2	;		// Original
	ILcMdl*			m_pMdlIns2	;		// Instance

	IGLTexture*		m_pTex3		;
	IGLEffect*		m_pEft		;

public:
	CMcScene();
	virtual ~CMcScene();

	virtual	INT		Create(void* p1);
	virtual	void	Destroy();
	virtual	INT		FrameMove();
	virtual	void	Render();
};


#endif

