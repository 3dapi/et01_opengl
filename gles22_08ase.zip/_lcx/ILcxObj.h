// Interface for the ILcxObj class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILcxObj_H_
#define _ILcxObj_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
	virtual ~CLASS_NAME(){}
#endif


interface ILcxObj
{
	LC_CLASS_DESTROYER(	ILcxObj	);

	virtual INT		Create(void* =0, void* =0, void* p3=0, void* p4=0) =0;
	virtual void	Destroy() =0;
	virtual INT		FrameMove() =0;
	virtual void	Render() =0;
};


INT LcxObj_Create(char* sCmd
				, ILcxObj** pData
				, void* p1		// IGLDev*
				, void* p2=NULL
				, void* p3=NULL
				, void* p4=NULL
				);

#endif


