// Implementation of the CLcCam class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "GLES2/gl2.h"

#include "../_lcgl/IGLDev.h"
#include "../_lcgl/GLMath.h"

#include "ILcCam.h"



class CLcCam : public ILcCam
{
protected:
	IGLDev*		m_pDev;				// OpenGL Device

	FLOAT		m_fFv;				// Field of View
    FLOAT		m_fAs;				// Aspect Ratio
    FLOAT		m_fNr;				// Near
    FLOAT		m_fFr;				// Far

	FLOAT		m_nScnW;			// Screen Width
	FLOAT		m_nScnH;			// Screen Height

	LCXVECTOR3	m_vcEye;			// Camera position
	LCXVECTOR3	m_vcLook;			// Look vector
	LCXVECTOR3	m_vcUp;				// up vector

	FLOAT		m_fYaw;
	FLOAT		m_fPitch;

	LCXMATRIX	m_mtViw;			// View Matrix
	LCXMATRIX	m_mtPrj;			// Projection Matrix
	

public:
	CLcCam();
	virtual ~CLcCam();

	virtual	INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual	INT		FrameMove();

	virtual	const LCXMATRIX*	GetMatrixViw()	const	{	return &m_mtViw;	}
	virtual	const LCXMATRIX*	GetMatrixPrj()	const	{	return &m_mtPrj;	}

	virtual	const LCXVECTOR3*	GetEye()	const		{	return &m_vcEye;	}
	virtual	const LCXVECTOR3*	GetLook()	const		{	return &m_vcLook;	}
	virtual	const LCXVECTOR3*	GetUp()		const		{	return &m_vcUp;		}

public:
	virtual	void	MoveSideward(FLOAT	fSpeed);
	virtual	void	MoveForward	(FLOAT	fSpeed, FLOAT fY=0);
	virtual	void	Rotation(FLOAT fYaw, FLOAT fPitch, FLOAT fSpeed);

	virtual	void	TransformProj();
	virtual	void	TransformView();
};




CLcCam::CLcCam()
{

}

CLcCam::~CLcCam()
{

}


INT CLcCam::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev		= (IGLDev*)p1;

	float	f[4];

	glGetFloatv(GL_VIEWPORT, f);

	m_fYaw		= 0.f;
	m_fPitch	= 0.f;

	m_vcEye		= LCXVECTOR3(0, -450, 150);
	m_vcLook	= LCXVECTOR3(0,0,50);
	m_vcUp		= LCXVECTOR3(0,0,1);

	m_nScnW		= f[2] - f[0];
	m_nScnH		= f[3] - f[1];

	m_fFv		= 45.f;
	m_fAs		= FLOAT(m_nScnW )/FLOAT(m_nScnH );
	m_fNr		= 1.f;
	m_fFr		= 5000.f;


	m_mtPrj.SetupPerspectiveGL(LCXToRadian(m_fFv), m_fAs, m_fNr, m_fFr);
	m_mtViw.SetupViewRH(&m_vcEye, &m_vcLook, &m_vcUp);

	return 0;
}


INT CLcCam::FrameMove()
{
	m_mtPrj.SetupPerspectiveGL(LCXToRadian(m_fFv), m_fAs, m_fNr, m_fFr);
	m_mtViw.SetupViewRH(&m_vcEye, &m_vcLook, &m_vcUp);

	m_pDev->SetAttribute(IGLDev::LPTS_VIEW, &m_mtViw);
	m_pDev->SetAttribute(IGLDev::LPTS_PROJ, &m_mtPrj);

	return 0;
}

void CLcCam::MoveSideward(FLOAT fSpeed)
{
	LCXVECTOR3 vcZ = m_vcLook - m_vcEye;
	vcZ.Normalize();

	LCXVECTOR3	vcX;
	vcX.Cross(&vcZ, &m_vcUp);
	vcX.Normalize();
	m_vcEye  += vcX * fSpeed;
	m_vcLook += vcX * fSpeed;

	m_mtViw.SetupViewRH(&m_vcEye, &m_vcLook, &m_vcUp);
}


void CLcCam::MoveForward(FLOAT fSpeed, FLOAT fD)
{
	LCXVECTOR3 vcZ;

//	vcZ =LCXVECTOR3(m_mtViw._12, m_mtViw._22, m_mtViw._32);
//	vcZ = -LCXVECTOR3(m_mtViw._13, m_mtViw._23, m_mtViw._33);

	vcZ = m_vcLook - m_vcEye;
	vcZ.Normalize();

	m_vcEye  += vcZ * fSpeed;
	m_vcLook += vcZ * fSpeed;

	m_mtViw.SetupViewRH(&m_vcEye, &m_vcLook, &m_vcUp);
}



void CLcCam::Rotation(FLOAT fYaw, FLOAT fPitch, FLOAT fSpeed)
{
	m_fYaw   = LCXToRadian(fYaw  * fSpeed);
	m_fPitch = LCXToRadian(fPitch* fSpeed);
	
	LCXMATRIX rot;
	LCXVECTOR3 vcZ;
	LCXVECTOR3 vcX;

	// Yaw�� ���� ȸ��
	vcZ = m_vcLook - m_vcEye;
	rot.SetupRotationZ(m_fYaw);

	rot.TransformCoord(&vcZ);
	rot.TransformCoord(&m_vcUp);

	m_vcLook = vcZ + m_vcEye;
	m_mtViw.SetupViewRH(&m_vcEye, &m_vcLook, &m_vcUp);


	// Pitch�� ���� ȸ��
	vcZ = m_vcLook - m_vcEye;
	vcX =LCXVECTOR3(m_mtViw._11, m_mtViw._21, m_mtViw._31);

	rot.SetupRotationAxis(&vcX, m_fPitch);
	rot.TransformCoord(&vcZ);
	rot.TransformCoord(&m_vcUp);

	m_vcLook = vcZ + m_vcEye;
	m_mtViw.SetupViewRH(&m_vcEye, &m_vcLook, &m_vcUp);
}


void CLcCam::TransformProj()
{
	m_pDev->SetAttribute(IGLDev::LPTS_PROJ, &m_mtPrj);
}


void CLcCam::TransformView()
{
	m_pDev->SetAttribute(IGLDev::LPTS_VIEW, &m_mtViw);
}




INT LcEnt_CreateCamera(char* sCmd, ILcCam** pData, void* p1, void* p2, void* p3, void* p4)
{
	*pData = NULL;

	CLcCam* pObj = new CLcCam;

	if(FAILED(pObj->Create(p1, p2, p3, p4)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}