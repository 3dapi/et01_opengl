// Implementation of the CLcxGrid class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include "GLES2/gl2.h"

#include "../_lcgl/GLMath.h"
#include "../_lcgl/IGLDev.h"
#include "../_lcgl/IGLEffect.h"

#include "ILcxObj.h"

#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }


class CLcxGrid : public ILcxObj
{
public:
	struct GtxD
	{
		LCXVEC3i	p;
		LCXCOLORb	d;

		GtxD() : p(0,0,0), d(0xFFFFFFFF){}
		GtxD(FLOAT X,FLOAT Y,FLOAT Z, DWORD D=0xFFFFFFFF)
		{
			p.x =FixedD(X);
			p.y =FixedD(Y);
			p.z =FixedD(Z);

			d = D;
		}
	};


protected:
	IGLDev*	m_pDev;
	GLuint	m_eProg;

	INT		m_nVtx;
	GtxD*	m_pVtx;

public:
	CLcxGrid();
	virtual ~CLcxGrid();

	virtual	INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL);
	virtual	void	Destroy();
	virtual	INT		FrameMove();
	virtual	void	Render();
};



CLcxGrid::CLcxGrid()
{
	m_eProg = 0;
}

CLcxGrid::~CLcxGrid()
{
	Destroy();
}

void CLcxGrid::Destroy()
{
	SAFE_DELETE_ARRAY(	m_pVtx	);

	if(m_eProg)
	{
		glDeleteProgram(m_eProg);
		m_eProg = 0;
	}

	m_pDev	= NULL;
}

INT CLcxGrid::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pDev = (IGLDev*)p1;


	INT hr =0;

	GLuint ShaderVtx = 0;
	GLuint ShaderFrg = 0;

	const char* sSrc = 0;
	INT			iLen = 0;

	char	sShaderVtx[] =
		
	"uniform	mat4	m_mtWld;		\n"
	"uniform	mat4	m_mtViw;		\n"
	"uniform	mat4	m_mtPrj;		\n"

	"attribute	vec3	att_pos;		\n"
	"attribute	vec4	att_dif;		\n"

	"varying	vec4	frg_dif;		\n"

	"void main()						\n"
	"{									\n"
	"	vec4	Pos;					\n"
	"	Pos = vec4(att_pos,1.0);		\n"
	"	Pos = m_mtWld * Pos;			\n"
	"	Pos = m_mtViw * Pos;			\n"
	"	Pos = m_mtPrj * Pos;			\n"

	"	gl_Position = Pos;				\n"

	"	frg_dif = att_dif;				\n"
	"}									\n"
	;


	char	sShaderFrg[] =
	"precision mediump float;			\n"

	"varying	vec4	frg_dif;		\n"

	"void main()						\n"
	"{									\n"
	"	vec4 Out = frg_dif;				\n"
	"	gl_FragColor = Out;				\n"
	"}									\n"
	;


	// Create Vertex Shader
	hr  = LgxDev_CompileShader(&ShaderVtx, GL_VERTEX_SHADER, sShaderVtx, strlen(sShaderVtx));
	if(FAILED(hr))
		return -1;


	// Create Fragment Shader
	hr  = LgxDev_CompileShader(&ShaderFrg, GL_FRAGMENT_SHADER, sShaderFrg, strlen(sShaderFrg));
	if(FAILED(hr))
		return -1;


	// Create Program Object
	m_eProg = glCreateProgram();

	if(0 == m_eProg)
		return -1;


	// Attach
	glAttachShader(m_eProg, ShaderVtx);
	glAttachShader(m_eProg, ShaderFrg);

	// Setup Position Attribute
	glBindAttribLocation(m_eProg, 0, "att_pos");
	glBindAttribLocation(m_eProg, 1, "att_dif");


	// Linking
	glLinkProgram(m_eProg);
	glGetProgramiv(m_eProg, GL_LINK_STATUS, &hr);
	if(!hr) 
	{
		printf("Couldn't link shader! Exiting...\n");
		return -1;
	}


	m_nVtx = (20*2 + 20*2 + 3*2)*2;
	m_pVtx = new GtxD[m_nVtx];

	INT k=-1;

	m_pVtx[++k] = GtxD(-2000.0F,    0.0F,    0.0F, 	LCXCOLOR(0.5F, 0.0F, 0.0F, 1.0F) 	);
	m_pVtx[++k] = GtxD(    0.0F,    0.0F,    0.0F, 	LCXCOLOR(0.5F, 0.0F, 0.0F, 1.0F) 	);	
	m_pVtx[++k] = GtxD( 2000.0F,    0.0F,    0.0F, 	LCXCOLOR(1.0F, 0.0F, 0.0F, 1.0F) 	);
	m_pVtx[++k] = GtxD(    0.0F,    0.0F,    0.0F, 	LCXCOLOR(1.0F, 0.0F, 0.0F, 1.0F) 	);	

	m_pVtx[++k] = GtxD(	   0.0F,-2000.0F,    0.0F, 	LCXCOLOR(0.0F, 0.5F, 0.0F, 1.0F) 	);
	m_pVtx[++k] = GtxD(    0.0F,    0.0F,    0.0F, 	LCXCOLOR(0.0F, 0.5F, 0.0F, 1.0F) 	);	
	m_pVtx[++k] = GtxD(	   0.0F, 2000.0F,    0.0F, 	LCXCOLOR(0.0F, 1.0F, 0.0F, 1.0F) 	);
	m_pVtx[++k] = GtxD(    0.0F,    0.0F,    0.0F, 	LCXCOLOR(0.0F, 1.0F, 0.0F, 1.0F) 	);	

	m_pVtx[++k] = GtxD(	   0.0F,    0.0F,-2000.0F, 	LCXCOLOR(0.0F, 0.0F, 0.5f, 1.0F) 	);
	m_pVtx[++k] = GtxD(    0.0F,    0.0F,    0.0F, 	LCXCOLOR(0.0F, 0.0F, 0.5f, 1.0F) 	);	
	m_pVtx[++k] = GtxD(	   0.0F,    0.0F, 2000.0F, 	LCXCOLOR(0.0F, 0.0F, 1.0F, 1.0F) 	);
	m_pVtx[++k] = GtxD(    0.0F,    0.0F,    0.0F, 	LCXCOLOR(0.0F, 0.0F, 1.0F, 1.0F) 	);	

	
	for(INT i = -10; i <=10; i++)
	{
		if(0==i)
			continue;

		m_pVtx[++k] = GtxD(i*20.0F, -200.0F, 0.0F, 	LCXCOLOR(0.5F, 0.5F, 0.5F, 1.0F) 	);
		m_pVtx[++k] = GtxD(i*20.0F, 0.0F   , 0.0F, 	LCXCOLOR(0.5F, 0.5F, 0.5F, 1.0F) 	);
		m_pVtx[++k] = GtxD(i*20.0F,  200.0F, 0.0F, 	LCXCOLOR(0.5F, 0.5F, 0.5F, 1.0F) 	);
		m_pVtx[++k] = GtxD(i*20.0F, 0.0F   , 0.0F, 	LCXCOLOR(0.5F, 0.5F, 0.5F, 1.0F) 	);

		m_pVtx[++k] = GtxD(-200.0F, i*20.0F, 0.0F, 	LCXCOLOR(0.5F, 0.5F, 0.5F, 1.0F) 	);
		m_pVtx[++k] = GtxD(   0.0F, i*20.0F, 0.0F, 	LCXCOLOR(0.5F, 0.5F, 0.5F, 1.0F) 	);
		m_pVtx[++k] = GtxD( 200.0F, i*20.0F, 0.0F, 	LCXCOLOR(0.5F, 0.5F, 0.5F, 1.0F) 	);
		m_pVtx[++k] = GtxD(   0.0F, i*20.0F, 0.0F, 	LCXCOLOR(0.5F, 0.5F, 0.5F, 1.0F) 	);
	}



//	GLfloat	LineWidth[2]={0};
//	glGetFloatv(GL_ALIASED_LINE_WIDTH_RANGE, LineWidth);

	return 0;
}


INT CLcxGrid::FrameMove()
{
	return 0;
}

void CLcxGrid::Render()
{
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_CULL_FACE);


	glUseProgram(m_eProg);

	char*	pVtx = (char*)m_pVtx;
	glEnableVertexAttribArray(0);	glVertexAttribPointer(0, 3, GL_FIXED,		  GL_TRUE, sizeof(CLcxGrid::GtxD), pVtx);	pVtx += sizeof(LCXVEC3i);
	glEnableVertexAttribArray(1);	glVertexAttribPointer(1, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(CLcxGrid::GtxD), pVtx);


	LCXMATRIX	mtWld;
	LCXMATRIX	mtViw;
	LCXMATRIX	mtPrj;

	mtWld.Identity();
	mtViw.Identity();
	mtPrj.Identity();

	m_pDev->GetAttribute(IGLDev::LPTS_VIEW, &mtViw);
	m_pDev->GetAttribute(IGLDev::LPTS_PROJ, &mtPrj);

	INT	nWld =  glGetUniformLocation(m_eProg, "m_mtWld");	glUniformMatrix4fv(nWld, 1, GL_FALSE, (GLfloat*)&mtWld);
	INT	nViw =  glGetUniformLocation(m_eProg, "m_mtViw");	glUniformMatrix4fv(nViw, 1, GL_FALSE, (GLfloat*)&mtViw);
	INT	nPrj =  glGetUniformLocation(m_eProg, "m_mtPrj");	glUniformMatrix4fv(nPrj, 1, GL_FALSE, (GLfloat*)&mtPrj);

	

	glDrawArrays(GL_LINES, 0, m_nVtx);

	glDisableVertexAttribArray(0);
	glDisableVertexAttribArray(1);

	glUseProgram(0);
}



INT LcxObj_Create(char* sCmd, ILcxObj** pData, void* p1, void* p2, void* p3, void* p4)
{
	*pData = NULL;

	ILcxObj* pObj = NULL;

	if(0 ==_stricmp(sCmd, "Grid"))
		pObj = new CLcxGrid;
	else
		return -1;


	if(FAILED(pObj->Create(p1, p2, p3, p4)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}


