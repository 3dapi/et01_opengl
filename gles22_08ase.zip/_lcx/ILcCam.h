// Interface for the ILcCam class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _ILcCam_H_
#define _ILcCam_H_

#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
	virtual ~CLASS_NAME(){}
#endif


interface ILcCam
{
	LC_CLASS_DESTROYER(	ILcCam	);

	virtual	INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL)=0;
	virtual	INT		FrameMove()=0;

	virtual const LCXMATRIX*	GetMatrixViw() const =0;
	virtual const LCXMATRIX*	GetMatrixPrj() const =0;

	virtual const LCXVECTOR3*	GetEye() const =0;
	virtual const LCXVECTOR3*	GetLook() const =0;
	virtual const LCXVECTOR3*	GetUp() const =0;

	virtual void MoveForward(FLOAT	fSpeed, FLOAT fD=0)=0;
	virtual void MoveSideward(FLOAT	fSpeed)=0;
	virtual void Rotation(FLOAT fYaw, FLOAT fPitch, FLOAT fSpeed)=0;

	virtual void TransformProj()=0;
	virtual void TransformView()=0;
};


INT LcEnt_CreateCamera(char* sCmd
					   , ILcCam** pData
					   , void* p1
					   , void* p2	= NULL
					   , void* p3	= NULL
					   , void* p4	= NULL
					   );

#endif


