// Interface for the IGLFont class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _IGLFont_H_
#define _IGLFont_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
	virtual ~CLASS_NAME(){}
#endif


interface IGLFont
{
	LC_CLASS_DESTROYER(	IGLFont	);

	virtual	INT		Create(void* =0, void* =0, void* =0, void* =0)=0;
	virtual	void	Destroy()=0;

	virtual	GLuint	GetName()=0;
	virtual	GLenum	GetFMT()=0;
	virtual	GLenum	GetType()=0;

	virtual	INT		GetImgW()=0;
	virtual	INT		GetImgH()=0;

	virtual	void	SetString(char* sMsg)=0;

	virtual	void	DrawTxt(  LCXVECTOR2* vcScl		// Scaling
							, LCXVECTOR2* vcRot		// Rotation Center
							, FLOAT fRot			// Angle(Radian)
							, LCXVECTOR2* vcTrn		// Position
							, LCXCOLOR dcolor		// color
						)=0;


struct TFont
{
	INT		Height;
	INT		Weight;
	INT		Italic;
	INT		Quality;
	char	sName[32];

	TFont() : Height(0), Weight(400), Italic(0), Quality(0)
	{
		strcpy(sName, "����");
	}

	TFont(INT H,INT W,INT I,INT Q,char* s) : Height(H), Weight(W), Italic(I), Quality(Q)
	{
		strcpy(sName, s);
	}
};


};


INT		LgxDev_FontInit();
void	LgxDev_FontDestroy();

INT		LgDev_CreateFont(char* sCmd
						, IGLFont** pData
						, void* pTFont);


#endif