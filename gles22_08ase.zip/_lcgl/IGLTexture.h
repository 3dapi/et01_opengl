// Interface for the IGLTexture class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _IGLTexture_H_
#define _IGLTexture_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
	virtual ~CLASS_NAME(){}
#endif


interface IGLTexture
{
	LC_CLASS_DESTROYER(	IGLTexture	);

	virtual	INT		Create(void* =0, void* =0, void* =0, void* =0)=0;
	virtual	void	Destroy()=0;

	virtual	UINT	GetName()=0;
	virtual	INT		GetFMT()=0;
	virtual	INT		GetType()=0;

	virtual	INT		GetImgW()=0;
	virtual	INT		GetImgH()=0;

	virtual	void	BindTexture(INT modulate=0)=0;

	virtual	void	DrawPixel(RECT* rc			// Image rect
						, LCXVECTOR2* vcScl		// Scaling
						, LCXVECTOR2* vcRot		// Rotation Center
						, FLOAT fRot			// Angle(Radian)
						, LCXVECTOR2* vcTrn		// Position
						, LCXCOLOR dcolor		// color
						)=0;
};


INT LgDev_CreateTexture(char* sCmd
					, IGLTexture** pData
					, void* sFile
					, void* pMemoey
					, DWORD dcolorKey
					, DWORD dFilter);


#endif