// Implementation of the GLUtil Functions.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include "GLES2/gl2.h"
#include "GLES2/gl2ext.h"
#include "EGL/egl.h"

#include "GLMath.h"
#include "GLUtil.h"


#define D3DFVF_XYZ			0x002
#define D3DFVF_DIFFUSE      0x040
#define D3DFVF_TEX1			0x100


void LcGL_SetStreamSource(DWORD dFVF, void* pVtx, INT dStride)
{
}



void LcGL_DrawPrimitive(INT mode, INT first, INT nVtx)
{
	glDrawArrays(mode, first, nVtx);
}


void LcGL_DrawIndexedPrimitive(INT mode, INT nFace, const void *indices)
{
	glDrawElements(mode, nFace * 3, GL_UNSIGNED_SHORT, indices);
}

void LcGL_DrawIndexedPrimitiveUP(INT mode, INT nFace, const void *indices,	DWORD dFVF, const void* pVtx, INT dStride)
{
	glDrawElements(mode, nFace * 3, GL_UNSIGNED_SHORT, indices);
}

