// Interface for the IGLEffect class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _IGLEffect_H_
#define _IGLEffect_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
	virtual ~CLASS_NAME(){}
#endif


interface IGLEffect
{
	LC_CLASS_DESTROYER(	IGLEffect	);

	virtual	INT		Create(void* =0, void* =0, void* =0, void* =0)=0;
	virtual	void	Destroy()=0;
	virtual	INT		Begin()=0;
	virtual	INT		End()=0;
	virtual	INT		BindAttribLocation(char* attName, INT nIndex) =0;
	virtual	INT		SetVertexAttrib(INT indx, INT size=0, INT type=0, INT normalized=0, INT stride=0, const void* ptr=0) =0;

	virtual	INT		GetProgram()=0;


	// Setup Uniform value
	virtual	INT	SetInt(const char* sHandle, INT pVal)=0;
	virtual	INT	SetIntArray(const char* sHandle, void* pVal, INT nCount)=0;
	virtual	INT	SetFloat(const char* sHandle, float pVal)=0;
	virtual	INT	SetFloatArray(const char* sHandle, void* pVal, INT nCount)=0;
	virtual	INT	SetVector2(const char* sHandle, void* pVal)=0;
	virtual	INT	SetVector3(const char* sHandle, void* pVal)=0;
	virtual	INT	SetVector4(const char* sHandle, void* pVal)=0;
	virtual	INT	SetMatrix2(const char* sHandle, void* pVal)=0;
	virtual	INT	SetMatrix3(const char* sHandle, void* pVal)=0;
	virtual	INT	SetMatrix4(const char* sHandle, void* pVal)=0;
	virtual	INT	SetColor4f(const char* sHandle, void* pVal)=0;
	virtual	INT	SetTexture(const char* sHandle, void* pVal)=0;
};


INT LgDev_CreateEffect(char* sCmd
					, IGLEffect** pData
					, void* p1				// Vertex Shader Source
					, void* p2				// Fragment Shader Source
					, void* p3				// Bind Positon Attrib Location
					, void* p4	= NULL		// No Use
					);


INT		LgxDev_CompileShader(UINT* pOut, INT nType, const char* sSrc, INT iLen);
INT		LgxDev_CompileShaderFromTextFile(UINT* pOut, INT nType, const char* sFile);

#endif


