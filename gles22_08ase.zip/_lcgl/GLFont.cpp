// Implementation of the CGLFont class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <string>

#include "GLES2/gl2.h"

#include "../_lcgl/GLMath.h"

#include "IGLEffect.h"
#include "IGLFont.h"



class CGLFont : public IGLFont
{
protected:
	HFONT		m_hFnt;
	TFont		m_Font;

	GLuint		m_nTex;			// Name
	INT			m_ImgW;
	INT			m_ImgH;

	std::string	m_sMsg;

public:
	CGLFont ();
	virtual ~CGLFont();

	virtual	INT		Create(void* =0, void* =0, void* =0, void* =0);
	virtual	void	Destroy();

	virtual	GLuint	GetName()	{	return m_nTex;				}
	virtual	GLenum	GetFMT()	{	return GL_LUMINANCE;		}
	virtual	GLenum	GetType()	{	return GL_UNSIGNED_BYTE;	}

	virtual	INT		GetImgW()	{	return m_ImgW;				}
	virtual	INT		GetImgH()	{	return m_ImgH;				}


	virtual	void	SetString(char* sMsg);

	virtual	void	DrawTxt(  LCXVECTOR2* vcScl		// Scaling
							, LCXVECTOR2* vcRot		// Rotation Center
							, FLOAT fRot			// Angle(Radian)
							, LCXVECTOR2* vcTrn		// Position
							, LCXCOLOR dcolor		// color
						);

public:
	static GLuint	m_eProg;
};




CGLFont::CGLFont()
{
	m_hFnt	= NULL;

	m_nTex	= 0;
	
	m_ImgW	= 0;
	m_ImgH	= 0;
}


CGLFont::~CGLFont()
{
	Destroy();
}

void CGLFont::Destroy()
{
	if(m_nTex)
	{
		glDeleteTextures (1, &m_nTex);
		m_nTex = 0;
	}

	if(m_hFnt)
	{
		DeleteObject(m_hFnt);
		m_hFnt = NULL;
	}
}


INT CGLFont::Create(void* p1, void* p2, void* p3, void* p4)
{
	INT		hr;

	memcpy(&m_Font, p1, sizeof(IGLFont::TFont));


	// Log Font ����
	LOGFONT lFont=
	{
		-m_Font.Height
		, 0
		, 0
		, 0
		, m_Font.Weight
		, m_Font.Italic
		, FALSE
		, FALSE
		, HANGUL_CHARSET
		, OUT_DEFAULT_PRECIS
		, CLIP_DEFAULT_PRECIS
		, m_Font.Quality ? ANTIALIASED_QUALITY: NONANTIALIASED_QUALITY	// 
		, FF_DONTCARE
	};

	strcpy(lFont.lfFaceName, m_Font.sName);

	m_hFnt = CreateFontIndirect(&lFont);

	if(!m_hFnt)
		return -1;
	

	if(0 ==CGLFont::m_eProg)
	{
		hr = LgxDev_FontInit();
		if(FAILED(hr))
			return -1;
	}

	return 0;
}


void CGLFont::SetString(char* sMsg)
{
	if(!sMsg || !strlen(sMsg))
	{
		m_sMsg.erase();

		if(m_nTex)
		{
			glDeleteTextures (1, &m_nTex);
			m_nTex = 0;
		}

		return;
	}

	// 1. GDI�� ���ڿ� ���
	HDC			hDC = NULL;
	SIZE		sz;
	TEXTMETRIC	tm;
	INT			nImgW=0;
	INT			nImgH=0;



	INT		iLen	= strlen(sMsg);


	hDC = GetDC(NULL);
	SelectObject(hDC, m_hFnt);													// Parent window�� DC�� �̿��� ��Ʈ���� ��Ȯ�� �ȼ� ����� ��� �´�.
	GetTextExtentPoint32(hDC, sMsg, iLen, &sz);
	nImgW = sz.cx;
	GetTextMetrics(hDC, &tm);
	nImgW -= tm.tmOverhang;


	// DIB�� ������ �����Ѵ�.
	BITMAPINFO BmpInfo={0};

	INT	nFontH = m_Font.Height;


	//������ ���� 4�� ����� �����.
	nImgW = nImgW + (4 - nImgW%4);


	//������ ���� �����Ѵ�.
	if(nFontH<=11)		nImgH = INT(nFontH * 8);
	else if(nFontH<=20)	nImgH = INT(nFontH * 3);
	else				nImgH = INT(nFontH * 1.25);



	nImgH = INT(nFontH * 8);
	nImgH = nImgH + (8 - nImgH%8);

	BmpInfo.bmiHeader.biSize		= sizeof(BITMAPINFOHEADER);
	BmpInfo.bmiHeader.biWidth		= nImgW;
	BmpInfo.bmiHeader.biHeight		= nImgH;
	BmpInfo.bmiHeader.biPlanes		= 1;
	BmpInfo.bmiHeader.biBitCount	= 3 * 8;	// 24��Ʈ�� ����
	BmpInfo.bmiHeader.biCompression	= BI_RGB;
	BmpInfo.bmiHeader.biSizeImage	= 3* nImgW * nImgH;
//	BmpInfo.bmiHeader.biSizeImage	= (((m_ImgW * 24 + 31) & ~31) >> 3) * m_ImgH;	// ������ ���� 4��� �̻��̸� �� ������ �ʿ����.


	// DIB�� ���� �̹��� �����Ϳ� DIB�� �����Ѵ�.
	BYTE*	pPxlT = NULL;
	HBITMAP hBmpCur = ::CreateDIBSection(hDC, &BmpInfo, DIB_RGB_COLORS, (void **)&pPxlT, 0, 0);

	// hDC�� ����ϸ� ����ȭ�鿡 ���ڿ��� ��µǹǷ�
	// ���� ȭ���� ��Ʈ ���� ���� ������ �� �����Ƿ�
	// �̿� ������ �̹��� ������ ���� DC�� �ӽ÷� �����.
	HDC hMemDC = ::CreateCompatibleDC(hDC);

	// �� �ӽ� DC�� �̹����� ������ ��Ʈ���� �����ϰ� ���� ���븦 ����
	HBITMAP hBmpOld = (HBITMAP)::SelectObject(hMemDC, hBmpCur);


	// DC�� ��Ʈ���� ������ BGR�����̴�.
	COLORREF dFrn = RGB(255, 255, 255);
	SetTextColor(hMemDC, dFrn);
	SelectObject(hMemDC, m_hFnt);
	SetBkMode(hMemDC, TRANSPARENT);
	::ExtTextOut(hMemDC, 0, 0, 0, NULL, sMsg, iLen, NULL);

	::SelectObject(hMemDC, hBmpOld); 	// ���� ��Ʈ������ �����Ѵ�.
	DeleteDC(hMemDC);					// �ӽ� DC�� �����Ѵ�.



	// ���ڿ� ����.
	m_sMsg = sMsg;


	// 2. GDI���� ���ڿ� ����
	BYTE*	pPxl= new BYTE[1 * nImgW * nImgH];	// new Data

	// RGB --> RGBA�� ����� �������̸� ���� �������� �ٲ۴�.
	for(INT y=0; y<nImgH; ++y)
	{
		for(INT x=0; x<nImgW; ++x)
		{
			INT n1 = (y*nImgW + x)* 3;
			INT n2 = (y*nImgW + x)* 1;

			BYTE R = pPxlT[n1 +0];
			BYTE G = pPxlT[n1 +1];
			BYTE B = pPxlT[n1 +2];

			pPxl[n2 +0] = R;
//			pPxl[n2 +1] = 0xFF;
//
//			if(0 == R && 0 == G && 0 == B)
//				pPxl[n2 +1] = 0x0;
		}
	}

	// ����ߴ� ��Ʈ�ʰ� DC �� ����
	DeleteObject(hBmpCur);
	ReleaseDC(NULL, hDC);


	m_ImgW	= nImgW;
	m_ImgH	= nImgH;

	if(m_nTex)
		glDeleteTextures(1, &m_nTex);

	glGenTextures (1,&m_nTex);
	glBindTexture (GL_TEXTURE_2D, m_nTex);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, m_ImgW, m_ImgH, 0, GL_LUMINANCE, GL_UNSIGNED_BYTE, pPxl);

	glTexParameteri ( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri ( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri ( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri ( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	glBindTexture (GL_TEXTURE_2D, 0);

	delete [] pPxl;
}


void CGLFont::DrawTxt(LCXVECTOR2* vcScl		// Scaling
					, LCXVECTOR2* vcRot		// Rotation Center
					, FLOAT fRot			// Angle(Radian)
					, LCXVECTOR2* vcTrn		// Position
					, LCXCOLOR dColor		// color
					)
{
	if(!m_nTex)
		return;

	
	FLOAT f[ 4]={0};


	LCXVECTOR2	st0(0,0);	// �ؽ�ó ��ǥ �� �ϴ�
	LCXVECTOR2	st1(1,1);	// �ؽ�ó ��ǥ �� ���

	FLOAT	PosL = 0;		// ��ġ Left
	FLOAT	PosT = 0;		// ��ġ Top
	FLOAT	PosR = 0;		// ��ġ Right
	FLOAT	PosB = 0;		// ��ġ Bottom

	FLOAT	ImgW = (FLOAT)this->GetImgW();
	FLOAT	ImgH = (FLOAT)this->GetImgH();
	INT		nTex = this->GetName();

	FLOAT	rcW= ImgW;
	FLOAT	rcH= ImgH;


	LCXVECTOR2	vScl(1,1);
	LCXVECTOR2	vRot(0,0);
	LCXVECTOR2	vTrn(0,0);

	if(vcScl)	vScl = *vcScl;
	if(vcRot)	vRot = *vcRot;
	if(vcTrn)	vTrn = *vcTrn;


	// ����Ʈ���� ȭ���� ũ�⸦ ��´�.
	glGetFloatv(GL_VIEWPORT, f);

	
	// ���� ��ȯ�� x, y�� ����� �Ѵ�.
	PosL =  2.0f * vTrn.x/f[2] - 1.0f;		// Left
	PosT = -2.0f * vTrn.y/f[3] + 1.0f;		// Top
	PosR = PosL + 2.0f * rcW * vScl.x/f[2];	// Right
	PosB = PosT - 2.0f * rcH * vScl.y/f[3];	// Bottom



	LCXVEC2i	s_pos[4];
	LCXVEC2i	s_tex[4];

	s_pos[0] = LCXVEC2i(FixedD(PosL), FixedD(PosB) );
	s_pos[1] = LCXVEC2i(FixedD(PosR), FixedD(PosB) );
	s_pos[2] = LCXVEC2i(FixedD(PosR), FixedD(PosT) ); 
	s_pos[3] = LCXVEC2i(FixedD(PosL), FixedD(PosT) ); 

	s_tex[0] = LCXVEC2i(FixedD(st0.x), FixedD(st0.y) );
	s_tex[1] = LCXVEC2i(FixedD(st1.x), FixedD(st0.y) );
	s_tex[2] = LCXVEC2i(FixedD(st1.x), FixedD(st1.y) ); 
	s_tex[3] = LCXVEC2i(FixedD(st0.x), FixedD(st1.y) ); 



	if(0.0f == dColor.r && 0.0f == dColor.g && 0.0f == dColor.b)
	{
		dColor.r = 1.f/255.f;
		dColor.g = 1.f/255.f;
		dColor.b = 1.f/255.f;
	}

	glDisable(GL_DEPTH_TEST);


	// Blending Ȱ��ȭ
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	GLuint eProg = CGLFont::m_eProg;

	glUseProgram(eProg);
	glEnableVertexAttribArray(0);	glVertexAttribPointer(0, 2, GL_FIXED, GL_TRUE, 0, s_pos);
	glEnableVertexAttribArray(1);	glVertexAttribPointer(1, 2, GL_FIXED, GL_TRUE, 0, s_tex);

	INT	nFrg_Col = glGetUniformLocation(eProg, "frg_col");
	glUniform4fv(nFrg_Col, 4, (GLfloat*)&dColor);


	int	nFrg_Smp = glGetUniformLocation(eProg, "sampler");
	glEnable(GL_TEXTURE_2D);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture (GL_TEXTURE_2D, nTex);

	glUniform1i(nFrg_Smp, 0);


	glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
	

	glUseProgram(0);

	glBindTexture (GL_TEXTURE_2D, 0);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);
}



INT LgDev_CreateFont(char* sCmd
					, IGLFont** pData
					, void* pTFont)
{
	*pData = NULL;

	CGLFont* pObj = new CGLFont;

	if(FAILED(pObj->Create(pTFont)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}




GLuint CGLFont::m_eProg = 0;


INT LgxDev_FontInit()
{
	INT hr =0;

	GLuint ShaderVtx = 0;
	GLuint ShaderFrg = 0;

	const char* sSrc = 0;
	INT			iLen = 0;

	char	sShaderVtx[] =
	"attribute vec2 att_pos;			\n"
	"attribute vec2 att_tex;			\n"

	"varying vec2	frg_tex;			\n"

	"void main()						\n"
	"{									\n"
	"	gl_Position.x = att_pos.x;		\n"
	"	gl_Position.y = att_pos.y;		\n"
	"	gl_Position.z = 0.0;			\n"
	"	gl_Position.w = 1.0;			\n"
	
	"	frg_tex	= att_tex;				\n"
	"}									\n"
	;


	char	sShaderFrg[] =
	"precision mediump float;					\n"

	"uniform sampler2D	sampler;				\n"
	"uniform vec4		frg_col;				\n"

	"varying vec2		frg_tex;				\n"

	"void main()								\n"
	"{											\n"
	"	vec4 Out;								\n"
	"	vec4 tex = texture2D(sampler,frg_tex);	\n"

	"	Out	= frg_col;							\n"
	"	Out	*= tex;								\n"

	"	if( (Out.r==0.0 && Out.g==0.0 && Out.b==0.0) || Out.a<0.01)	\n"
	"	{															\n"
	"		discard;							\n"
	"		return;								\n"
	"	}										\n"

	"	gl_FragColor = Out;						\n"
	"}											\n"
	;



	// Create Vertex Shader
	hr  = LgxDev_CompileShader(&ShaderVtx, GL_VERTEX_SHADER, sShaderVtx, strlen(sShaderVtx));
	if(FAILED(hr))
		return -1;


	// Create Fragment Shader
	hr  = LgxDev_CompileShader(&ShaderFrg, GL_FRAGMENT_SHADER, sShaderFrg, strlen(sShaderFrg));
	if(FAILED(hr))
		return -1;


	// Create Program Object
	CGLFont::m_eProg = glCreateProgram();

	if(0 == CGLFont::m_eProg)
		return -1;


	// Attach
	glAttachShader(CGLFont::m_eProg, ShaderVtx);
	glAttachShader(CGLFont::m_eProg, ShaderFrg);

	// Setup Position Attribute
	glBindAttribLocation(CGLFont::m_eProg, 0, "att_pos");
	glBindAttribLocation(CGLFont::m_eProg, 1, "att_tex");


	// Linking
	glLinkProgram(CGLFont::m_eProg);
	glGetProgramiv(CGLFont::m_eProg, GL_LINK_STATUS, &hr);
	if(!hr) 
	{
		printf("Couldn't link shader! Exiting...\n");
		return -1;
	}

	return 0;
}


void LgxDev_FontDestroy()
{
	if(CGLFont::m_eProg)
	{
		glDeleteProgram(CGLFont::m_eProg);
		CGLFont::m_eProg = 0;
	}
}

