// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pDev		= NULL;

	m_pMdlOrg1	= NULL;
	m_pMdlIns1	= NULL;

	m_pMdlOrg2	= NULL;
	m_pMdlIns2	= NULL;

	m_pTex3		= NULL;
	m_pEft		= NULL;
}


CMcScene::~CMcScene()
{
	Destroy();
}


void CMcScene::Destroy()
{
	SAFE_DELETE(	m_pMdlOrg1	);
	SAFE_DELETE(	m_pMdlIns1	);

	SAFE_DELETE(	m_pMdlOrg2	);
	SAFE_DELETE(	m_pMdlIns2	);
	
	SAFE_DELETE(	m_pTex3		);
	SAFE_DELETE(	m_pEft		);
}


INT CMcScene::Create(void* p1)
{
	INT	hr=0;

	m_pDev	= (IGLDev*)p1;

	hr = LgDev_CreateEffect("File", &m_pEft, "shaders/lcm.glsv", "shaders/lcm.glsf", "att_pos");
	if(FAILED(hr))
		return -1;



	hr = LcMdl_CreateAse("Ase Text PC", &m_pMdlOrg1, NULL, "Model/dancing.ase");
	if(FAILED(hr))
		return -1;

	m_pMdlOrg1->SetAttrib("Device", m_pDev);
	m_pMdlOrg1->SetAttrib("Effect", m_pEft);


	hr = LcMdl_CreateAse("Ase Text PC", &m_pMdlIns1, NULL, NULL, m_pMdlOrg1);
	if(FAILED(hr))
		return -1;


	
	

	hr = LcMdl_CreateAse("Ase Bin PC", &m_pMdlOrg2, NULL, "Model/dancing.asb");
	if(FAILED(hr))
		return -1;

	m_pMdlOrg2->SetAttrib("Device", m_pDev);
	m_pMdlOrg2->SetAttrib("Effect", m_pEft);



	hr = LcMdl_CreateAse("Ase Bin PC", &m_pMdlIns2, NULL, NULL, m_pMdlOrg2);
	if(FAILED(hr))
		return -1;
	

	hr = LgDev_CreateTexture(NULL, &m_pTex3, "texture/title_03.png", NULL, 0x00FFFFFF, 0);
	if(FAILED(hr))
		return -1;




	return 0;
}


INT CMcScene::FrameMove()
{
	LCXMATRIX	mtRotX;
	LCXMATRIX	mtRotZ;
	LCXMATRIX	mtWld;
	float		fTime = 0;

	DOUBLE		fElapsed = GMAIN->GetElapsed();


	mtRotX.Identity();
	mtRotZ.Identity();
	mtWld.Identity();


	mtRotZ.SetupRotationZ(LCXToRadian(0));
	mtWld.SetupTranslation(-150, 0, 0);
	mtWld = mtRotX * mtRotZ * mtWld;
	fTime = FLOAT(fElapsed*0.4);

	m_pMdlOrg1->SetAttrib("World Matrix", &mtWld);
	m_pMdlOrg1->SetAttrib("Advance Time", &fTime);
	SAFE_FRAMEMOVE(	m_pMdlOrg1	);



	mtWld.Identity();
	mtRotZ.SetupRotationZ(LCXToRadian(-90));
	mtWld.SetupTranslation( 50, 0, 0);
	mtWld = mtRotZ * mtWld;
	fTime = FLOAT(fElapsed*.6f);

	m_pMdlOrg2->SetAttrib("World Matrix", &mtWld);
	m_pMdlOrg2->SetAttrib("Advance Time", &fTime);
	SAFE_FRAMEMOVE(	m_pMdlOrg2	);



	mtWld.Identity();
	mtRotZ.SetupRotationZ(LCXToRadian(90));
	mtWld.SetupTranslation(-50, 0, 0);
	mtWld = mtRotZ * mtWld;
	fTime = FLOAT(fElapsed*1.0f);

	m_pMdlIns1->SetAttrib("World Matrix", &mtWld);
	m_pMdlIns1->SetAttrib("Advance Time", &fTime);
	SAFE_FRAMEMOVE(	m_pMdlIns1	);



	mtWld.Identity();
	mtRotZ.SetupRotationZ(LCXToRadian(-90));
	mtWld.SetupTranslation( 150, 0, 0);
	mtWld = mtRotZ * mtWld;
	fTime = FLOAT(fElapsed*1.2f);

	m_pMdlIns2->SetAttrib("World Matrix", &mtWld);
	m_pMdlIns2->SetAttrib("Advance Time", &fTime);
	SAFE_FRAMEMOVE(	m_pMdlIns2	);

	return 0;
}

void CMcScene::Render()
{
	glDisable(GL_CULL_FACE);


	SAFE_RENDER(	m_pMdlOrg1	);
	SAFE_RENDER(	m_pMdlIns1	);

	SAFE_RENDER(	m_pMdlOrg2	);
	SAFE_RENDER(	m_pMdlIns2	);


	glEnable(GL_CULL_FACE);


	IGLSprite*	pSprite = GMAIN->GetSprite();
	INT nH = m_pTex3->GetImgH();

	RECT	rc={0, nH* 2/4, m_pTex3->GetImgW(), nH* 3/4};
	pSprite->Draw(m_pTex3, &rc, &LCXVECTOR2(2,2), NULL, 0, &LCXVECTOR2(400,300), LCXCOLOR(2,2,2,2.0f));
}




