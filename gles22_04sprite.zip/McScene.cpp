// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pSprite	= NULL;

	m_pTex1	= NULL;
	m_pTex2	= NULL;
	m_pTex3	= NULL;
}


CMcScene::~CMcScene()
{
	Destroy();
}


void CMcScene::Destroy()
{
	SAFE_DELETE(	m_pSprite	);

	SAFE_DELETE(	m_pTex1		);
	SAFE_DELETE(	m_pTex2		);
	SAFE_DELETE(	m_pTex3		);
}


INT CMcScene::Create()
{
	INT hr =0;

	// Create Effect
	hr = LgDev_CreateSprite(NULL, &m_pSprite);

	if(FAILED(hr))
		return -1;

	hr = LgDev_CreateTexture(NULL, &m_pTex1, "texture/title_01.png", NULL, 0, 0);
	if(FAILED(hr))
		return -1;

	hr = LgDev_CreateTexture(NULL, &m_pTex2, "texture/title_02.png", NULL, 0x00FFFFFF, 0);
	if(FAILED(hr))
		return -1;

	hr = LgDev_CreateTexture(NULL, &m_pTex3, "texture/title_03.png", NULL, 0x00FFFFFF, 0);
	if(FAILED(hr))
		return -1;

	return 0;
}


INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	m_pSprite->Draw(m_pTex1, NULL, &LCXVECTOR2(2,2), NULL, 0, NULL, LCXCOLOR(1,1,1,1));
	m_pSprite->Draw(m_pTex2, NULL, &LCXVECTOR2(2,2), NULL, 0, &LCXVECTOR2(158,184), LCXCOLOR(1,1,1,0.8f));

	INT nH = m_pTex3->GetImgH();

	RECT	rc={0, nH* 2/4, m_pTex3->GetImgW(), nH* 3/4};
	m_pSprite->Draw(m_pTex3, &rc, &LCXVECTOR2(2,2), NULL, 0, &LCXVECTOR2(400,300), LCXCOLOR(2,2,2,2.0f));
}




