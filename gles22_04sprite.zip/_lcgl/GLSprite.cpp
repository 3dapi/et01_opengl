// Implementation of the CGLSprite class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include "GLES2/gl2.h"

#include "../_lcgl/GLMath.h"

#include "IGLTexture.h"
#include "IGLSprite.h"


class CGLSprite : public IGLSprite
{
protected:
	GLuint	m_eProg;

public:
	CGLSprite();
	virtual ~CGLSprite();

	virtual INT		Create();
	virtual void	Destroy();

	virtual INT Draw(	IGLTexture* pTx	// Texture Pointer
			,	RECT* rc				// Image rect
			,	LCXVECTOR2* vcScl		// Scaling
			,	LCXVECTOR2* vcRot		// Rotation Center
			,	FLOAT fRot				// Angle(Radian)
			,	LCXVECTOR2* vcTrns		// Position
			,	LCXCOLOR dColor			// color
			);
};



CGLSprite::CGLSprite()
{
	m_eProg = 0;
}


CGLSprite::~CGLSprite()
{
	Destroy();
}

void CGLSprite::Destroy()
{
	if(m_eProg)
	{
		glDeleteProgram(m_eProg);
		m_eProg = 0;
	}
}



INT CGLSprite::Create()
{
	INT hr =0;

	GLuint ShaderVtx = 0;
	GLuint ShaderFrg = 0;

	const char* sSrc = 0;
	INT			iLen = 0;

	char	sShaderVtx[] =
	"attribute vec2 att_pos;			\n"
	"attribute vec2 att_tex;			\n"

	"varying vec2	frg_tex;			\n"

	"void main()						\n"
	"{									\n"
	"	gl_Position.x = att_pos.x;		\n"
	"	gl_Position.y = att_pos.y;		\n"
	"	gl_Position.z = 0.0;			\n"
	"	gl_Position.w = 1.0;			\n"
	
	"	frg_tex	= att_tex;				\n"
	"}									\n"
	;


	char	sShaderFrg[] =
	"precision mediump float;					\n"

	"uniform sampler2D	sampler;				\n"
	"uniform vec4		frg_col;				\n"

	"varying vec2		frg_tex;				\n"

	"void main()								\n"
	"{											\n"
	"	vec4 Out;								\n"
	"	vec4 tex = texture2D(sampler,frg_tex);	\n"

	"	Out	= frg_col;							\n"
	"	Out	*= tex;								\n"

	"	if(Out.a<0.01)							\n"
	"	{										\n"
	"		discard;							\n"
	"		return;								\n"
	"	}										\n"

	"	gl_FragColor = Out;						\n"
	"}											\n"

	;

	// Create Vertex and Fragment Shader
	ShaderVtx = glCreateShader(GL_VERTEX_SHADER);
	if(0 == ShaderVtx)
	{
		printf("Couldn't Create Sprite Vertex Shader.\n\n");
		return -1;
	}

	ShaderFrg = glCreateShader(GL_FRAGMENT_SHADER);
	if(0 == ShaderFrg)
	{
		printf("Couldn't Create Sprite Fragment Shader.\n\n");
		return -1;
	}

	// Compile Vertex Shader
	sSrc = sShaderVtx;	// glShaderSource() �Լ� ���ο��� �����͸� �̵��ϴ°� ����. �迭�� �ּҸ� ���� ������ Error
	iLen = strlen(sSrc);

	glShaderSource(ShaderVtx, 1, (const char**)&sSrc, &iLen);
	glCompileShader(ShaderVtx);
	glGetShaderiv(ShaderVtx, GL_COMPILE_STATUS, &hr);
	if(!hr) 
	{
		glGetShaderiv(ShaderVtx, GL_INFO_LOG_LENGTH, &hr);
		char* sLog = (char*)malloc (sizeof(char) * (hr+4) );
		memset(sLog, 0, hr+4);
		glGetShaderInfoLog ( ShaderVtx, hr, NULL, sLog );
		printf("Compile Sprite Shader Failed: %s.\n\n", sLog);
		free(sLog);
	}


	// Compile Vertex Shader
	sSrc = sShaderFrg;
	iLen = strlen(sSrc);

	glShaderSource(ShaderFrg, 1, (const char**)&sSrc, &iLen);
	glCompileShader(ShaderFrg);
	glGetShaderiv(ShaderFrg, GL_COMPILE_STATUS, &hr);
	if(!hr) 
	{
		glGetShaderiv(ShaderFrg, GL_INFO_LOG_LENGTH, &hr);
		char* sLog = (char*)malloc (sizeof(char) * (hr+4) );
		memset(sLog, 0, hr+4);
		glGetShaderInfoLog (ShaderFrg, hr, NULL, sLog );
		printf("Compile Sprite Fragment Shader Failed: %s.\n\n", sLog);
		free(sLog);
	}


	// Create Program Object
	m_eProg = glCreateProgram();

	if(0 == m_eProg)
		return -1;


	// Attach
	glAttachShader(m_eProg, ShaderVtx);
	glAttachShader(m_eProg, ShaderFrg);

	// Setup Position Attribute
	glBindAttribLocation(m_eProg, 0, "att_pos");
	glBindAttribLocation(m_eProg, 1, "att_tex");


	// Linking
	glLinkProgram(m_eProg);
	glGetProgramiv(m_eProg, GL_LINK_STATUS, &hr);
	if(!hr) 
	{
		printf("Couldn't link shader! Exiting...\n");
		return -1;
	}

	return 0;
}



INT CGLSprite::Draw(IGLTexture* pTx			// Texture Pointer
					, RECT* rc				// Image rect
					, LCXVECTOR2* vcScl		// Scaling
					, LCXVECTOR2* vcRot		// Rotation Center
					, FLOAT fRot			// Angle(Radian)
					, LCXVECTOR2* vcTrn		// Position
					, LCXCOLOR dColor		// color
					)
{
	FLOAT f[ 4]={0};


	LCXVECTOR2	st0(0,0);	// �ؽ�ó ��ǥ �� �ϴ�
	LCXVECTOR2	st1(1,1);	// �ؽ�ó ��ǥ �� ���

	FLOAT	PosL = 0;		// ��ġ Left
	FLOAT	PosT = 0;		// ��ġ Top
	FLOAT	PosR = 0;		// ��ġ Right
	FLOAT	PosB = 0;		// ��ġ Bottom

	FLOAT	ImgW = (FLOAT)pTx->GetImgW();
	FLOAT	ImgH = (FLOAT)pTx->GetImgH();
	INT		nTex = (INT  )pTx->GetName();

	FLOAT	rcW= ImgW;
	FLOAT	rcH= ImgH;


	LCXVECTOR2	vScl(1,1);
	LCXVECTOR2	vRot(0,0);
	LCXVECTOR2	vTrn(0,0);

	// ������ �̹��� ������ ���ؼ� UV�� ����Ѵ�.
	if(rc)
	{
		rcW= FLOAT(rc->right - rc->left);
		rcH= FLOAT(rc->bottom- rc->top);

		st0.x = rc->left/ImgW;				// �� �ϴ� S
		st0.y = 1.0f - rc->bottom/ImgH;		// �� �ϴ� T

		st1.x = rc->right /ImgW;			// �� ��� S
		st1.y = 1.0f - rc->top/ImgH;		// �� ��� T
	}

	if(vcScl)	vScl = *vcScl;
	if(vcRot)	vRot = *vcRot;
	if(vcTrn)	vTrn = *vcTrn;


	// ����Ʈ���� ȭ���� ũ�⸦ ��´�.
	glGetFloatv(GL_VIEWPORT, f);

	
	// ���� ��ȯ�� x, y�� ����� �Ѵ�.
	PosL =  2.0f * vTrn.x/f[2] - 1.0f;		// Left
	PosT = -2.0f * vTrn.y/f[3] + 1.0f;		// Top
	PosR = PosL + 2.0f * rcW * vScl.x/f[2];	// Right
	PosB = PosT - 2.0f * rcH * vScl.y/f[3];	// Bottom


	LCXVEC2i	s_pos[4];
	LCXVEC2i	s_tex[4];

	s_pos[0] = LCXVEC2i(FixedD(PosL), FixedD(PosB) );
	s_pos[1] = LCXVEC2i(FixedD(PosR), FixedD(PosB) );
	s_pos[2] = LCXVEC2i(FixedD(PosR), FixedD(PosT) ); 
	s_pos[3] = LCXVEC2i(FixedD(PosL), FixedD(PosT) ); 

	s_tex[0] = LCXVEC2i(FixedD(st0.x), FixedD(st0.y) );
	s_tex[1] = LCXVEC2i(FixedD(st1.x), FixedD(st0.y) );
	s_tex[2] = LCXVEC2i(FixedD(st1.x), FixedD(st1.y) ); 
	s_tex[3] = LCXVEC2i(FixedD(st0.x), FixedD(st1.y) ); 



	glDisable(GL_DEPTH_TEST);


	// Blending Ȱ��ȭ
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	glUseProgram(m_eProg);
	glEnableVertexAttribArray(0);	glVertexAttribPointer(0, 2, GL_FIXED, GL_TRUE, 0, s_pos);
	glEnableVertexAttribArray(1);	glVertexAttribPointer(1, 2, GL_FIXED, GL_TRUE, 0, s_tex);

	INT	nFrg_Col = glGetUniformLocation(m_eProg, "frg_col");
	glUniform4fv(nFrg_Col, 4, (GLfloat*)&dColor);


	
	int	nFrg_Smp = glGetUniformLocation(m_eProg, "sampler");
	glEnable(GL_TEXTURE_2D);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture (GL_TEXTURE_2D, nTex);
//	glTexParameteri ( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
//	glTexParameteri ( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
//	glTexParameteri ( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
//	glTexParameteri ( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

	glUniform1i(nFrg_Smp, 0);


	glDrawArrays(GL_TRIANGLE_FAN, 0, 4);
	

	glUseProgram(0);

	glBindTexture (GL_TEXTURE_2D, 0);
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);
	glEnable(GL_DEPTH_TEST);

	return 0;
}


INT LgDev_CreateSprite(char* sCmd, IGLSprite** pData)
{
	*pData = NULL;

	CGLSprite* pObj = new CGLSprite;

	if(FAILED(pObj->Create()))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}