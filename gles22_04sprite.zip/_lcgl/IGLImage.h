// Interface for the IGLImage class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _IGLImage_H_
#define _IGLImage_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
	virtual ~CLASS_NAME(){}
#endif


interface IGLImage
{
	LC_CLASS_DESTROYER(	IGLImage	);

	virtual	INT		Create(char* sFile)=0;
	virtual	void	Destroy()=0;

	virtual	INT		GetType()=0;
	virtual	INT		GetImgW()=0;
	virtual	INT		GetImgH()=0;
	virtual	BYTE* const	GetPixel() const=0;


	enum EImageType
	{
		IMG_UNKNOWN	= 0,
		IMG_BMP		,
		IMG_TGA		,
		IMG_PNG		,
	};
};


INT LgDev_CreateImage(char* sCmd
					, IGLImage** pData
					, char* sFile);


#endif