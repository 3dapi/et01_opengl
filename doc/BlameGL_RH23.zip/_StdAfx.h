#ifndef __STDAFX_H_
#define __STDAFX_H_


#define _WIN32_WINNT	0x0400


#pragma comment(lib, "comctl32.lib")
#pragma comment(lib, "dsound.lib")
#pragma comment(lib, "d3dx9.lib")
#pragma comment(lib, "Opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "glaux.lib")
#pragma comment(lib, "Winmm.lib")


#include <list>
#include <cstdlib>
#include <ctime>

using namespace std;

#include <windows.h>

#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include <gl/gl.h>						// standard OpenGL include
#include <gl/glu.h>						// OpenGL utilties
#include <gl/glaux.h>					// OpenGL auxiliary functions
#include <gl/glext.h>

//#include <gl/glut.h>

#include "resource.h"

#include "_GL/BaseType.h"
#include "_GL/GLMath.h"
#include "_GL/GLUtil.h"

#include "_GL/IGLTexture.h"
#include "_GL/IGLFont.h"
#include "_GL/IGLSprite.h"
#include "_GL/GLApp.h"

#include "_LcEnt/ILcInput.h"
#include "_LcEnt/ILcCam.h"
#include "_LcEnt/ILcxGrid.h"
#include "_LcmAse/ILcMdl.h"



#include "Main.h"

#endif