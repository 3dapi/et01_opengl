// Interface for the ILcxGrid class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILcxGrid_H_
#define _ILcxGrid_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
	virtual ~CLASS_NAME(){}
#endif


interface ILcxGrid
{
	LC_CLASS_DESTROYER(	ILcxGrid	);

	virtual INT		Create() =0;
	virtual void	Destroy() =0;
	virtual INT		FrameMove() =0;
	virtual void	Render() =0;
};


INT LcxEnt_CreateGrid(char* sCmd, ILcxGrid** pData);

#endif


