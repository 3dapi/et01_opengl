// Interface for the CLcxGrid class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _LcxGrid_H_
#define _LcxGrid_H_


class CLcxGrid : public ILcxGrid
{
protected:
	
public:
	CLcxGrid();
	virtual ~CLcxGrid();

	virtual	INT		Create();
	virtual	void	Destroy();
	virtual	INT		FrameMove();
	virtual	void	Render();
};

#endif

