// Implementation of the CLcCam class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include <gl/gl.h>						// standard OpenGL include
#include <gl/glu.h>						// OpenGL utilties
#include <gl/glaux.h>					// OpenGL auxiliary functions

#include "../_GL/GLMath.h"
#include "ILcCam.h"
#include "LcCam.h"


CLcCam::CLcCam()
{

}

CLcCam::~CLcCam()
{

}


INT CLcCam::Create(FLOAT ScnW, FLOAT ScnH)
{
	m_fYaw		= 0.f;
	m_fPitch	= 0.f;
	m_vcEye		= LCXVECTOR3(30, 30, -100);
	m_vcLook	= LCXVECTOR3(5, 10,6);

	m_vcEye		= LCXVECTOR3(10, -390, 40);
	m_vcLook	= LCXVECTOR3(0, 0,0);
	
	m_vcUp		= LCXVECTOR3(0,0,1);

	m_nScnW		= ScnW;
	m_nScnH		= ScnH;

	m_fFv		= 45.f;
	m_fAs		= FLOAT(m_nScnW )/FLOAT(m_nScnH );
	m_fNr		= 1.f;
	m_fFr		= 5000.f;

	m_mtPrj.SetupPerspectiveRH(m_fFv, m_fAs, m_fNr, m_fFr);
	m_mtViw.SetupViewRH(&m_vcEye, &m_vcLook, &m_vcUp);

	return 0;
}


INT CLcCam::FrameMove()
{
	m_mtViwI.Inverse(&m_mtViw);
	
	m_mtBill = m_mtViwI;
	m_mtBill._41 = m_mtBill._42 = m_mtBill._43 = 0;								// Bill board Matrix
	
	m_vcEye		= LCXVECTOR3( m_mtViwI._41, m_mtViwI._42, m_mtViwI._43);				// Camera Position ReSetting
	m_mtVwPj	= m_mtViw * m_mtPrj;

	LCXVECTOR3 vcLf = -LCXVECTOR3(m_mtVwPj._14 + m_mtVwPj._11, m_mtVwPj._24 + m_mtVwPj._21, m_mtVwPj._34 + m_mtVwPj._31);		// Left
	LCXVECTOR3 vcRg = -LCXVECTOR3(m_mtVwPj._14 - m_mtVwPj._11, m_mtVwPj._24 - m_mtVwPj._21, m_mtVwPj._34 - m_mtVwPj._31);		// Right
	LCXVECTOR3 vcTp = -LCXVECTOR3(m_mtVwPj._14 - m_mtVwPj._12, m_mtVwPj._24 - m_mtVwPj._22, m_mtVwPj._34 - m_mtVwPj._32);		// Top
	LCXVECTOR3 vcBt = -LCXVECTOR3(m_mtVwPj._14 + m_mtVwPj._12, m_mtVwPj._24 + m_mtVwPj._22, m_mtVwPj._34 + m_mtVwPj._32);		// Bottom
	LCXVECTOR3 vcNr = -LCXVECTOR3(m_mtViwI._31, m_mtViwI._32, m_mtViwI._33);				// Near
	LCXVECTOR3 vcFr = -vcNr;															// Far
	LCXVECTOR3 vcZn = m_vcEye + vcNr * m_fNr;
	LCXVECTOR3 vcZf = m_vcEye + vcNr * m_fFr;

	m_Frsm[0].SetupFromPointNormal(&vcZn	, &vcNr);			// Near Plane
	m_Frsm[1].SetupFromPointNormal(&vcZf	, &vcFr);			// Far Plane
	m_Frsm[2].SetupFromPointNormal(&m_vcEye	, &vcLf);			// Left Plane
	m_Frsm[3].SetupFromPointNormal(&m_vcEye	, &vcRg);			// Right Plane
	m_Frsm[4].SetupFromPointNormal(&m_vcEye	, &vcTp);			// Top Plane
	m_Frsm[5].SetupFromPointNormal(&m_vcEye	, &vcBt);			// Bottom Plane
	
	return 0;
}

void CLcCam::MoveSideward(FLOAT fSpeed)
{
	LCXVECTOR3 vcY = m_vcLook - m_vcEye;
	vcY.Normalize();

	LCXVECTOR3 vcX;

	vcX = vcY ^ m_vcUp;
	vcX.Normalize();

	m_vcEye  -= vcX * fSpeed;
	m_vcLook -= vcX * fSpeed;
	m_mtViw.SetupViewRH(&m_vcEye, &m_vcLook, &m_vcUp);
}


void CLcCam::MoveForward(FLOAT fSpeed, FLOAT fD)
{
	LCXVECTOR3 tmp(m_mtViw._12, m_mtViw._22, m_mtViw._32);
	tmp.Normalize();

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
	m_mtViw.SetupViewRH(&m_vcEye, &m_vcLook, &m_vcUp);
}



void CLcCam::Rotation(FLOAT fYaw, FLOAT fPitch, FLOAT fSpeed)
{
	m_fYaw   = -LCXToRadian(fYaw  * fSpeed);
	m_fPitch = LCXToRadian(fPitch* fSpeed);
	
	LCXMATRIX rot;
	LCXVECTOR3 vcY = m_vcLook-m_vcEye;
	LCXVECTOR3 vcX;
	rot.SetupRotationZ(m_fYaw);

	rot.TransformCoord(&vcY, &vcY);
	rot.TransformCoord(&m_vcUp, &m_vcUp);

	
	m_vcLook = vcY + m_vcEye;
	m_mtViw.SetupViewRH(&m_vcEye, &m_vcLook, &m_vcUp);

	
	vcY = m_vcLook - m_vcEye;
	vcX =LCXVECTOR3(m_mtViw._11, m_mtViw._21, m_mtViw._31);
	
	rot.SetupRotationAxis(&vcX, m_fPitch);
	rot.TransformCoord(&vcY, &vcY);
	rot.TransformCoord(&m_vcUp, &m_vcUp);

	m_vcLook = vcY + m_vcEye;
	m_mtViw.SetupViewRH(&m_vcEye, &m_vcLook, &m_vcUp);
}


void CLcCam::TransformProj()
{
	glViewport(0, 0, INT(m_nScnW), INT(m_nScnH) );		// set the viewport to the new dimensions
	glMatrixMode(GL_PROJECTION);						// select the projection matrix and clear it out
	glLoadIdentity();
	gluPerspective(m_fFv, m_fAs , m_fNr, m_fFr);
}


void CLcCam::TransformView()
{
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	LCXMATRIX mtViw;
	
//	LCXMATRIX mtViwT;
//	LCXVECTOR3	vcUp(m_mtViw._13, m_mtViw._23, m_mtViw._33);
//
//	gluLookAt(	m_vcEye.x	,	m_vcEye.y	,	m_vcEye.z	,
//				m_vcLook.x	,	m_vcLook.y	,	m_vcLook.z	,
//				vcUp.x		,	vcUp.y		,	vcUp.z
//				);
//
//	glGetFloatv(GL_MODELVIEW_MATRIX, (float*)&mtViwT);

	mtViw._11 = m_mtViw._11;	mtViw._12 = m_mtViw._13;	mtViw._13 = -m_mtViw._12;	mtViw._14 = -m_mtViw._14;
	mtViw._21 = m_mtViw._21;	mtViw._22 = m_mtViw._23;	mtViw._23 = -m_mtViw._22;	mtViw._24 = -m_mtViw._24;
	mtViw._31 = m_mtViw._31;	mtViw._32 = m_mtViw._33;	mtViw._33 = -m_mtViw._32;	mtViw._34 = -m_mtViw._34;
	mtViw._41 = m_mtViw._41;	mtViw._42 = m_mtViw._43;	mtViw._43 = -m_mtViw._42;	mtViw._44 = m_mtViw._44;


	glLoadMatrixf((float*)&mtViw);




	int c;
	c=0;
}




INT LcEnt_CreateCamera(char* sCmd, ILcCam** pData, FLOAT ScnW, FLOAT ScnH)
{
	*pData = NULL;

	CLcCam* pObj = new CLcCam;

	if(FAILED(pObj->Create(ScnW, ScnH)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}