// Interface for the ILcInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILcInput_H_
#define _ILcInput_H_


#ifndef interface
#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
	virtual ~CLASS_NAME(){}
#endif


interface ILcInput
{
	LC_CLASS_DESTROYER(	ILcInput	);

	enum
	{
		EINPUT_NONE  = 0,
		EINPUT_DOWN  = 1,
		EINPUT_UP	 = 2,
		EINPUT_PRESS = 3,
		EINPUT_DBCLC = 4,
	};

	enum
	{
		MAX_INPUT_KEY	= 256,
		MAX_INPUT_BTN	=   8,
	};


	virtual INT		Create(HWND	hWnd) =0;
	virtual INT		FrameMove() =0;
	virtual LRESULT	MsgProc(HWND, UINT, WPARAM, LPARAM) =0;

	virtual BOOL	KeyDown	(INT nKey) =0;
	virtual BOOL	KeyUp	(INT nKey) =0;
	virtual BOOL	KeyPress(INT nKey) =0;
	virtual INT		KeyState(INT nKey) =0;

	virtual BOOL	BtnDown	(INT nBtn) =0;
	virtual BOOL	BtnUp	(INT nBtn) =0;
	virtual BOOL	BtnPress(INT nBtn) =0;
	virtual INT		BtnState(INT nBtn) =0;

	virtual const LCXVECTOR3* GetMousePos() const =0;
	virtual const LCXVECTOR3* GetMouseEps() const =0;
};


INT LcEnt_CreateInput(char* sCmd, ILcInput** pData, HWND hWnd);

#endif

