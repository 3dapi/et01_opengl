// Implementation of the CLcxGrid class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include <gl/gl.h>
#include <gl/glu.h>

#include "../_GL/GLMath.h"
#include "ILcxGrid.h"
#include "LcxGrid.h"



CLcxGrid::CLcxGrid()
{

}

CLcxGrid::~CLcxGrid()
{

}

void CLcxGrid::Destroy()
{
}

INT CLcxGrid::Create()
{
	return 0;
}


INT CLcxGrid::FrameMove()
{
	return 0;
}

void CLcxGrid::Render()
{
	glPushMatrix();
		glDisable(GL_TEXTURE_2D);
		glDisable(GL_LIGHTING);

		glLineWidth(1.2f);
//		glEnable(GL_LINE_SMOOTH);
//		glEnable(GL_LINE_STIPPLE_PATTERN);


		glBegin(GL_LINES);
		{
			for(INT i = -10; i <=10; i++)
			{
				if(0==i)
					continue;

				glColor3f(.5f, .5f, .5f);
				glVertex3f(i*20.f, -200.f, 0.f);	glVertex3f(i*20.f, 0.f   , 0.f);
				glVertex3f(i*20.f,  200.f, 0.f);	glVertex3f(i*20.f, 0.f   , 0.f);

				glVertex3f(-200.f, i*20.f, 0.f);	glVertex3f(   0.f, i*20.f, 0.f);
				glVertex3f( 200.f, i*20.f, 0.f);	glVertex3f(   0.f, i*20.f, 0.f);
			}

			glColor3f(.5f, 0.f, 0.f);	glVertex3f(-5000.f,    0.f,    0.f);	glVertex3f(0.f, 0.f, 0.f);
			glColor3f(1.f, 0.f, 0.f);	glVertex3f( 5000.f,    0.f,    0.f);	glVertex3f(0.f, 0.f, 0.f);

			glColor3f(0.f, .5f, 0.f);	glVertex3f(	   0.f,-5000.f,    0.f);	glVertex3f(0.f, 0.f, 0.f);
			glColor3f(0.f, 1.f, 0.f);	glVertex3f(	   0.f, 5000.f,    0.f);	glVertex3f(0.f, 0.f, 0.f);
			
			glColor3f(0.f, 0.f, .5f);	glVertex3f(	   0.f,    0.f,-5000.f);	glVertex3f(0.f, 0.f, 0.f);
			glColor3f(0.f, 0.f, 1.f);	glVertex3f(	   0.f,    0.f, 5000.f);	glVertex3f(0.f, 0.f, 0.f);
		}
		glEnd();

	glPopMatrix();

	glColor3f(1.f, 1.f, 1.f);
	
}



INT LcxEnt_CreateGrid(char* sCmd, ILcxGrid** pData)
{
	*pData = NULL;

	CLcxGrid* pObj = new CLcxGrid;

	if(FAILED(pObj->Create()))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}