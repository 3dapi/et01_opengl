// Interface for the CLcCam class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _LcCam_H_
#define _LcCam_H_


class CLcCam : public ILcCam
{
protected:
	FLOAT		m_fFv;				// Field of View
    FLOAT		m_fAs;				// Aspect Ratio
    FLOAT		m_fNr;				// Near
    FLOAT		m_fFr;				// Far

	FLOAT		m_nScnW;			// Screen Width
	FLOAT		m_nScnH;			// Screen Height

	LCXVECTOR3	m_vcEye;			// Camera position
	LCXVECTOR3	m_vcLook;			// Look vector
	LCXVECTOR3	m_vcUp;				// up vector

	FLOAT		m_fYaw;
	FLOAT		m_fPitch;

	LCXMATRIX	m_mtViw;			// View Matrix
	LCXMATRIX	m_mtPrj;			// Projection Matrix

	LCXMATRIX	m_mtViwI;			// View Matrix Inverse
	LCXMATRIX	m_mtBill;			// BillBoard Matrix
	LCXMATRIX	m_mtVwPj;			// m_mtViw * m_mtPrj;
	
	LCXPLANE	m_Frsm[6];			// Near, Far, Left, Right, Up, Down
	
public:
	CLcCam();
	virtual ~CLcCam();

	virtual	INT		Create(FLOAT ScnW, FLOAT ScnH);
	virtual	INT		FrameMove();

	virtual	const LCXMATRIX*	GetMatrixViw()	const	{	return &m_mtViw;		}
	virtual	const LCXMATRIX*	GetMatrixViwI()	const	{	return &m_mtViwI;	}
	virtual	const LCXMATRIX*	GetMatrixBll()	const	{	return &m_mtBill;	}
	virtual	const LCXMATRIX*	GetMatrixPrj()	const	{	return &m_mtPrj;		}
	virtual	const LCXMATRIX*	GetMatrixViwPrj()const	{	return &m_mtVwPj;	}

	virtual	const LCXVECTOR3*	GetEye()	const		{	return &m_vcEye;		}
	virtual	const LCXVECTOR3*	GetLook()	const		{	return &m_vcLook;	}
	virtual	const LCXVECTOR3*	GetUp()		const		{	return &m_vcUp;		}

public:
	virtual	void	MoveSideward(FLOAT	fSpeed);
	virtual	void	MoveForward	(FLOAT	fSpeed, FLOAT fY=0);
	virtual	void	Rotation(FLOAT fYaw, FLOAT fPitch, FLOAT fSpeed);

	virtual	void	TransformProj();
	virtual	void	TransformView();
};

#endif
