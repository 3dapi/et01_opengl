// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMain::CMain()
{
	m_dWinIcon	= IDI_ICON;
	m_dWinAccl	= IDR_ACCELERATOR;
	m_dWinMode	= IDA_CHANGE_WINDOW;
	m_dWinExit	= IDA_EXIT;

	m_dScnW		= 800	;	// Screen Width
	m_dScnH		= 600	;	// Screen Height

	m_pCam		= NULL;
	m_pInput	= NULL;
	m_pFont		= NULL;

	m_pGrid		= NULL;
	m_pTex		= NULL;

	m_pMdlOrg1	= NULL;
	m_pMdlIns1	= NULL;

	m_pMdlOrg2	= NULL;
	m_pMdlIns2	= NULL;
}


HRESULT CMain::Init()
{
	if(FAILED(LcEnt_CreateCamera(NULL, &m_pCam, GMAIN->GetScnW(), GMAIN->GetScnH() )))
		return -1;

	if(FAILED(LcEnt_CreateInput(NULL, &m_pInput, m_hWnd )))
		return -1;

	if(FAILED(LgDev_CreateFont(NULL, &m_pFont, m_hDC, "Arial", 18)))
		return -1;


	if(FAILED(LcxEnt_CreateGrid(NULL, &m_pGrid)))
		return -1;


	if(FAILED(LgDev_CreateTexture(NULL, &m_pTex, "Texture/mario2.tga", 0x00FFFFFF)))
		return -1;


	if(FAILED( LcMdl_CreateAse("Ase Text PC", &m_pMdlOrg1, NULL, "Model/test.ASE")))
		return -1;

	if(FAILED( LcMdl_CreateAse("Ase Text PC", &m_pMdlIns1, NULL, NULL, m_pMdlOrg1)))
		return -1;


	if(FAILED( LcMdl_CreateAse("Ase Bin PC", &m_pMdlOrg2, NULL, "Model/test.ASb")))
		return -1;

	if(FAILED( LcMdl_CreateAse("Ase Bin PC", &m_pMdlIns2, NULL, NULL, m_pMdlOrg2)))
		return -1;

	return 0;
}


HRESULT CMain::Destroy()
{
	SAFE_DELETE(	m_pCam		);
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pFont		);
	SAFE_DELETE(	m_pGrid		);

	SAFE_DELETE(	m_pTex		);

	SAFE_DELETE(	m_pMdlOrg1	);
	SAFE_DELETE(	m_pMdlIns1	);

	SAFE_DELETE(	m_pMdlOrg2	);
	SAFE_DELETE(	m_pMdlIns2	);

	return 0;
}

HRESULT CMain::FrameMove()
{
	SAFE_FRMOV(	m_pInput	);

	LCXVECTOR3	vcDelta = m_pInput->GetMouseEps();

	FLOAT	fSpeedMov  = 200.f * 0.01F;
	FLOAT	fSpeedRot  =  0.1f;
	FLOAT	fSpeedWheel=  10.f * 0.01F;

	if(vcDelta.z !=0.f)
	{
		m_pCam->MoveForward(-vcDelta.z* fSpeedWheel, 1.f);
	}

	if(m_pInput->KeyPress('W'))					// W
		m_pCam->MoveForward( fSpeedMov, 1.f);

	if(m_pInput->KeyPress('S'))					// S
		m_pCam->MoveForward(-fSpeedMov, 1.f);

	if(m_pInput->KeyPress('A'))					// A
		m_pCam->MoveSideward(fSpeedMov);

	if(m_pInput->KeyPress('D'))					// D
		m_pCam->MoveSideward(-fSpeedMov);

	if(m_pInput->BtnPress(1))
		m_pCam->Rotation(vcDelta.x, vcDelta.y, fSpeedRot);


	SAFE_FRMOV(	m_pCam		);
	SAFE_FRMOV(	m_pGrid		);


	LCXMATRIX	mtRotX;
	LCXMATRIX	mtRotZ;
	LCXMATRIX	mtWld;
	float	fTime = 0;



	mtWld.Identity();
	mtRotZ.SetupRotationZ(LCXToRadian(0));
	mtWld.SetupTranslation( &LCXVECTOR3(-90, 0, 0), FALSE);
	mtWld = mtRotX * mtRotZ * mtWld;
	fTime = m_fElapsed*0.8;

	m_pMdlOrg1->SetAttrib("World Matrix", &mtWld);
	m_pMdlOrg1->SetAttrib("Advance Time", &fTime);
	SAFE_FRAMEMOVE(	m_pMdlOrg1	);


	mtWld.Identity();
	mtRotZ.SetupRotationZ(LCXToRadian(90));
	mtWld.SetupTranslation(&LCXVECTOR3(-30, 0, 0), FALSE);
	mtWld = mtRotZ * mtWld;
	fTime = m_fElapsed*.4;

	m_pMdlIns1->SetAttrib("World Matrix", &mtWld);
	m_pMdlIns1->SetAttrib("Advance Time", &fTime);
	SAFE_FRAMEMOVE(	m_pMdlIns1	);


//	float v1;
//	float v2;
//	m_pMdlOrg1->GetVal("Current Time", &v1);
//	m_pMdlIns1->GetVal("Current Time", &v2);
//	McUtil_SetWindowTitle("%f %f", v1, v2);
//
	mtWld.Identity();
	mtRotZ.SetupRotationZ(LCXToRadian(-90));
	mtWld.SetupTranslation(&LCXVECTOR3(30, 0, 0), FALSE);
	mtWld = mtRotZ * mtWld;
	fTime = m_fElapsed*.6f;

	m_pMdlOrg2->SetAttrib("World Matrix", &mtWld);
	m_pMdlOrg2->SetAttrib("Advance Time", &fTime);
	SAFE_FRAMEMOVE(	m_pMdlOrg2	);


	mtWld.Identity();
	mtRotZ.SetupRotationZ(LCXToRadian(-90));
	mtWld.SetupTranslation(&LCXVECTOR3(90, 0, 0), FALSE);
	mtWld = mtRotZ * mtWld;
	fTime = m_fElapsed*1.f;

	m_pMdlIns2->SetAttrib("World Matrix", &mtWld);
	m_pMdlIns2->SetAttrib("Advance Time", &fTime);
	SAFE_FRAMEMOVE(	m_pMdlIns2	);

	return 0;
}



HRESULT CMain::Render()
{
	glClearColor (0.0,0.4f,0.6f,1.f);
	glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);


	m_pCam->TransformProj();
	m_pCam->TransformView();

	SAFE_RENDER(	m_pGrid	);

	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
//	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	glDisable(GL_CULL_FACE);
//	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);

	SAFE_RENDER(	m_pGrid		);



	glColor4f(1,1,1,1);
	SAFE_RENDER(	m_pMdlOrg1	);
	SAFE_RENDER(	m_pMdlIns1	);

	SAFE_RENDER(	m_pMdlOrg2	);
	SAFE_RENDER(	m_pMdlIns2	);


	LCXVECTOR3	Eye  = *m_pCam->GetEye();

	McUtil_SetWindowTitle("%f %f %f", Eye.x, Eye.y, Eye.z);


	RECT	rc={300, 0, 400, 128};
	m_pTex->DrawPixel(&rc, &LCXVECTOR2(1, 1), NULL, 0, &LCXVECTOR2(700, 450), 0xFFFFFFFF);

	FLOAT	fFps = this->GetFPS();

	char	sBuf[128]={0};
	sprintf(sBuf, "FPS: %.f", fFps);
	m_pFont->DrawText(10, 10, 0xFFFF00FF, sBuf);


	return 0;
}



LRESULT CMain::MsgProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	if(m_pInput )
		m_pInput->MsgProc(hWnd, uMsg, wParam, lParam);

	return CGLApp::MsgProc(hWnd, uMsg, wParam, lParam);
}