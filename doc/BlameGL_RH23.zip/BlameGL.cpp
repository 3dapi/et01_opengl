

#include "_StdAfx.h"


CMain* g_pApp  = NULL;


void LcUtil_SetCurrentDirectory()
{
	char	sExe1[512];
	char	sExe2[512];

	memset(sExe1, 0, sizeof(sExe1));
	memset(sExe2, 0, sizeof(sExe2));

	strcpy(sExe1, GetCommandLine());

	INT	iLen = strlen(sExe1);

	INT k=0;

	for(INT i=0; i<iLen; ++i)
	{
		if('"' == sExe1[i])
		{
			++k;
			continue;
		}

		if(2==k)
			break;

		sExe2[i-k] = sExe1[i];
		if('\\' == sExe2[i-k])
			sExe2[i-k] ='/';
	}

	char*pdest;
	
	pdest = strrchr(sExe2, '/');

	INT result;
	result = pdest - sExe2;

	sExe2[result] =0;

	BOOL hr = ::SetCurrentDirectory(sExe2);
}


INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR, INT )
{
	CMain AppMain;
	g_pApp  = &AppMain;

	LcUtil_SetCurrentDirectory();
	
	InitCommonControls();
	if( FAILED( AppMain.Create( hInst ) ) )
		return 0;
	
	return AppMain.Run();
}