// Implementation of the CGLSprite class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>

#include <gl/gl.h>						// standard OpenGL include
#include <gl/glu.h>						// OpenGL utilties

#include "GLMath.h"
#include "IGLTexture.h"
#include "GLTexture.h"

#include "IGLSprite.h"
#include "GLSprite.h"


CGLSprite::~CGLSprite()
{

}

INT CGLSprite::Create()
{
	return 0;
}

INT CGLSprite::Draw(IGLTexture* pTx			// Texture Pointer
					, RECT* rc				// Image rect
					, LCXVECTOR2* vcScl		// Scaling
					, LCXVECTOR2* vcRot		// Rotation Center
					, FLOAT fRot			// Angle(Radian)
					, LCXVECTOR2* vcTrn		// Position
					, LCXCOLOR dcolor		// color
					)
{
	FLOAT f[ 4]={0};

	FLOAT	PosL = 0;
	FLOAT	PosT = 0;
	FLOAT	PosR = 0;
	FLOAT	PosB = 0;

	FLOAT	ImgW = (FLOAT)pTx->GetImgW();
	FLOAT	ImgH = (FLOAT)pTx->GetImgH();
	INT		nId = pTx->GetName();

	LCXVECTOR2	vScl(1,1);
	LCXVECTOR2	vRot(0,0);
	LCXVECTOR2	vTrn(0,0);

	if(vcScl)	vScl = *vcScl;
	if(vcRot)	vRot = *vcRot;
	if(vcTrn)	vTrn = *vcTrn;


	glGetFloatv(GL_VIEWPORT, f);


	glPushMatrix();
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		glDisable(GL_ALPHA_TEST);
		glDisable(GL_LIGHTING);
		glDisable(GL_FOG);
		glDisable(GL_DEPTH_TEST);

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NONE);
		glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NONE);
		glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);


		
		glEnable(GL_TEXTURE_2D);
		glBindTexture (GL_TEXTURE_2D, nId);
		glTexEnvi (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

		PosL =  2.f * vTrn.x/f[2] - 1.f;
		PosT = -2.f * vTrn.y/f[3] + 1.f;
		PosR = PosL + 2 * ImgW * vScl.x/f[2];
		PosB = PosT - 2 * ImgH * vScl.y/f[3];

		glTranslatef(0, 0, 0);

		// Quad�� �̿��ؼ� ������
		glBegin(GL_QUADS);
			glColor4f(dcolor.r, dcolor.g, dcolor.b, dcolor.a);
			glTexCoord2f(0.0f, 0.0f); glVertex3f(PosL, PosB, 0);
			glTexCoord2f(1.0f, 0.0f); glVertex3f(PosR, PosB, 0);	
			glTexCoord2f(1.0f, 1.0f); glVertex3f(PosR, PosT, 0);
			glTexCoord2f(0.0f, 1.0f); glVertex3f(PosL, PosT, 0);
		glEnd();

		glEnable(GL_DEPTH_TEST);
		glDisable(GL_BLEND);

	glPopMatrix();


	return 0;
}


INT LgDev_CreateSprite(char* sCmd
					, IGLSprite** pData)
{
	*pData = NULL;

	CGLSprite* pObj = new CGLSprite;

	if(FAILED(pObj->Create()))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}