// Interface for the CGLFont class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _GLFont_H_
#define _GLFont_H_


class CGLFont : public IGLFont
{
protected:
	HFONT	m_hFont;
	UINT	m_uBase;
	INT		m_iWidths[512];
	INT		m_iHeight;
		
	public:
		CGLFont();
		virtual ~CGLFont();		

		virtual	INT		Create(HDC hDC, char* sFontName, INT height);
		virtual	void	Delete();
		virtual	void	DrawText(FLOAT x, FLOAT y, const DWORD color, const char *str);
};

#endif