// Interface for the IGLFont class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _IGLFont_H_
#define _IGLFont_H_


#ifndef interface
	#define interface struct
#endif


#ifndef LC_CLASS_DESTROYER
#define LC_CLASS_DESTROYER( CLASS_NAME )	\
	virtual ~CLASS_NAME(){}
#endif


interface IGLFont
{
	LC_CLASS_DESTROYER(	IGLFont	);

	virtual	INT		Create(HDC hDC, char* sFontName, INT height)=0;
	virtual	void	Delete()=0;
	virtual	void	DrawText(FLOAT x, FLOAT y, const DWORD color, const char *str)=0;
};


INT LgDev_CreateFont(char* sCmd
					, IGLFont** pData
					, HDC hDC
					, char* sName
					, INT	nHeight);

#endif