// Interface for the CGLSprite class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _GLSprite_H_
#define _GLSprite_H_


class CGLSprite : public IGLSprite
{
public:
	virtual ~CGLSprite();

	virtual INT Create();

	virtual INT Draw(	IGLTexture* pTx			// Texture Pointer
			,	RECT* rc				// Image rect
			,	LCXVECTOR2* vcScl		// Scaling
			,	LCXVECTOR2* vcRot		// Rotation Center
			,	FLOAT fRot				// Angle(Radian)
			,	LCXVECTOR2* vcTrns		// Position
			,	LCXCOLOR dcolor			// color
			);
};

#endif

