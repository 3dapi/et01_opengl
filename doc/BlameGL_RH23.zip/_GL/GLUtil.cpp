// Implementation of the GLUtil Functions.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include <gl/gl.h>
#include <gl/glu.h>

#include "GLMath.h"
#include "GLUtil.h"



void McUtil_ErrMsgBox(char *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	MessageBox(NULL, s, "Err", MB_OK | MB_ICONERROR);
}


void McUtil_SetWindowTitle(char *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	// �̷��� ���������� �ʿ��� ���̴�.
	SetWindowText( GetActiveWindow(), s);
}







void LcGL_SetStreamSource(DWORD dFVF, void* pVtx, INT dStride)
{
	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);


	if( dFVF&D3DFVF_XYZ )
		glEnableClientState(GL_VERTEX_ARRAY);

	if( dFVF&D3DFVF_DIFFUSE)
		glEnableClientState(GL_COLOR_ARRAY);

	if( dFVF&D3DFVF_TEX1)
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);


	// pVtx + sizeof(LCXVECTOR3) ==> �̷��� �ϸ�
	// Pointer ��ġ�� pVtx += (VtxDUV) * sizeof(LCXVECTOR3)�� ���� �ȴ�.
	// glColorPointer (4, GL_FLOAT, sizeof(VtxDUV), pVtx + sizeof(LCXVECTOR3));

	char* p = (char*)pVtx;
	
	if( dFVF|D3DFVF_XYZ )
		glVertexPointer(3, GL_FLOAT, dStride, p);


	if( dFVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE) )
	{
		p += sizeof(LCXVECTOR3);
		glColorPointer(4, GL_FLOAT, dStride, p);
	}

	else if( dFVF = (D3DFVF_XYZ|D3DFVF_TEX1) )
	{
		p += sizeof(LCXVECTOR3);
		glTexCoordPointer(2, GL_FLOAT, dStride, p);
	}

	else if( dFVF = (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1) )
	{
		p += sizeof(LCXVECTOR3);
		glColorPointer(4, GL_FLOAT, dStride, p);

		p += sizeof(LCXCOLOR);
		glTexCoordPointer(2, GL_FLOAT, dStride, p);
	}
}



void LcGL_DrawPrimitive(INT mode, INT first, INT nVtx)
{
	glDrawArrays(mode, first, nVtx);

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
}


void LcGL_DrawIndexedPrimitive(INT mode, INT nFace, const void *indices)
{
	glDrawElements(mode, nFace * 3, GL_UNSIGNED_SHORT, indices);

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
}

void LcGL_DrawIndexedPrimitiveUP(INT mode, INT nFace, const void *indices,	DWORD dFVF, const void* pVtx, INT dStride)
{
	if(!pVtx)
		return;

	if( D3DFVF_XYZ & dFVF)
		glEnableClientState(GL_VERTEX_ARRAY);

	if( D3DFVF_DIFFUSE & dFVF)
		glEnableClientState(GL_COLOR_ARRAY);

	if( D3DFVF_TEX1 & dFVF)
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);



	char* p = (char*)pVtx;

	if( D3DFVF_XYZ & dFVF)
		glVertexPointer(3, GL_FLOAT, dStride, p);


	if( (D3DFVF_XYZ|D3DFVF_DIFFUSE) == dFVF)
	{
		p += sizeof(LCXVECTOR3);
		glColorPointer(4, GL_FLOAT, dStride, p);
	}

	else if( (D3DFVF_XYZ|D3DFVF_TEX1) == dFVF)
	{
		p += sizeof(LCXVECTOR3);
		glTexCoordPointer(2, GL_FLOAT, dStride, p);
	}

	else if( (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1) == dFVF)
	{
		p += sizeof(LCXVECTOR3);
		glColorPointer(4, GL_FLOAT, dStride, p);

		p += sizeof(LCXCOLOR);
		glTexCoordPointer(2, GL_FLOAT, dStride, p);
	}

	glDrawElements(mode, nFace * 3, GL_UNSIGNED_SHORT, indices);

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_NORMAL_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
}