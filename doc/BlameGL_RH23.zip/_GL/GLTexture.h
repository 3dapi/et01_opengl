// Interface for the CGLTexture class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _GLTexture_H_
#define _GLTexture_H_


class CGLTexture : public IGLTexture
{
public:
	struct TimgSrc
	{
		enum EImgType
		{
			IMG_UNKNOWN	= 0,
			IMG_BMP		,
			IMG_TGA		,
		};

		struct TGAHEADER
		{
			BYTE	ImgT;				// imageTypeCode
			SHORT	ImgW;				// Width
			SHORT	ImgH;				// Height
			BYTE	ImgB;				// Bit Count
		};

		INT		m_Type;
		INT		m_ImgW;
		INT		m_ImgH;
		BYTE*	m_pPxl;				// Pixel Data

		TimgSrc();

		INT		Load(char* sFile);
		void	Destroy();

		INT		GetType() {	return m_Type;	}
		INT		GetImgW() {	return m_ImgW;	}
		INT		GetImgH() {	return m_ImgH;	}
		BYTE*	GetPixel(){	return m_pPxl;	}

		INT		LoadBitmapFile(char* sFile);
		INT		LoadTGAFile(char* sFile);
	};


protected:
	GLuint		m_nId;				// Name
	GLenum		m_Fmt;				// Pixel Format
	GLenum		m_Type;				// Pixel Data Type

	INT			m_ImgW;
	INT			m_ImgH;
	DWORD		m_dKey;				// Color Key
	
	BYTE*		m_pPxl;				// Pixel Data
	
public:
	CGLTexture ();
	virtual ~CGLTexture();

	virtual	INT			Create(char* sFile, DWORD dColor, DWORD dFilter);
	virtual	void		Destroy();

	virtual	void		SetTexure(INT modulate);

	virtual	GLuint		GetName();
	virtual	GLenum		GetFMT();
	virtual	GLenum		GetType();

	virtual	INT			GetImgW();
	virtual	INT			GetImgH();
	
	virtual	BYTE* const	GetPixel() const;

public:
	virtual	void		DrawPixel(RECT* rc				// Image rect
						, LCXVECTOR2* vcScl		// Scaling
						, LCXVECTOR2* vcRot		// Rotation Center
						, FLOAT fRot			// Angle(Radian)
						, LCXVECTOR2* vcTrn		// Position
						, LCXCOLOR dcolor		// color
						);
};




#endif