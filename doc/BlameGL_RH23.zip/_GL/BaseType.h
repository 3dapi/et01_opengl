//
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _BASETYPE_H_
#define _BASETYPE_H_


#pragma warning( disable : 4786)

#include <vector>
#include <list>
#include <string>

#include <windows.h>
#include <d3dx9.h>
#include <dxfile.h>
#include <d3dx9mesh.h>


// Window
typedef WNDPROC									LPWNDPROC;						// for Window Message
typedef DLGPROC									LPDLGPROC;						// for Dialog Message


// Vector


typedef std::vector<std::string >				lsStr;
typedef lsStr::iterator							itStr;


#endif


