// Implementation of the CGLApp class.
//
//////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include <gl/gl.h>						// standard OpenGL include
#include <gl/glu.h>						// OpenGL utilties
#include <gl/glext.h>
#include <gl/wglext.h>

#include "GLApp.h"


CGLApp*	CGLApp::g_pStApp = NULL;


INT		m_bMultiSampleCheck = 0;

CGLApp::CGLApp()
{
	g_pStApp	= this;

	strcpy(	m_sCls, "OpenGL");

	m_hInst		= NULL;
	m_hWnd		= NULL;
	m_hDC		= NULL;
	m_hRC		= NULL;
	m_hAccl		= NULL;

	m_dScnX		= 0;
	m_dScnY		= 0;

	m_dScnW		= 800;
	m_dScnH		= m_dScnW*3/4;
	m_dScnB		= 32;

	m_fElapsed	= 0.;
	m_fFPS		= 60;

	m_bWindow	= TRUE;
	m_bActive	= TRUE;

	m_dWinIcon	= 0;
	m_dWinAccl	= 0;
	m_dWinMode	= 0;
	m_dWinExit	= 0;
	m_dWinStyle	= WS_OVERLAPPED| WS_CAPTION|WS_SYSMENU|WS_VISIBLE;


}

CGLApp::~CGLApp()
{
	g_pStApp	= NULL;
}



HRESULT CGLApp::Create(HINSTANCE hInstance)
{
	m_hInst = hInstance;
	
	WNDCLASS wc =								// Register the window class
	{
		CS_CLASSDC
			, WndProc
			, 0
			, 0
			, m_hInst
			, LoadIcon( m_hInst, MAKEINTRESOURCE(m_dWinIcon) )
			, LoadCursor(NULL,IDC_ARROW)
			, (HBRUSH)GetStockObject(LTGRAY_BRUSH)
			, NULL
			, m_sCls
	};
	
	RegisterClass( &wc );

	if(FAILED(WindowCreate()))
		return -1;

	if(FAILED(Init3DEnvironment()))
		return -1;
	
	return 0;
}





HRESULT CGLApp::Cleanup3DEnvironment()
{
	if(!m_hDC)
		return 0;

	Destroy();
	
	if (m_bWindow)
	{
		ChangeDisplaySettings(NULL, 0);
		ShowCursor(TRUE);
	}
	
	if (m_hRC)
	{
		if (!wglMakeCurrent(NULL,NULL))
			MessageBox(NULL, "Unable to release rendering context", "Error", MB_OK | MB_ICONINFORMATION);
		
		if (!wglDeleteContext(m_hRC))
			MessageBox(NULL, "Unable to delete rendering context", "Error", MB_OK | MB_ICONINFORMATION);
		
		m_hRC = NULL;
	}
	
	ReleaseDC(m_hWnd, m_hDC);
	m_hDC = NULL;
	
	return 0;
}




HRESULT CGLApp::WindowCreate()
{
	RECT rc;									//Create the application's window
	
	SetRect( &rc, 0, 0, m_dScnW, m_dScnH);
	AdjustWindowRect( &rc, m_dWinStyle, FALSE );
	
	INT iScnSysW = ::GetSystemMetrics(SM_CXSCREEN);
	INT iScnSysH = ::GetSystemMetrics(SM_CYSCREEN);

	m_dScnX	= (iScnSysW - (rc.right-rc.left))/2;
	m_dScnY	= (iScnSysH - (rc.bottom-rc.top))/2;
	
	m_hWnd = CreateWindow( m_sCls
		, m_sCls
		, m_dWinStyle
		, m_dScnX
		, m_dScnY
		, (rc.right-rc.left)
		, (rc.bottom-rc.top)
		, GetDesktopWindow()
		, NULL
		, m_hInst
		, NULL );

	if(!m_hWnd)
		return -1;
	
	GetWindowRect( m_hWnd, &m_rcWin );

	return 0;
}



void CGLApp::WindowResize(INT width, INT height)
{
	if (height==0)
		height=1;
	
	glViewport(0, 0, width, height);	// set the viewport to the new dimensions
}


HRESULT CGLApp::ChangeWindowMode()
{
	if(m_bWindow)
	{
		m_bWindow = FALSE;
		m_DevFull.dmDisplayFrequency = 60;
		
		if ( DISP_CHANGE_SUCCESSFUL == ChangeDisplaySettings(&m_DevFull, CDS_FULLSCREEN) )
		{
			SetWindowLong( m_hWnd, GWL_STYLE, WS_POPUP|WS_VISIBLE );

			SetWindowPos(m_hWnd, HWND_TOP
				, 0
				, 0
				, m_dScnW
				, m_dScnH
				, SWP_SHOWWINDOW);
		}
		
		else
		{
			MessageBox(NULL,"Full mode Failed", "Fail" , MB_OK);
			return -1;
		}
	}
	else
	{
		m_bWindow = TRUE;
		m_DevFull.dmDisplayFrequency = 0;

		if ( DISP_CHANGE_SUCCESSFUL == ChangeDisplaySettings(&m_DevWin, 0) )
		{
			SetWindowLong(m_hWnd, GWL_STYLE, m_dWinStyle);
			SetWindowPos(m_hWnd, HWND_TOP
				, m_dScnX
				, m_dScnY
				, m_rcWin.right	- m_rcWin.left
				, m_rcWin.bottom	- m_rcWin.top
				, SWP_SHOWWINDOW);

		}
		else
		{
			MessageBox(NULL,"Full mode Failed", "Fail" , MB_OK);
			return -1;
		}		
	}

	
	
	return 0;
}



HRESULT CGLApp::WindowMouseMove(INT nPosX, INT nPosY)
{
	return 0;
}



INT	CGLApp::Run()
{
	MSG msg;

	m_hAccl = LoadAccelerators( m_hInst, MAKEINTRESOURCE(m_dWinAccl) );
	
	while (1)
	{
		if(PeekMessage(&msg, NULL, NULL, NULL, PM_REMOVE))
		{
			if (msg.message == WM_QUIT)
				break;
			
			if(m_hWnd)
				TranslateAccelerator( m_hWnd, m_hAccl, &msg );

			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}

		if (m_bActive)
		{
			if( FAILED( Render3DEnvironment() ) )
				SendMessage( m_hWnd, WM_CLOSE, 0, 0 );
		}
	}
	
	return msg.wParam;
}





HRESULT CGLApp::Init3DEnvironment()
{
	if (!(m_hDC = GetDC(m_hWnd)))
		return -1;

	memset(&m_DevFull,0,sizeof(m_DevFull));
	m_DevFull.dmSize       = sizeof(m_DevFull);	

	EnumDisplaySettings(NULL, ENUM_CURRENT_SETTINGS, &m_DevWin);

	m_DevFull.dmPelsWidth  = m_dScnW;
	m_DevFull.dmPelsHeight = m_dScnH;
//	m_DevFull.dmBitsPerPel = m_dScnB;
	m_DevFull.dmDisplayFrequency = m_bWindow? 0 : m_DevWin.dmDisplayFrequency;
	m_DevFull.dmFields     = DM_DISPLAYFREQUENCY | DM_PELSWIDTH | DM_PELSHEIGHT;

	PIXELFORMATDESCRIPTOR pfd = {0};

	pfd.nSize		= sizeof(PIXELFORMATDESCRIPTOR);
	pfd.nVersion	= 1;
	pfd.dwFlags		= PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL |PFD_DOUBLEBUFFER;	//|PFD_GENERIC_ACCELERATED;
	pfd.iPixelType	= PFD_TYPE_RGBA;
	pfd.cColorBits	= 32;				// cColorBits   : Specifies the number of color bitplanes in each color buffer.
	pfd.cDepthBits	= 24;				// cDepthBits   : Specifies the depth of the depth (z-axis) buffer.
	pfd.cStencilBits=  8;				// cStencilBits : Specifies the depth of the stencil buffer.
	pfd.iLayerType	= PFD_MAIN_PLANE;	// iLayerType   : Ignored. Earlier implementations of OpenGL used this member, but it is no longer used.

	
	UINT PixelFormat=0;
	
	if(! (PixelFormat = ChoosePixelFormat(m_hDC, &pfd)))
	{
		MessageBox(NULL, "Choose Pixel Format Failed", "Err", MB_OK | MB_ICONEXCLAMATION);
		return -1;
	}

	
	if(! SetPixelFormat(m_hDC, PixelFormat,&pfd))
	{
		MessageBox(NULL, "Set Pixel Format Failed", "Err", MB_OK | MB_ICONEXCLAMATION);
		return -1;
	}

	if(! (m_hRC = wglCreateContext(m_hDC)))
	{
		MessageBox(NULL, "WGL Create Context Failed", "Err",MB_OK | MB_ICONEXCLAMATION);
		return -1;
	}
	
	if(! wglMakeCurrent(m_hDC, m_hRC))
	{
		MessageBox(NULL,"WGL Make Current Failed", "Err", MB_OK | MB_ICONEXCLAMATION);
		return -1;
	}

	
	PixelFormat = MultisampleType(m_hWnd);

	if(SUCCEEDED(PixelFormat))
	{
		m_bMultiSampleCheck = 1;
		wglMakeCurrent(NULL,NULL);
		wglDeleteContext(m_hRC);
		
		ReleaseDC(m_hWnd, m_hDC);
		DestroyWindow(m_hWnd);

		m_bMultiSampleCheck = 0;

		WindowCreate();

		
		if(! SetPixelFormat(m_hDC, PixelFormat,&pfd))
		{
			MessageBox(NULL, "Set Pixel Format Failed", "Err", MB_OK | MB_ICONEXCLAMATION);
			return -1;
		}

		if(! (m_hRC = wglCreateContext(m_hDC)))
		{
			MessageBox(NULL, "WGL Create Context Failed", "Err",MB_OK | MB_ICONEXCLAMATION);
			return -1;
		}
		
		if(! wglMakeCurrent(m_hDC, m_hRC))
		{
			MessageBox(NULL,"WGL Make Current Failed", "Err", MB_OK | MB_ICONEXCLAMATION);
			return -1;
		}


		glEnable(GL_MULTISAMPLE_ARB);							// Enable Our Multisampling
	}
	

	ShowWindow(m_hWnd, SW_SHOW);
	SetForegroundWindow(m_hWnd);
	SetFocus(m_hWnd);
	
	WindowResize(m_dScnW, m_dScnH);

	InitVSync(1);
	
	if (FAILED(Init()))
	{
  		MessageBox(NULL, "Init() Failed", "Err", MB_OK | MB_ICONEXCLAMATION);
		return -1;
	}

	glEnable(GL_MULTISAMPLE_ARB);
	
	return 0;
}



HRESULT CGLApp::Render3DEnvironment()
{
	if(!m_hWnd)
		return 0;
	
	if(FAILED(FrameMove()))
		return -1;
	
	if(FAILED(Render()))
		return -1;
	
	if(FALSE == SwapBuffers(m_hDC))
		return -1;

	UpdateFPS();
	
	return 0;
}



void CGLApp::UpdateFPS()
{
	static LARGE_INTEGER	dTimeTck={0};
	static LARGE_INTEGER	dTimeBgn={0};
	static LARGE_INTEGER	dTimeEnd={0};

	static INT		bHards	= -1;
	static INT		nCount	= -1;

	++nCount;

	// ���� �Լ� ȣ���
	if(-1 == bHards)
	{
		bHards = QueryPerformanceFrequency((LARGE_INTEGER*)&dTimeTck);
//		bHards	= 0;

		// �ϵ���� ������ �ȵ� �ܿ�
		if(0 == bHards)
		{
			dTimeBgn.LowPart	= timeGetTime();
			dTimeTck.LowPart	= 1;			
		}
		else
		{
			QueryPerformanceCounter((LARGE_INTEGER*)&dTimeBgn);
		}

		return;
	}


	// 24Frame�� ����
	if(nCount>=16)
	{
		// �ϵ���� ������ �ȵǴ� ��� timeGetTime�� �̿�
		if(0 == bHards)
		{
			dTimeEnd.LowPart = timeGetTime();

			m_fElapsed	= double(dTimeEnd.LowPart - dTimeBgn.LowPart)/ double(nCount*1000);
		}
		else
		{
			QueryPerformanceCounter((LARGE_INTEGER*)&dTimeEnd);
			m_fElapsed	= double(dTimeEnd.QuadPart - dTimeBgn.QuadPart)/ (double(dTimeTck.QuadPart) * nCount);
		}

		m_fFPS	= float(1/m_fElapsed);
		nCount	= 0;
		dTimeBgn= dTimeEnd;
	}
}



LRESULT CALLBACK CGLApp::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	if(!g_pStApp)
		return DefWindowProc(hWnd, message, wParam, lParam);

	return g_pStApp->MsgProc(hWnd, message, wParam, lParam);
}



LRESULT CGLApp::MsgProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch(message)
	{
		case WM_CREATE:
			return 0;

		case WM_ACTIVATE:
		{
			if (!HIWORD(wParam))
				m_bActive = TRUE;
			else
				m_bActive= FALSE;
			
			return 0;
		}
		
		case WM_COMMAND:
		{
			if( m_dWinMode && m_dWinMode == LOWORD(wParam) )
			{
				ChangeWindowMode();
				return 0;
			}
				
			else if( m_dWinExit && m_dWinExit == LOWORD(wParam) )
			{
				PostMessage( hWnd, WM_CLOSE, 0, 0 );
				return 0;
			}
			
			return 0;
		}
		
		case WM_CLOSE:
		case WM_DESTROY:
		{
			if(m_hWnd)
			{
				if(!m_bMultiSampleCheck)
				{
					Cleanup3DEnvironment();
				
					HMENU hMenu;
					hMenu = GetMenu(hWnd);
					
					if( hMenu != NULL )
						DestroyMenu( hMenu );
				
					PostQuitMessage(0);
				}

				m_hWnd = NULL;
			}

			return 0;
		}
			
		case WM_SIZE:
			WindowResize(LOWORD(lParam), HIWORD(lParam));
			return 0;
			
		case WM_KEYDOWN:
		{
			switch (wParam)
			{
			case VK_ESCAPE:
				SendMessage(hWnd, WM_DESTROY, 0, 0);
				return 0;
			}
			return 0;
			
			case WM_MOUSEMOVE:
				WindowMouseMove (LOWORD(lParam), HIWORD(lParam));
				
				return 0;
		}
	}
	
	return (DefWindowProc(hWnd, message, wParam, lParam));
}





void CGLApp::InitVSync(BOOL bVsynOff)
{
	//get extensions of graphics card
	char* extensions = (char*)glGetString(GL_EXTENSIONS);
	
	//is WGL_EXT_swap_control in the string? VSync switch possible?
	if (strstr(extensions,"WGL_EXT_swap_control"))
	{
		//function pointer typdefs
		typedef void (APIENTRY *PFNWGLEXTSWAPCONTROLPROC)(INT);
		typedef INT (*PFNWGLEXTGETSWAPINTERVALPROC)(void);
		
		//declare functions
		PFNWGLEXTSWAPCONTROLPROC wglSwapIntervalEXT = NULL;
		PFNWGLEXTGETSWAPINTERVALPROC wglGetSwapIntervalEXT = NULL;
		
		//get address's of both functions and save them
		wglSwapIntervalEXT	= (PFNWGLEXTSWAPCONTROLPROC)	wglGetProcAddress("wglSwapIntervalEXT");
		wglGetSwapIntervalEXT= (PFNWGLEXTGETSWAPINTERVALPROC)wglGetProcAddress("wglGetSwapIntervalEXT");
	
		if(wglGetSwapIntervalEXT())
		{
			if(bVsynOff)
				wglSwapIntervalEXT(0);
			else
				wglSwapIntervalEXT(1);
		}
		
	}
}



#define WGL_SAMPLE_BUFFERS_ARB		 0x2041
#define WGL_SAMPLES_ARB			     0x2042


INT WGLisExtensionSupported(const char *extension);


INT CGLApp::MultisampleType(HWND hWnd)
{  
	 // See If The String Exists In WGL!
	if(FAILED(WGLisExtensionSupported("WGL_ARB_multisample")))
		return -1;

	// Get Our Pixel Format
	PFNWGLCHOOSEPIXELFORMATARBPROC wglChoosePixelFormatARB =
		(PFNWGLCHOOSEPIXELFORMATARBPROC)wglGetProcAddress("wglChoosePixelFormatARB");

	if (!wglChoosePixelFormatARB) 
		return -1;



	HDC hDC = GetDC(hWnd);

	// Get Our Current Device Context
	INT		pixelFormat=-1;
	INT		valid;
	UINT	numFormats;
	float	fAttributes[] = {0,0};

	INT iAttributes[] =
	{
		WGL_DRAW_TO_WINDOW_ARB,	GL_TRUE,
		WGL_SUPPORT_OPENGL_ARB,	GL_TRUE,
		WGL_ACCELERATION_ARB,	WGL_FULL_ACCELERATION_ARB,
		WGL_COLOR_BITS_ARB,		32,
		WGL_ALPHA_BITS_ARB,		 8,
		WGL_DEPTH_BITS_ARB,		24,
		WGL_STENCIL_BITS_ARB,	 8,

		WGL_DOUBLE_BUFFER_ARB,GL_TRUE,
		WGL_SAMPLE_BUFFERS_ARB,GL_TRUE,

		WGL_SAMPLES_ARB,		16,	// 16 is 16-sampling
		0,0
	};

	// sampling�� 16 �ƴϸ� 4... 8�� 4�� ���� ���

	for(INT smp=16; smp>0; smp -=2)
	{
		iAttributes[19] = smp;
		valid = wglChoosePixelFormatARB(hDC,iAttributes,fAttributes,1,&pixelFormat,&numFormats);
		if (valid && numFormats >= 1)
		{
			break;
		}
	}
	  
	ReleaseDC(hWnd, hDC);
	return pixelFormat;
}



INT WGLisExtensionSupported(const char *extension)
{
	const size_t extlen = strlen(extension);
	const char *supported = NULL;

	// Try To Use wglGetExtensionStringARB On Current DC, If Possible
	PROC wglGetExtString = wglGetProcAddress("wglGetExtensionsStringARB");

	if (wglGetExtString)
		supported = ((char*(__stdcall*)(HDC))wglGetExtString)(wglGetCurrentDC());

	// If That Failed, Try Standard Opengl Extensions String
	if (supported == NULL)
		supported = (char*)glGetString(GL_EXTENSIONS);

	// If That Failed Too, Must Be No Extensions Supported
	if (supported == NULL)
		return -1;

	// Begin Examination At Start Of String, Increment By 1 On False Match
	for (const char* p = supported; ; p++)
	{
		// Advance p Up To The Next Possible Match
		p = strstr(p, extension);

		if (p == NULL)
			return -1;															// No Match

		// Make Sure That Match Is At The Start Of The String Or That
		// The Previous Char Is A Space, Or Else We Could Accidentally
		// Match "wglFunkywglExtension" With "wglExtension"

		// Also, Make Sure That The Following Character Is Space Or NULL
		// Or Else "wglExtensionTwo" Might Match "wglExtension"
		if ((p==supported || p[-1]==' ') && (p[extlen]=='\0' || p[extlen]==' '))
			return 0;															// Match
	}


	return -1;
}