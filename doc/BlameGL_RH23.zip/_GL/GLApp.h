// Interface for the CGLApp class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _GLApp_H_
#define _GLApp_H_


class CGLApp
{
protected:
	char		m_sCls[128]	;
	
	HINSTANCE	m_hInst		;
	HWND		m_hWnd		;
	HDC			m_hDC		;
	HGLRC		m_hRC		;
	HACCEL		m_hAccl		;

	INT			m_dScnX		;													// Screen X
	INT			m_dScnY		;													// Screen Y
	RECT		m_rcWin		;

	INT			m_dScnW		;													// Screen Width
	INT			m_dScnH		;													// Screen Height
	INT			m_dScnB		;													// Screen Bitmap

	DOUBLE		m_fElapsed	;
	FLOAT		m_fFPS		;

	DWORD		m_dWinIcon	;
	DWORD		m_dWinAccl	;
	DWORD		m_dWinMode	;
	DWORD		m_dWinExit	;

	DWORD		m_dWinStyle	;
	DEVMODE		m_DevWin	;
	DEVMODE		m_DevFull	;
	
	BOOL		m_bWindow	;
	BOOL		m_bActive	;

public:
	static CGLApp*	g_pStApp;

public:
	CGLApp();
	virtual ~CGLApp();

	virtual HRESULT Init()		{	return 0;	}
	virtual HRESULT	Destroy()	{	return 0;	}
	virtual HRESULT	FrameMove()	{	return 0;	}
	virtual HRESULT Render()	{	return 0;	}
	virtual	LRESULT	MsgProc(HWND,UINT,WPARAM,LPARAM);

public:
	HRESULT	Create(HINSTANCE hInstance);
	INT		Run();	

protected:
	HRESULT	Init3DEnvironment();
	HRESULT	Render3DEnvironment();
	HRESULT	Cleanup3DEnvironment();

	void	UpdateFPS();
	HRESULT	WindowCreate();
	void	WindowResize(INT width, INT height);
	HRESULT	WindowMouseMove(INT nPosX, INT nPosY);

	HRESULT	ChangeWindowMode();
	
	void	InitVSync(BOOL bVsynOff=1);
	INT		MultisampleType(HWND);

	static	LRESULT CALLBACK WndProc(HWND,UINT,WPARAM,LPARAM);

public:
	HINSTANCE	GetHinst()	{	return m_hInst;		}
	HWND		GetHwnd()	{	return m_hWnd;		}
	HDC			GetHdc()	{	return m_hDC;		}

	INT			GetScnX()	{	return 	m_dScnX;	}
	INT			GetScnY()	{	return 	m_dScnY;	}

	INT			GetScnW()	{	return 	m_dScnW;	}
	INT			GetScnH()	{	return 	m_dScnH;	}

	float		GetFPS()	{	return m_fFPS;		}
};

#endif