//
//////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <math.h>

#include <d3dmx.h>

#include "LpEuclid.h"



// 2D Vector


LPXVECTOR2::LPXVECTOR2() : x(0), y(0)
{
}


LPXVECTOR2::LPXVECTOR2( const LPXVECTOR2& rhs)
{
	x = rhs.x;
	y = rhs.y;
}



LPXVECTOR2::LPXVECTOR2( const FLOAT *pf )
{
	x = pf[0];
	y = pf[1];
}



LPXVECTOR2::LPXVECTOR2( FLOAT fx, FLOAT fy )
{
	x = fx;
	y = fy;
}

// casting

LPXVECTOR2::operator FLOAT* ()
{
	return (FLOAT *) &x;
}


LPXVECTOR2::operator const FLOAT* () const
{
	return (const FLOAT *) &x;
}

// assignment operators
 LPXVECTOR2&
LPXVECTOR2::operator += ( const LPXVECTOR2& v )
{
	x += v.x;
	y += v.y;
	return *this;
}

 LPXVECTOR2&
LPXVECTOR2::operator -= ( const LPXVECTOR2& v )
{
	x -= v.x;
	y -= v.y;
	return *this;
}

 LPXVECTOR2&
LPXVECTOR2::operator *= ( FLOAT f )
{
	x *= f;
	y *= f;
	return *this;
}

 LPXVECTOR2&
LPXVECTOR2::operator /= ( FLOAT f )
{
	FLOAT fInv = 1.0f / f;
	x *= fInv;
	y *= fInv;
	return *this;
}

// unary operators
 LPXVECTOR2
LPXVECTOR2::operator + () const
{
	return *this;
}

 LPXVECTOR2
LPXVECTOR2::operator - () const
{
	return LPXVECTOR2(-x, -y);
}

// binary operators
 LPXVECTOR2
LPXVECTOR2::operator + ( const LPXVECTOR2& v ) const
{
	return LPXVECTOR2(x + v.x, y + v.y);
}

 LPXVECTOR2
LPXVECTOR2::operator - ( const LPXVECTOR2& v ) const
{
	return LPXVECTOR2(x - v.x, y - v.y);
}

 LPXVECTOR2
LPXVECTOR2::operator * ( FLOAT f ) const
{
	return LPXVECTOR2(x * f, y * f);
}

 LPXVECTOR2
LPXVECTOR2::operator / ( FLOAT f ) const
{
	FLOAT fInv = 1.0f / f;
	return LPXVECTOR2(x * fInv, y * fInv);
}


 LPXVECTOR2
operator * ( FLOAT f, const LPXVECTOR2& v )
{
	return LPXVECTOR2(f * v.x, f * v.y);
}

 BOOL
LPXVECTOR2::operator == ( const LPXVECTOR2& v ) const
{
	return x == v.x && y == v.y;
}

 BOOL
LPXVECTOR2::operator != ( const LPXVECTOR2& v ) const
{
	return x != v.x || y != v.y;
}



// Quaternion


LPXQUATERNION::LPXQUATERNION() : x(0), y(0), z(0), w(0)
{
}


LPXQUATERNION::LPXQUATERNION( const FLOAT* pf )
{
	x = pf[0];
	y = pf[1];
	z = pf[2];
	w = pf[3];
}


LPXQUATERNION::LPXQUATERNION( const LPXQUATERNION& rhs)
{
	x = rhs.x;
	y = rhs.y;
	z = rhs.z;
	w = rhs.w;
}



LPXQUATERNION::LPXQUATERNION( FLOAT fx, FLOAT fy, FLOAT fz, FLOAT fw )
{
	x = fx;
	y = fy;
	z = fz;
	w = fw;
}


// casting

LPXQUATERNION::operator FLOAT* ()
{
return (FLOAT *) &x;
}


LPXQUATERNION::operator const FLOAT* () const
{
return (const FLOAT *) &x;
}


// assignment operators
 LPXQUATERNION&
LPXQUATERNION::operator += ( const LPXQUATERNION& q )
{
x += q.x;
y += q.y;
z += q.z;
w += q.w;
return *this;
}

 LPXQUATERNION&
LPXQUATERNION::operator -= ( const LPXQUATERNION& q )
{
x -= q.x;
y -= q.y;
z -= q.z;
w -= q.w;
return *this;
}

 LPXQUATERNION&
LPXQUATERNION::operator *= ( const LPXQUATERNION& q )
{
//    LPXQuaternionMultiply(this, this, &q);
return *this;
}

 LPXQUATERNION&
LPXQUATERNION::operator *= ( FLOAT f )
{
x *= f;
y *= f;
z *= f;
w *= f;
return *this;
}

 LPXQUATERNION&
LPXQUATERNION::operator /= ( FLOAT f )
{
FLOAT fInv = 1.0f / f;
x *= fInv;
y *= fInv;
z *= fInv;
w *= fInv;
return *this;
}


// unary operators
 LPXQUATERNION
LPXQUATERNION::operator + () const
{
return *this;
}

 LPXQUATERNION
LPXQUATERNION::operator - () const
{
return LPXQUATERNION(-x, -y, -z, -w);
}


// binary operators
 LPXQUATERNION
LPXQUATERNION::operator + ( const LPXQUATERNION& q ) const
{
return LPXQUATERNION(x + q.x, y + q.y, z + q.z, w + q.w);
}

 LPXQUATERNION
LPXQUATERNION::operator - ( const LPXQUATERNION& q ) const
{
return LPXQUATERNION(x - q.x, y - q.y, z - q.z, w - q.w);
}

 LPXQUATERNION
LPXQUATERNION::operator * ( const LPXQUATERNION& q ) const
{
LPXQUATERNION qT;
//    LPXQuaternionMultiply(&qT, this, &q);
return qT;
}

 LPXQUATERNION
LPXQUATERNION::operator * ( FLOAT f ) const
{
return LPXQUATERNION(x * f, y * f, z * f, w * f);
}

 LPXQUATERNION
LPXQUATERNION::operator / ( FLOAT f ) const
{
FLOAT fInv = 1.0f / f;
return LPXQUATERNION(x * fInv, y * fInv, z * fInv, w * fInv);
}


 LPXQUATERNION
operator * (FLOAT f, const LPXQUATERNION& q )
{
return LPXQUATERNION(f * q.x, f * q.y, f * q.z, f * q.w);
}


 BOOL
LPXQUATERNION::operator == ( const LPXQUATERNION& q ) const
{
return x == q.x && y == q.y && z == q.z && w == q.w;
}

 BOOL
LPXQUATERNION::operator != ( const LPXQUATERNION& q ) const
{
return x != q.x || y != q.y || z != q.z || w != q.w;
}



// Plane


LPXPLANE::LPXPLANE() : a(0), b(0), c(0), d(0)
{
}



LPXPLANE::LPXPLANE( const FLOAT* pf )
{
	a = pf[0];
	b = pf[1];
	c = pf[2];
	d = pf[3];
}



LPXPLANE::LPXPLANE( const LPXPLANE& rhs )
{
	a = rhs.a;
	b = rhs.b;
	c = rhs.c;
	d = rhs.d;
}




LPXPLANE::LPXPLANE( FLOAT fa, FLOAT fb, FLOAT fc, FLOAT fd )
{
	a = fa;
	b = fb;
	c = fc;
	d = fd;
}


// casting

LPXPLANE::operator FLOAT* ()
{
	return (FLOAT *) &a;
}


LPXPLANE::operator const FLOAT* () const
{
	return (const FLOAT *) &a;
}


// unary operators
 LPXPLANE
LPXPLANE::operator + () const
{
	return *this;
}

 LPXPLANE
LPXPLANE::operator - () const
{
	return LPXPLANE(-a, -b, -c, -d);
}


// binary operators
 BOOL
LPXPLANE::operator == ( const LPXPLANE& p ) const
{
	return a == p.a && b == p.b && c == p.c && d == p.d;
}

 BOOL
LPXPLANE::operator != ( const LPXPLANE& p ) const
{
	return a != p.a || b != p.b || c != p.c || d != p.d;
}


// Color


LPXCOLOR::LPXCOLOR() : r(1), g(1), b(1), a(1)
{
}



LPXCOLOR::LPXCOLOR( DWORD dw )
{
	const FLOAT f = 1.0f / 255.0f;
	r = f * (FLOAT) (unsigned char) (dw >> 16);
	g = f * (FLOAT) (unsigned char) (dw >>  8);
	b = f * (FLOAT) (unsigned char) (dw >>  0);
	a = f * (FLOAT) (unsigned char) (dw >> 24);
}


LPXCOLOR::LPXCOLOR( const FLOAT* pf )
{
	r = pf[0];
	g = pf[1];
	b = pf[2];
	a = pf[3];
}


LPXCOLOR::LPXCOLOR( const LPXCOLOR& rhs )
{
	r = rhs.r;
	g = rhs.g;
	b = rhs.b;
	a = rhs.a;
}



LPXCOLOR::LPXCOLOR( FLOAT fr, FLOAT fg, FLOAT fb, FLOAT fa )
{
	r = fr;
	g = fg;
	b = fb;
	a = fa;
}


// casting

LPXCOLOR::operator DWORD () const
{
	DWORD dwR = r >= 1.0f ? 0xff : r <= 0.0f ? 0x00 : (DWORD) (r * 255.0f + 0.5f);
	DWORD dwG = g >= 1.0f ? 0xff : g <= 0.0f ? 0x00 : (DWORD) (g * 255.0f + 0.5f);
	DWORD dwB = b >= 1.0f ? 0xff : b <= 0.0f ? 0x00 : (DWORD) (b * 255.0f + 0.5f);
	DWORD dwA = a >= 1.0f ? 0xff : a <= 0.0f ? 0x00 : (DWORD) (a * 255.0f + 0.5f);

	return (dwA << 24) | (dwR << 16) | (dwG << 8) | dwB;
}



LPXCOLOR::operator FLOAT * ()
{
	return (FLOAT *) &r;
}


LPXCOLOR::operator const FLOAT * () const
{
	return (const FLOAT *) &r;
}


// assignment operators
 LPXCOLOR&
LPXCOLOR::operator += ( const LPXCOLOR& c )
{
	r += c.r;
	g += c.g;
	b += c.b;
	a += c.a;
	return *this;
}

 LPXCOLOR&
LPXCOLOR::operator -= ( const LPXCOLOR& c )
{
	r -= c.r;
	g -= c.g;
	b -= c.b;
	a -= c.a;
	return *this;
}

 LPXCOLOR&
LPXCOLOR::operator *= ( FLOAT f )
{
	r *= f;
	g *= f;
	b *= f;
	a *= f;
	return *this;
}

 LPXCOLOR&
LPXCOLOR::operator /= ( FLOAT f )
{
	FLOAT fInv = 1.0f / f;
	r *= fInv;
	g *= fInv;
	b *= fInv;
	a *= fInv;
	return *this;
}


// unary operators
 LPXCOLOR
LPXCOLOR::operator + () const
{
	return *this;
}

 LPXCOLOR
LPXCOLOR::operator - () const
{
	return LPXCOLOR(-r, -g, -b, -a);
}


// binary operators
 LPXCOLOR
LPXCOLOR::operator + ( const LPXCOLOR& c ) const
{
	return LPXCOLOR(r + c.r, g + c.g, b + c.b, a + c.a);
}

 LPXCOLOR
LPXCOLOR::operator - ( const LPXCOLOR& c ) const
{
	return LPXCOLOR(r - c.r, g - c.g, b - c.b, a - c.a);
}

 LPXCOLOR
LPXCOLOR::operator * ( FLOAT f ) const
{
	return LPXCOLOR(r * f, g * f, b * f, a * f);
}

 LPXCOLOR
LPXCOLOR::operator / ( FLOAT f ) const
{
	FLOAT fInv = 1.0f / f;
	return LPXCOLOR(r * fInv, g * fInv, b * fInv, a * fInv);
}


 LPXCOLOR
operator * (FLOAT f, const LPXCOLOR& c )
{
	return LPXCOLOR(f * c.r, f * c.g, f * c.b, f * c.a);
}


 BOOL
LPXCOLOR::operator == ( const LPXCOLOR& c ) const
{
	return r == c.r && g == c.g && b == c.b && a == c.a;
}

 BOOL
LPXCOLOR::operator != ( const LPXCOLOR& c ) const
{
	return r != c.r || g != c.g || b != c.b || a != c.a;
}


