// OpenGL Util functions
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _GLUtil_H_
#define _GLUtil_H_


#define SAFE_FREE(p)         { if(p) { free(p);     (p)=NULL; } }
#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }

#define SAFE_DESTROY(p)		{	if(p)	(p)->Destroy();			}
#define SAFE_INVALIDATE(p)	{	if(p)	(p)->Invalidate();		}
#define SAFE_RENDER(p)		{	if(p)	(p)->Render();			}


#define SAFE_NEWINIT(p, CLASSTYPE)								\
{																\
	if(NULL == (p))												\
	{															\
		p = new CLASSTYPE;										\
																\
		if(!(p))												\
		{														\
			return -1;											\
		}														\
																\
		if(FAILED((p)->Init()))									\
		{														\
			delete p;											\
			p = NULL;											\
			return -1;											\
		}														\
	}															\
}

	
#define SAFE_RESTORE(p)											\
{																\
	if(p)														\
	{															\
		if(FAILED((p)->Restore()))								\
			return -1;											\
	}															\
}



#define SAFE_FRMOV(p)											\
{																\
	if(p)														\
	{															\
		if(FAILED(	(p)->FrameMove()))							\
			return -1;											\
	}															\
}

#define SAFE_FRAMEMOVE(p)										\
{																\
	if(p)														\
	{															\
		if(FAILED(	(p)->FrameMove()))							\
			return -1;											\
	}															\
}

// Access variable-argument lists �̿��� MessageBox ��Ÿ ��¹�
// Error MessageBox����
void McUtil_ErrMsgBox(char *format,...);

//������ Ÿ��Ʋ ���� ����
void McUtil_SetWindowTitle(char *format,...);



#define D3DFVF_XYZ			0x002
#define D3DFVF_DIFFUSE      0x040
#define D3DFVF_TEX1			0x100


void LcGL_SetStreamSource(DWORD dFVF, void* pVtx, INT dStride);
void LcGL_DrawPrimitive(INT mode, INT first, INT nVtx);
void LcGL_DrawIndexedPrimitive(INT mode, INT nFace, const void *indices);
void LcGL_DrawIndexedPrimitiveUP(INT mode, INT nFace, const void *indices,	DWORD dFVF, const void* pVtx, INT dStride);




inline FLOAT UsePerformanceCounter()													// �ϵ����� �����Ǵ� UsePerformanceCounter�� �̿��� FPS���ϱ�
{
	static INT				iCnt =0;
	static LARGE_INTEGER	dTicks={0};
	static BOOL				bS=1;
	static LARGE_INTEGER	dB;
	static LARGE_INTEGER	dE;
	
	static FLOAT			fFps=0.f;

	if(0 == bS)
		return 0.f;																// �ϵ���� ������ �ȵ�

	if(0 == dTicks.QuadPart)													// ���� �Լ� ȣ���
	{
		bS = QueryPerformanceFrequency( &dTicks);

		if(0 == bS)
			return 0.f;

		QueryPerformanceCounter(&dB);
	}

	++iCnt;
	QueryPerformanceCounter( &dE);

	if(iCnt>=24)																// 30Frame�� ����
	{
		double fElapsedTime = double(dE.QuadPart-dB.QuadPart)/ dTicks.QuadPart;
		fFps = float(iCnt/fElapsedTime);
		iCnt = 0;
		dB = dE;
	}

	return fFps;
}

#endif


