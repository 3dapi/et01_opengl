// Implementation of the CGLTexture class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>
#include <math.h>
#include <gl/gl.h>
#include <gl/glu.h>

#include "GLMath.h"
#include "IGLTexture.h"
#include "GLTexture.h"


#define SAFE_DELETE_ARRAY(p)       { if(p) { delete [] (p);     (p)=NULL; } }


CGLTexture::TimgSrc::TimgSrc()
{
	m_ImgW = 0;
	m_ImgH = 0;
	m_pPxl = NULL;
}



INT CGLTexture::TimgSrc::Load(char *sFile)
{
	m_Type = IMG_UNKNOWN;

	char Ext[MAX_PATH];

	char* p  = strrchr(sFile, '.');

	if(p)
		strcpy(Ext, p+1);

	if(0==_stricmp(Ext, "bmp"))
		m_Type =IMG_BMP;
	else if(0==_stricmp(Ext, "tga"))
		m_Type =IMG_TGA;

	switch(m_Type)
	{
	case IMG_BMP:
		return LoadBitmapFile(sFile);
	case IMG_TGA:
		return LoadTGAFile(sFile);
	}
	
	return -1;
}


INT CGLTexture::TimgSrc::LoadBitmapFile(char* sFile)
{
	FILE*	fp;
	long	lSize;
	INT		nImgB;				// Bit Count
	BYTE*	pData = NULL;
	BYTE*	pPxlT = NULL;

	fp= fopen(sFile, "rb");

	if(NULL == fp)
		return -1;

	fseek(fp, 0, SEEK_END);
	lSize = ftell(fp);
	fseek(fp, 0, SEEK_SET);

	if(lSize<10)
	{
		fclose(fp);
		return -1;
	}

	pData = new BYTE[lSize];

	fread(pData, sizeof(BYTE), lSize, fp);
	fclose(fp);

	BITMAPFILEHEADER*	fh		= (BITMAPFILEHEADER *)pData;
	BITMAPINFOHEADER*	ih		= (BITMAPINFOHEADER *)(pData + sizeof(BITMAPFILEHEADER));
	
	pPxlT	= pData + fh->bfOffBits;
	nImgB	= ih->biBitCount>>3;

	m_ImgW	= ih->biWidth;
	m_ImgH	= ih->biHeight;
	m_pPxl	= new BYTE[m_ImgW * m_ImgH * 4];// 4byte�� �����.

	// BGR Mode
	if(3 == nImgB)
	{
//		m_Fmt = GL_RGB;

		for(INT y=0; y<m_ImgH; ++y)
		{
			for(INT x=0; x<m_ImgW; ++x)
			{
				INT n1 = (y*m_ImgW + x)* 3;
				INT n2 = (y*m_ImgW + x)* 4;
				
				INT B = pPxlT[n1+0];
				INT G = pPxlT[n1+1];
				INT R = pPxlT[n1+2];

				m_pPxl[n2+0] = R;
				m_pPxl[n2+1] = G;
				m_pPxl[n2+2] = B;
				m_pPxl[n2+3] = 0xFF;
			}
		}
	}

	// BGRA Mode
	else if(4 == nImgB)
	{
//		m_Fmt = GL_RGBA;

		for(INT y=0; y<m_ImgH; ++y)
		{
			for(INT x=0; x<m_ImgW; ++x)
			{
				INT n1 = (y*m_ImgW + x)* 4;
				INT n2 = (y*m_ImgW + x)* 4;
				
				INT B = pPxlT[n1+0];
				INT G = pPxlT[n1+1];
				INT R = pPxlT[n1+2];
				INT A = pPxlT[n1+3];

				m_pPxl[n2+0] = R;
				m_pPxl[n2+1] = G;
				m_pPxl[n2+2] = B;
				m_pPxl[n2+3] = A;
			}
		}
	}

	delete [] pData;

	return 0;
}



INT CGLTexture::TimgSrc::LoadTGAFile(char *sFile)
{
	FILE*		fp;
	BYTE		charBad;					// garbage data
	SHORT		sintBad;					// garbage data
	long		imageSize;					// size of TGA image

	TGAHEADER	Tga;

	INT			nImgB;
	BYTE*		pPxlT = NULL;
		
	// open the TGA file
	fp = fopen(sFile, "rb");

	if (!fp)
		return NULL;
	
	// read first two bytes of garbage
	fread(&charBad, sizeof(BYTE), 1, fp);
	fread(&charBad, sizeof(BYTE), 1, fp);

	// read in the image type
	fread(&Tga.ImgT, sizeof(Tga.ImgT), 1, fp);

	// for our purposes, the image type should be either a 2 or a 3
	if ((Tga.ImgT != 2) && (Tga.ImgT != 3))
	{
		fclose(fp);
		return NULL;
	}

	// read 13 bytes of garbage data
	fread(&sintBad, sizeof(SHORT), 1, fp);
	fread(&sintBad, sizeof(SHORT), 1, fp);
	fread(&charBad, sizeof(BYTE ), 1, fp);
	fread(&sintBad, sizeof(SHORT), 1, fp);
	fread(&sintBad, sizeof(SHORT), 1, fp);

	// read image dimensions
	fread(&Tga.ImgW, sizeof(SHORT), 1, fp);
	fread(&Tga.ImgH, sizeof(SHORT), 1, fp);

	// read bit depth
	fread(&Tga.ImgB, sizeof(BYTE), 1, fp);

	// read garbage
	fread(&charBad, sizeof(BYTE), 1, fp);


	// colormode -> 3 = BGR, 4 = BGRA
	nImgB		= Tga.ImgB>>3;
	imageSize	= Tga.ImgW * Tga.ImgH * nImgB;
	pPxlT		= new BYTE[imageSize];

	fread(pPxlT, sizeof(BYTE), imageSize, fp);
	fclose(fp);

	m_ImgW	= Tga.ImgW;
	m_ImgH	= Tga.ImgH;
	m_pPxl	= new BYTE[Tga.ImgW * Tga.ImgH* 4];

	// BGR
	if(3 == nImgB)
	{
		for(INT y=0; y<m_ImgH; ++y)
		{
			for(INT x=0; x<m_ImgW; ++x)
			{
				INT n1 = (y*m_ImgW + x)* 3;
				INT n2 = (y*m_ImgW + x)* 4;
				
				BYTE B = pPxlT[n1+0];
				BYTE G = pPxlT[n1+1];
				BYTE R = pPxlT[n1+2];

				m_pPxl[n2+0] = R;
				m_pPxl[n2+1] = G;
				m_pPxl[n2+2] = B;
				m_pPxl[n2+3] = 0xFF;
			}
		}
	}

	// BGRA
	else if(4 == nImgB)
	{
		for(INT y=0; y<m_ImgH; ++y)
		{
			for(INT x=0; x<m_ImgW; ++x)
			{
				INT n1 = (y*m_ImgW + x)* 4;
				INT n2 = (y*m_ImgW + x)* 4;
				
				BYTE B = pPxlT[n1+0];
				BYTE G = pPxlT[n1+1];
				BYTE R = pPxlT[n1+2];
				BYTE A = pPxlT[n1+3];

				m_pPxl[n2+0] = R;
				m_pPxl[n2+1] = G;
				m_pPxl[n2+2] = B;
				m_pPxl[n2+3] = A;
			}
		}
	}

	delete [] pPxlT;

	return 0;
}






CGLTexture::CGLTexture()
{
	m_nId	= 0;
	m_Fmt	= 0;
	m_Type	= 0;
	
	m_ImgW	= 0;
	m_ImgH	= 0;

	m_pPxl	= 0;
}


CGLTexture::~CGLTexture()
{
	Destroy();
}

void CGLTexture::Destroy()
{
	if(0 == m_nId)
		return;

	glDeleteTextures (1, &m_nId);

	m_nId	= 0;
	m_Fmt	= 0;
	m_Type	= 0;
	
	m_ImgW	= 0;
	m_ImgH	= 0;

	SAFE_DELETE_ARRAY(	m_pPxl	);
}


INT CGLTexture::Create(char* sFile, DWORD color, DWORD dFilter)
{
	TimgSrc pImg;

	//TimgSrc�� �ؽ�ó�� 4����Ʈ�� �о� ���� ���İ� ������ 0xFF ������ ����.
	if(FAILED(pImg.Load(sFile)))
		return -1;



	m_Fmt	= GL_RGBA;
	m_Type	= GL_UNSIGNED_BYTE;

	m_ImgW	= pImg.GetImgW();
	m_ImgH	= pImg.GetImgH();
	m_pPxl	= pImg.GetPixel();
	m_dKey	= color;				// Color Key


	
	
	// Alpha channel�� �����.
	if(0x0 != m_dKey)
	{
		BYTE	color[4];
		memcpy(color, &m_dKey, sizeof(BYTE)*4);

		for(INT y=0; y<m_ImgH; ++y)
		{
			for(INT x=0; x<m_ImgW; ++x)
			{
				INT n1 = (y*m_ImgW + x)* 4;

				BYTE R = m_pPxl[n1+0];
				BYTE G = m_pPxl[n1+1];
				BYTE B = m_pPxl[n1+2];
				BYTE A = m_pPxl[n1+3];

				if( color[0] == A &&  color[1] == R &&  color[2] == G &&  color[3] == B)
					m_pPxl[n1+3] = 0x0;
			}
		}
	}


	// To Generate Texture Name
	glGenTextures (1,&m_nId);
	glBindTexture (GL_TEXTURE_2D, m_nId);
	glTexImage2D (GL_TEXTURE_2D, 0, 4, m_Fmt, m_ImgW, m_ImgH, 0, m_Type, m_pPxl);
	gluBuild2DMipmaps (GL_TEXTURE_2D, 4, m_ImgW, m_ImgH, m_Fmt, m_Type, m_pPxl);
	

	// set pixel unpacking mode
//	glPixelStorei (GL_UNPACK_SWAP_BYTES, 0);
//	glPixelStorei (GL_UNPACK_ROW_LENGTH, 0);
//	glPixelStorei (GL_UNPACK_ALIGNMENT, 1);
//	glPixelStorei (GL_UNPACK_SKIP_ROWS, 0);
//	glPixelStorei (GL_UNPACK_SKIP_PIXELS, 0);

	glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	
	glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NONE);
	glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NONE);
	
//	glTexEnvf (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);

	glBindTexture (GL_TEXTURE_2D, 0);

	return 0;
}


void CGLTexture::SetTexure(INT modulate)
{
	if(0 == modulate)
	{
		glBindTexture (GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);
		return;
	}

	glEnable(GL_TEXTURE_2D);
	glBindTexture (GL_TEXTURE_2D, m_nId);
	glTexEnvi (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, modulate);

	glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	
	glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
}




GLuint CGLTexture::GetName()
{
	return m_nId;
}

GLenum CGLTexture::	GetFMT()
{
	return m_Fmt;
}

GLenum CGLTexture::GetType()			{	return m_Type;	}
INT CGLTexture::GetImgW()				{	return m_ImgW;	}
INT CGLTexture::GetImgH()				{	return m_ImgH;	}
BYTE* const	CGLTexture::GetPixel() const{	return m_pPxl;	}


void CGLTexture::DrawPixel(RECT* rc				// Image rect
					, LCXVECTOR2* vcScl		// Scaling
					, LCXVECTOR2* vcRot		// Rotation Center
					, FLOAT fRot			// Angle(Radian)
					, LCXVECTOR2* vcTrn		// Position
					, LCXCOLOR dcolor		// color
					)
{
	FLOAT f[ 4]={0};


	LCXVECTOR2	uv0(0,0);
	LCXVECTOR2	uv1(1,1);

	FLOAT	PosL = 0;
	FLOAT	PosT = 0;
	FLOAT	PosR = 0;
	FLOAT	PosB = 0;

	FLOAT	ImgW= (FLOAT)this->GetImgW();
	FLOAT	ImgH= (FLOAT)this->GetImgH();
	INT		nId	= this->GetName();

	FLOAT	rcW= FLOAT(rc->right - rc->left);
	FLOAT	rcH= FLOAT(rc->bottom- rc->top);


	LCXVECTOR2	vScl(1,1);
	LCXVECTOR2	vRot(0,0);
	LCXVECTOR2	vTrn(0,0);

	if(rc)
	{
		uv0.x = rc->left/ImgW;
		uv0.y = rc->top /ImgH;

		uv1.x = rc->right /ImgW;
		uv1.y = rc->bottom/ImgH;
	}

	if(vcScl)	vScl = *vcScl;
	if(vcRot)	vRot = *vcRot;
	if(vcTrn)	vTrn = *vcTrn;


	glGetFloatv(GL_VIEWPORT, f);

	PosL =  2.f * vTrn.x/f[2] - 1.f;
	PosT = -2.f * vTrn.y/f[3] + 1.f;
	PosR = PosL + 2 * rcW * vScl.x/f[2];
	PosB = PosT - 2 * rcH * vScl.y/f[3];


	glPushMatrix();
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

		glDisable(GL_ALPHA_TEST);
		glDisable(GL_LIGHTING);
		glDisable(GL_FOG);
		glDisable(GL_DEPTH_TEST);

		glEnable(GL_BLEND);
		glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

		glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NONE);
		glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NONE);
		glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP);
		glTexParameterf (GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP);

		glEnable(GL_TEXTURE_2D);
		glBindTexture (GL_TEXTURE_2D, nId);
	//	glTexEnvi (GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);

		glTranslatef(0, 0, 0);

		// Quad�� �̿��ؼ� ������
		glBegin(GL_QUADS);
			glColor4f(dcolor.r, dcolor.g, dcolor.b, dcolor.a);
			glTexCoord2f(uv0.x, uv0.y); glVertex3f(PosL, PosB, 0);
			glTexCoord2f(uv1.x, uv0.y); glVertex3f(PosR, PosB, 0);	
			glTexCoord2f(uv1.x, uv1.y); glVertex3f(PosR, PosT, 0);
			glTexCoord2f(uv0.x, uv1.y); glVertex3f(PosL, PosT, 0);
		glEnd();

		glEnable(GL_DEPTH_TEST);
		glDisable(GL_BLEND);
	glPopMatrix();
}



INT LgDev_CreateTexture(char* sCmd
					, IGLTexture** pData
					, char* sFileName
					, DWORD dcolor
					, DWORD dFilter)
{
	*pData = NULL;

	CGLTexture* pObj = new CGLTexture;

	if(FAILED(pObj->Create( sFileName, dcolor, dFilter)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}