// Implementation of the CGLFont class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include <gl/gl.h>
#include <gl/glu.h>

#include "GLMath.h"
#include "IGLFont.h"
#include "GLFont.h"


CGLFont::CGLFont()
{
	
}


CGLFont::~CGLFont()
{
	Delete();
}


INT CGLFont::Create(HDC hDC, char* sFontName, INT height)
{
	m_iHeight = height;

	if ((m_uBase = glGenLists(256)) == 0)
		return -1;

	m_iHeight = height;
	m_iHeight = -MulDiv(height, GetDeviceCaps(hDC, LOGPIXELSY), 72);
	m_hFont = CreateFont(m_iHeight, 0, 0, 0, 0, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS, DRAFT_QUALITY, DEFAULT_PITCH, sFontName);

	m_iHeight = abs(m_iHeight);


	SelectObject(hDC, m_hFont);
	wglUseFontBitmaps(hDC, 0, 256, m_uBase);
	GetCharWidth(hDC, 0, 255, m_iWidths);
	
	return 0;
}


void CGLFont::Delete()
{
	glDeleteLists(m_uBase, 256);
	DeleteObject(m_hFont);
}


void CGLFont::DrawText(FLOAT x, FLOAT y, const DWORD color, const char *str)
{
	LCXCOLOR	xColor = color;

	if (!strlen(str))
		return;


	FLOAT f[ 4]={0};
	glGetFloatv(GL_VIEWPORT, f);

	x = -1 + 2 * x/ f[2];

	y += m_iHeight;
	y +=-72.f/20.f;

	y =  1 - 2 * y/ f[3];

	glPushMatrix();
		glMatrixMode(GL_PROJECTION);
		glLoadIdentity();

		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();

	

		glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
		glDisable(GL_DEPTH_TEST);
		glDisable(GL_TEXTURE_2D);


		glColor4fv(xColor);
		glRasterPos2f(x, y);

		glPushAttrib(GL_LIST_BIT);
			glListBase(m_uBase);
			glCallLists(strlen(str), GL_UNSIGNED_BYTE, str);
		glPopAttrib();

		glEnable(GL_DEPTH_TEST);
	glPopMatrix();
}






INT LgDev_CreateFont(char* sCmd
					, IGLFont** pData
					, HDC hDC
					, char* sName
					, INT	nHeight)
{
	*pData = NULL;

	CGLFont* pObj = new CGLFont;

	if(FAILED(pObj->Create(hDC, sName, nHeight)))
	{
		delete pObj;
		return -1;
	}

	*pData = pObj;
	return 0;
}