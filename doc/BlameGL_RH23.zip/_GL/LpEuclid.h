//  For Mathematics for Euclid Field.
//
//////////////////////////////////////////////////////////////////////////////


#ifndef _LpEuclid_H_
#define _LpEuclid_H_


#if _MSC_VER >= 1200
#pragma warning(disable:4201) // anonymous unions warning
#endif


struct LPXVECTOR2
{
	LPXVECTOR2();
	LPXVECTOR2( const FLOAT * );
	LPXVECTOR2( const LPXVECTOR2& );
	LPXVECTOR2( FLOAT x, FLOAT y );


	// casting
	operator FLOAT* ();
	operator const FLOAT* () const;

	// assignment operators
	LPXVECTOR2& operator += ( const LPXVECTOR2& );
	LPXVECTOR2& operator -= ( const LPXVECTOR2& );
	LPXVECTOR2& operator *= ( FLOAT );
	LPXVECTOR2& operator /= ( FLOAT );

	// unary operators
	LPXVECTOR2 operator + () const;
	LPXVECTOR2 operator - () const;

	// binary operators
	LPXVECTOR2 operator + ( const LPXVECTOR2& ) const;
	LPXVECTOR2 operator - ( const LPXVECTOR2& ) const;
	LPXVECTOR2 operator * ( FLOAT ) const;
	LPXVECTOR2 operator / ( FLOAT ) const;

	friend LPXVECTOR2 operator * ( FLOAT, const LPXVECTOR2& );

	BOOL operator == ( const LPXVECTOR2& ) const;
	BOOL operator != ( const LPXVECTOR2& ) const;

	FLOAT x, y;
};



//    Quaternions

struct LPXQUATERNION
{
	LPXQUATERNION();
	LPXQUATERNION( const FLOAT * );
	LPXQUATERNION( const LPXQUATERNION& );
	LPXQUATERNION( FLOAT x, FLOAT y, FLOAT z, FLOAT w );

	// casting
	operator FLOAT* ();
	operator const FLOAT* () const;

	// assignment operators
	LPXQUATERNION& operator += ( const LPXQUATERNION& );
	LPXQUATERNION& operator -= ( const LPXQUATERNION& );
	LPXQUATERNION& operator *= ( const LPXQUATERNION& );
	LPXQUATERNION& operator *= ( FLOAT );
	LPXQUATERNION& operator /= ( FLOAT );

	// unary operators
	LPXQUATERNION  operator + () const;
	LPXQUATERNION  operator - () const;

	// binary operators
	LPXQUATERNION operator + ( const LPXQUATERNION& ) const;
	LPXQUATERNION operator - ( const LPXQUATERNION& ) const;
	LPXQUATERNION operator * ( const LPXQUATERNION& ) const;
	LPXQUATERNION operator * ( FLOAT ) const;
	LPXQUATERNION operator / ( FLOAT ) const;

	friend LPXQUATERNION operator * (FLOAT, const LPXQUATERNION& );

	BOOL operator == ( const LPXQUATERNION& ) const;
	BOOL operator != ( const LPXQUATERNION& ) const;

	FLOAT x, y, z, w;
};


// Planes
struct LPXPLANE
{
	LPXPLANE();
	LPXPLANE( const FLOAT* );
	LPXPLANE( const LPXPLANE& );
	LPXPLANE( FLOAT a, FLOAT b, FLOAT c, FLOAT d );

	// casting
	operator FLOAT* ();
	operator const FLOAT* () const;

	// unary operators
	LPXPLANE operator + () const;
	LPXPLANE operator - () const;

	// binary operators
	BOOL operator == ( const LPXPLANE& ) const;
	BOOL operator != ( const LPXPLANE& ) const;

	FLOAT a, b, c, d;
};



// Colors
struct LPXCOLOR
{
	LPXCOLOR();
	LPXCOLOR( DWORD argb );
	LPXCOLOR( const FLOAT * );
	LPXCOLOR( const LPXCOLOR& );
	LPXCOLOR( FLOAT r, FLOAT g, FLOAT b, FLOAT a );

	// casting
	operator DWORD () const;

	operator FLOAT* ();
	operator const FLOAT* () const;

	// assignment operators
	LPXCOLOR& operator += ( const LPXCOLOR& );
	LPXCOLOR& operator -= ( const LPXCOLOR& );
	LPXCOLOR& operator *= ( FLOAT );
	LPXCOLOR& operator /= ( FLOAT );

	// unary operators
	LPXCOLOR operator + () const;
	LPXCOLOR operator - () const;

	// binary operators
	LPXCOLOR operator + ( const LPXCOLOR& ) const;
	LPXCOLOR operator - ( const LPXCOLOR& ) const;
	LPXCOLOR operator * ( FLOAT ) const;
	LPXCOLOR operator / ( FLOAT ) const;

	friend LPXCOLOR operator * (FLOAT, const LPXCOLOR& );

	BOOL operator == ( const LPXCOLOR& ) const;
	BOOL operator != ( const LPXCOLOR& ) const;

	FLOAT r, g, b, a;
};



//   Redefinition
typedef LPXVECTOR2			VEC2;
typedef LPXQUATERNION		QUAT;
typedef LPXPLANE			DPLN;
typedef LPXCOLOR			DCLR;

#ifdef _DEBUG
	#pragma comment(lib, "LpEuclid_.lib")
#else
	#pragma comment(lib, "LpEuclid.lib")
#endif

#endif

