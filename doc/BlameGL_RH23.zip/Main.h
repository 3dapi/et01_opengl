// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MAIN_H_
#define _MAIN_H_


class CMain : public CGLApp
{
protected:
	IGLFont*	m_pFont;
	ILcCam*		m_pCam;
	ILcInput*	m_pInput;
	ILcxGrid*	m_pGrid;

	IGLTexture*	m_pTex;

	ILcMdl*		m_pMdlOrg1	;		// Original
	ILcMdl*		m_pMdlIns1	;		// Instance

	ILcMdl*		m_pMdlOrg2	;		// Original
	ILcMdl*		m_pMdlIns2	;		// Instance

public:
	CMain();
	virtual ~CMain(){};

	virtual HRESULT Init();
	virtual HRESULT	Destroy();
	virtual HRESULT	FrameMove();
	virtual HRESULT Render();

	virtual LRESULT MsgProc(HWND,UINT,WPARAM,LPARAM);
};


#define GMAIN		g_pApp
extern CMain*		g_pApp;

#endif

