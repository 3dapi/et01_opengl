// Implementation of the CLcAseInst class.
//
////////////////////////////////////////////////////////////////////////////////


#include <stdio.h>
#include <windows.h>
#include <gl/gl.h>


#include "../_GL/GLMath.h"
#include "../_GL/IGLTexture.h"
#include "../_GL/GLUtil.h"

#include "ILcMdl.h"
#include "LcAse.h"
#include "LcAseInst.h"


#define SAFE_DELETE(p)       { if(p) { delete (p);     (p)=NULL; } }
#define SAFE_DELETE_ARRAY(p) { if(p) { delete[] (p);   (p)=NULL; } }


CLcAseInst::TlinkTm::TlinkTm()
{
	nPrn	= -1;

	mtW.Identity();
	mtL.Identity();
}


CLcAseInst::CLcAseInst()
{
	m_nMtl	= 0;
	m_pMtl	= NULL;
	m_nGeo	= 0;
	m_pGeo	= NULL;

	m_pOrg	= NULL;

	m_dFrmCur = 0;
	m_dTimeCur= 0;

	m_mtWld.Identity();
}

CLcAseInst::~CLcAseInst()
{
	Destroy();
}


INT CLcAseInst::Create(void* p1, void* p2, void* p3, void* p4)
{
	m_pOrg	= (CLcAse*)p1;

	m_nMtl	= m_pOrg->GetNumMtl();
	m_pMtl	= m_pOrg->GetMtrl();

	m_nGeo	= m_pOrg->GetNumGeo();
	m_pGeo	= m_pOrg->GetGeometry();


	m_pTM = new TlinkTm[m_nGeo]	;	// World and Animation Matrix


	// Original�� ������ ����
	for(INT i=0; i<m_nGeo; ++i)
	{
		m_pTM[i].mtL = m_pGeo[i].mtL;
		m_pTM[i].mtW = m_pGeo[i].mtW;

		m_pTM[i].nPrn= m_pGeo[i].nNodePrn;
	}


	struct Tscene
	{
		char sVer[16];	INT F; INT L; INT S; INT T;
	} t;

	memcpy(&t, m_pOrg->GetHeader(), sizeof(Tscene));

	m_nFrmF	= t.F;		// First Frame
	m_nFrmL	= t.L;		// Last Frame
	m_nFrmS	= t.S;		// Frame Speed
	m_nFrmT	= t.T;		// Tick per Frame

	return 0;
}


void CLcAseInst::Destroy()
{
	m_pOrg = NULL;

	SAFE_DELETE_ARRAY(	m_pTM	);
}






INT CLcAseInst::FrameMove()
{
	INT		i = 0;
	INT		nFrame	=0;

	// Frame = FrameSpeed * Time;
	m_dFrmCur = m_nFrmS * m_dTimeCur;

	nFrame	= INT(m_dFrmCur);

	if(nFrame>= m_nFrmL)
	{
		// ������ �ð��� ����ð����� �����Ѵ�.
		m_dTimeCur = m_dFrmCur - nFrame;
	}

	for(i=0; i<m_nGeo; ++i)
	{
		TlinkTm*	pTM = &m_pTM[i];
		
		m_pOrg->GetAniTrack(&pTM->mtL, i, m_dFrmCur);

		// �θ��� ���� ����� ���� �ڽ��� ���� ����� �ϼ��Ѵ�.
		LCXMATRIX	mtPrn =LCXMATRIX(1,0,0,0,  0,1,0,0,  0,0,1,0,  0,0,0,1);

		if(0 <= pTM->nPrn)
			mtPrn	= m_pTM[pTM->nPrn].mtW;

		pTM->mtW = pTM->mtL * mtPrn;
	}


	return 0;
}




void CLcAseInst::Render()
{
	if(!m_pGeo)
		return;

	INT			i=0;
	LCXMATRIX	mtW;


	for(i=0; i<m_nGeo; ++i)
	{
		CLcAse::AseGeo*		pGeo = &m_pGeo[i];

		if(NULL == pGeo->m_pVtx)
			continue;

		IGLTexture* pTx=NULL;

		if(pGeo->nMtlRef>=0)
			pTx = m_pMtl[pGeo->nMtlRef].pTex;
		
		if(NULL == pTx)
			continue;

		pTx->SetTexure(GL_MODULATE);


		glPushMatrix();
			mtW = m_pTM[i].mtW * m_mtWld;
			glMultMatrixf((const GLfloat *)&mtW);
			LcGL_DrawIndexedPrimitiveUP(GL_TRIANGLES, pGeo->m_iNix, pGeo->m_pIdx, pGeo->m_dFVF, pGeo->m_pVtx, pGeo->m_dVtx);
		glPopMatrix();
	}

}


INT CLcAseInst::SetAttrib(char* sCmd, void* pData)
{
	if( 0 ==_stricmp("Advance Time", sCmd))
	{
		float	fElapsedTime = *((float*)pData);

		m_dTimeCur += fElapsedTime;

		return 0;
	}

	else if( 0 ==_stricmp("World Matrix", sCmd))
	{
		LCXMATRIX* pTM = (LCXMATRIX*)pData;

		m_mtWld	= *pTM;
		return 0;
	}


	return -1;
}


INT CLcAseInst::GetAttrib(char* sCmd, void* pData)
{
	if( 0 ==_stricmp("Current Time", sCmd))
	{
		*((float*)pData) = m_dTimeCur;

		return 0;
	}

	return -1;
}




