// Implementation of the CLcAse class.
//
////////////////////////////////////////////////////////////////////////////////


#include <stdio.h>
#include <windows.h>
#include <gl/gl.h>


#include "../_GL/GLMath.h"
#include "../_GL/IGLTexture.h"

#include "ILcMdl.h"
#include "LcAse.h"
#include "LcAseInst.h"

#include "LcAseBin.h"
#include "LcAseBinInst.h"



INT LcMdl_CreateAse(char* sCmd
				 , ILcMdl** pData		// Output data
				 , void* pDev			// Device
				 , void* sName			// Model File Name
				 , void* pOriginal		// Original ILcMdl Pointer for Clone Creating
				 , void* p4				// Not Use
				 , void* p5				// Not Use
				 )
{
	ILcMdl*	p= NULL;
	*pData	= NULL;

	if(NULL==sCmd)
		return -1;


	if(0==_stricmp(sCmd, "Ase Text PC"))
	{
		if(sName && !pOriginal)
		{
//			char*	sFile = (char*)sName;
//			char drive[_MAX_DRIVE]={0};
//			char dir[_MAX_DIR]={0};
//			char fname[_MAX_FNAME]={0};
//			char ext[_MAX_EXT]={0};
//
//			_splitpath( sFile, drive, dir, fname, ext );

			p= new CLcAse;

			if(FAILED(p->Create(pDev, sName)))
			{
				delete p;
				return -1;
			}
		}
		else
		{
			p= new CLcAseInst;

			if(FAILED(p->Create(pOriginal)))
			{
				delete p;
				return -1;
			}
		}
	}
	
	else if(0==_stricmp(sCmd, "Ase Bin PC"))
	{
		if(sName && !pOriginal)
		{
			p= new CLcAseB;

			if(FAILED(p->Create(pDev, sName)))
			{
				delete p;
				return -1;
			}
		}
		else
		{
			p= new CLcAseBInst;

			if(FAILED(p->Create(pOriginal)))
			{
				delete p;
				return -1;
			}
		}
	}


	*pData = p;
	
	return 0;
}