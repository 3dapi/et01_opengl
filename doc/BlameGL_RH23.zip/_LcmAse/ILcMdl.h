// Interface for the ILcMdl class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _ILcMdl_H_
#define _ILcMdl_H_


struct ILcMdl
{
	#define LCM_TX_NAME			128
	#define	LCM_HEADER_SIZE		256

	#define D3DFVF_XYZ			0x002
	#define D3DFVF_NORMAL		0x010
	#define D3DFVF_DIFFUSE		0x040
	#define D3DFVF_TEX1			0x100
	#define D3DFVF_TEX2			0x200

	virtual ~ILcMdl(){};

	virtual INT		Create(void* p1=NULL, void* p2=NULL, void* p3=NULL, void* p4=NULL)=0;
	virtual void	Destroy()=0;

	virtual	INT		FrameMove()=0;
	virtual void	Render()=0;

	virtual INT		SetAttrib(char* sCmd, void* pData)=0;
	virtual INT		GetAttrib(char* sCmd, void* pData)=0;
};


INT LcMdl_CreateAse(char* sCmd
				 , ILcMdl** pData		// Output data
				 , void* pDev			// Device
				 , void* sName	= NULL	// Model File Name
				 , void* pOriginal=NULL	// Original ILcMdl Pointer for Clone Creating
				 , void* p4=NULL		// Not Use
				 , void* p5=NULL		// Not Use
				 );

#endif

