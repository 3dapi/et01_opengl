// Interface for the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#if _MSC_VER > 1000
#pragma once
#endif

#ifndef _McScene_H_
#define _McScene_H_


class CMcScene
{
protected:
	IGLSprite*	m_pSprite;
	
	IGLTexture*	m_pTex1;
	IGLTexture*	m_pTex2;
	IGLTexture*	m_pTex3;

public:
	CMcScene();
	virtual ~CMcScene();

	virtual	INT		Create();
	virtual	void	Destroy();
	virtual	INT		FrameMove();
	virtual	void	Render();
};


#endif

