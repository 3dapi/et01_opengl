// Implementation of the GLMath class.
//
////////////////////////////////////////////////////////////////////////////////



#include "GLMath.h"


// for integer type structures
////////////////////////////////////////////////////////////////////////////////

LCXVEC2s::LCXVEC2s()
{
	x = 0;	y = 0;
}

LCXVEC2s::LCXVEC2s(const SHORT* v)
{
	if(!v)
		return;

	x = v[0];	y = v[1];
}

LCXVEC2s::LCXVEC2s(const LCXVEC2s& v)
{
	x = v.x;	y = v.y;
}

LCXVEC2s::LCXVEC2s(const LCXVEC2s* v)
{
	if(!v)
		return;

	x = v->x;	y = v->y;
}

LCXVEC2s::LCXVEC2s(SHORT X, SHORT Y) : x(X), y(Y)
{
}

LCXVEC2s::operator SHORT*()
{
	return(SHORT*)&x;
}

LCXVEC2s::operator const SHORT*() const
{
	return(const SHORT*)&x;
}

SHORT& LCXVEC2s::operator[](int n)
{
	return *((&x)+ n);
}

// assignment operators
LCXVEC2s& LCXVEC2s::operator +=(const LCXVEC2s& v)	{	x += v.x; y += v.y;	return *this;	}
LCXVEC2s& LCXVEC2s::operator -=(const LCXVEC2s& v)	{	x -= v.x; y -= v.y;	return *this;	}
LCXVEC2s& LCXVEC2s::operator *=(SHORT v)			{	x *= v;	y *= v;		return *this;	}
LCXVEC2s& LCXVEC2s::operator /=(SHORT v)			{	x /= v;	y /= v;		return *this;	}

// unary operators
LCXVEC2s LCXVEC2s::operator +() const				{	return *this;						}
LCXVEC2s LCXVEC2s::operator -() const				{	return LCXVEC2s(-x, -y);			}

// binary operators
LCXVEC2s LCXVEC2s::operator +(const LCXVEC2s& v) const{	return LCXVEC2s(x + v.x, y + v.y);	}
LCXVEC2s LCXVEC2s::operator -(const LCXVEC2s& v) const{	return LCXVEC2s(x - v.x, y - v.y);	}
LCXVEC2s LCXVEC2s::operator *(SHORT v) const		{	return LCXVEC2s(x * v, y * v);		}
LCXVEC2s LCXVEC2s::operator /(SHORT v) const		{ 	return LCXVEC2s(x / v, y / v);		}

LCXVEC2s operator *(SHORT f, const LCXVEC2s& v)		{	return LCXVEC2s(f * v.x, f * v.y);	}
LCXVEC2s operator /(SHORT f, const LCXVEC2s& v)		{	return LCXVEC2s(f / v.x, f / v.y);	}

BOOL LCXVEC2s::operator ==(const LCXVEC2s& v) const	{	return x == v.x && y == v.y;		}
BOOL LCXVEC2s::operator !=(const LCXVEC2s& v) const	{	return x != v.x || y != v.y;		}





// for float type structures
////////////////////////////////////////////////////////////////////////////////



LCXVEC3s::LCXVEC3s()
{
	x = 0;	y = 0;	z = 0;
}

LCXVEC3s::LCXVEC3s(const SHORT* v)
{
	if(!v)
		return;

	x = v[0];	y = v[1];	z = v[2];
}

LCXVEC3s::LCXVEC3s(const LCXVEC3s& v)
{
	x = v.x;	y = v.y;	z = v.z;
}

LCXVEC3s::LCXVEC3s(const LCXVEC3s* v)
{
	if(!v)
		return;

	x = v->x;	y = v->y;	z = v->z;
}

LCXVEC3s::LCXVEC3s(SHORT X, SHORT Y, SHORT Z) : x(X), y(Y), z(Z)
{
}

LCXVEC3s::operator SHORT*()
{
	return(SHORT*)&x;
}

LCXVEC3s::operator const SHORT*() const
{
	return(const SHORT*)&x;
}


SHORT& LCXVEC3s::operator[](int n)
{
	return *((&x)+ n);
}

// assignment operators
LCXVEC3s& LCXVEC3s::operator +=(const LCXVEC3s& v)	{	x += v.x; y += v.y; z += v.z;	return *this;	}
LCXVEC3s& LCXVEC3s::operator -=(const LCXVEC3s& v)	{	x -= v.x; y -= v.y; z -= v.z;	return *this;	}
LCXVEC3s& LCXVEC3s::operator *=(SHORT v)			{	x *= v;	y *= v;	z *= v;			return *this;	}
LCXVEC3s& LCXVEC3s::operator /=(SHORT v)			{	x /= v;	y /= v;	z /= v;			return *this;	}

// unary operators
LCXVEC3s LCXVEC3s::operator +() const				{	return *this;									}
LCXVEC3s LCXVEC3s::operator -() const				{	return LCXVEC3s(-x, -y, -z);					}

// binary operators
LCXVEC3s LCXVEC3s::operator +(const LCXVEC3s& v) const{	return LCXVEC3s(x + v.x, y + v.y, z + v.z);		}
LCXVEC3s LCXVEC3s::operator -(const LCXVEC3s& v) const{	return LCXVEC3s(x - v.x, y - v.y, z - v.z);		}
LCXVEC3s LCXVEC3s::operator *(SHORT v) const		{	return LCXVEC3s(x * v, y * v, z * v);			}
LCXVEC3s LCXVEC3s::operator /(SHORT v) const		{ 	return LCXVEC3s(x / v, y / v, z / v);			}

LCXVEC3s operator *(SHORT f, const LCXVEC3s& v)		{	return LCXVEC3s(f * v.x, f * v.y, f * v.z);		}
LCXVEC3s operator /(SHORT f, const LCXVEC3s& v)		{	return LCXVEC3s(f / v.x, f / v.y, f / v.z);		}

BOOL LCXVEC3s::operator ==(const LCXVEC3s& v) const	{	return x == v.x && y == v.y && z == v.z;		}
BOOL LCXVEC3s::operator !=(const LCXVEC3s& v) const	{	return x != v.x || y != v.y || z != v.z;		}



// for Int
////////////////////////////////////////////////////////////////////////////////


LCXVEC2i::LCXVEC2i()
{
	x = 0;	y = 0;
}

LCXVEC2i::LCXVEC2i(const INT* v)
{
	if(!v)
		return;

	x = v[0];	y = v[1];
}

LCXVEC2i::LCXVEC2i(const LCXVEC2i& v)
{
	x = v.x;	y = v.y;
}

LCXVEC2i::LCXVEC2i(const LCXVEC2i* v)
{
	if(!v)
		return;

	x = v->x;	y = v->y;
}

LCXVEC2i::LCXVEC2i(INT X, INT Y) : x(X), y(Y)
{
}

LCXVEC2i::operator INT*()
{
	return(INT*)&x;
}

LCXVEC2i::operator const INT*() const
{
	return(const INT*)&x;
}


INT& LCXVEC2i::operator[](int n)
{
	return *((&x)+ n);
}


// assignment operators
LCXVEC2i& LCXVEC2i::operator +=(const LCXVEC2i& v)	{	x += v.x; y += v.y;	return *this;	}
LCXVEC2i& LCXVEC2i::operator -=(const LCXVEC2i& v)	{	x -= v.x; y -= v.y;	return *this;	}
LCXVEC2i& LCXVEC2i::operator *=(INT v)				{	x *= v;	y *= v;		return *this;	}
LCXVEC2i& LCXVEC2i::operator /=(INT v)				{	x /= v;	y /= v;		return *this;	}

// unary operators
LCXVEC2i LCXVEC2i::operator +() const				{	return *this;						}
LCXVEC2i LCXVEC2i::operator -() const				{	return LCXVEC2i(-x, -y);			}

// binary operators
LCXVEC2i LCXVEC2i::operator +(const LCXVEC2i& v) const{	return LCXVEC2i(x + v.x, y + v.y);	}
LCXVEC2i LCXVEC2i::operator -(const LCXVEC2i& v) const{	return LCXVEC2i(x - v.x, y - v.y);	}
LCXVEC2i LCXVEC2i::operator *(INT v) const			{	return LCXVEC2i(x * v, y * v);		}
LCXVEC2i LCXVEC2i::operator /(INT v) const			{	return LCXVEC2i(x / v, y / v);		}

LCXVEC2i operator *(INT f, const LCXVEC2i& v)		{	return LCXVEC2i(f * v.x, f * v.y);	}
LCXVEC2i operator /(INT f, const LCXVEC2i& v)		{	return LCXVEC2i(f / v.x, f / v.y);	}

BOOL LCXVEC2i::operator ==(const LCXVEC2i& v) const	{	return x == v.x && y == v.y;		}
BOOL LCXVEC2i::operator !=(const LCXVEC2i& v) const	{	return x != v.x || y != v.y;		}


////////////////////////////////////////////////////////////////////////////////


LCXVEC3i::LCXVEC3i()
{
	x = 0;	y = 0;	z = 0;
}

LCXVEC3i::LCXVEC3i(const INT* v)
{
	if(!v)
		return;

	x = v[0];	y = v[1];	z = v[2];
}

LCXVEC3i::LCXVEC3i(const LCXVEC3i& v)
{
	x = v.x;	y = v.y;	z = v.z;
}

LCXVEC3i::LCXVEC3i(const LCXVEC3i* v)
{
	if(!v)
		return;

	x = v->x;	y = v->y;	z = v->z;
}

LCXVEC3i::LCXVEC3i(INT X, INT Y, INT Z) : x(X), y(Y), z(Z)
{
}

LCXVEC3i::operator INT*()
{
	return(INT*)&x;
}

LCXVEC3i::operator const INT*() const
{
	return(const INT*)&x;
}


INT& LCXVEC3i::operator[](int n)
{
	return *((&x)+ n);
}

// assignment operators
LCXVEC3i& LCXVEC3i::operator +=(const LCXVEC3i& v)	{	x += v.x; y += v.y; z += v.z;	return *this;	}
LCXVEC3i& LCXVEC3i::operator -=(const LCXVEC3i& v)	{	x -= v.x; y -= v.y; z -= v.z;	return *this;	}
LCXVEC3i& LCXVEC3i::operator *=(INT v)				{	x *= v;	y *= v;	z *= v;			return *this;	}
LCXVEC3i& LCXVEC3i::operator /=(INT v)				{	x /= v;	y /= v;	z /= v;			return *this;	}

// unary operators
LCXVEC3i LCXVEC3i::operator +() const				{	return *this;									}
LCXVEC3i LCXVEC3i::operator -() const				{	return LCXVEC3i(-x, -y, -z);					}

// binary operators
LCXVEC3i LCXVEC3i::operator +(const LCXVEC3i& v) const{	return LCXVEC3i(x + v.x, y + v.y, z + v.z);		}
LCXVEC3i LCXVEC3i::operator -(const LCXVEC3i& v) const{	return LCXVEC3i(x - v.x, y - v.y, z - v.z);		}
LCXVEC3i LCXVEC3i::operator *(INT v) const			{	return LCXVEC3i(x * v, y * v, z * v);			}
LCXVEC3i LCXVEC3i::operator /(INT v) const			{	return LCXVEC3i(x / v, y / v, z / v);			}

LCXVEC3i operator *(INT f, const LCXVEC3i& v)		{	return LCXVEC3i(f * v.x, f * v.y, f * v.z);		}
LCXVEC3i operator /(INT f, const LCXVEC3i& v)		{	return LCXVEC3i(f / v.x, f / v.y, f / v.z);		}

BOOL LCXVEC3i::operator ==(const LCXVEC3i& v) const	{	return x == v.x && y == v.y && z == v.z;		}
BOOL LCXVEC3i::operator !=(const LCXVEC3i& v) const	{	return x != v.x || y != v.y || z != v.z;		}

// Color
////////////////////////////////////////////////////////////////////////////////


LCXCOLORb::LCXCOLORb()
{
	r = 255; g = 255; b = 255; a = 255;
}

LCXCOLORb::LCXCOLORb( DWORD dw )
{
	r = (BYTE) (dw >> 16);
	g = (BYTE) (dw >>  8);
	b = (BYTE) (dw >>  0);
	a = (BYTE) (dw >> 24);
}

LCXCOLORb::LCXCOLORb(const BYTE* pf )
{
	r = pf[0];	g = pf[1];	b = pf[2];	a = pf[3];
}

LCXCOLORb::LCXCOLORb(const LCXCOLORb& v )
{
	r = v.r;	g = v.g;	b = v.b;	a = v.a;
}

LCXCOLORb::LCXCOLORb( BYTE _R, BYTE _G, BYTE _B, BYTE _A )
{
	r = _R;	g = _G;	b = _B;	a = _A;
}


// casting
LCXCOLORb::operator DWORD () const					{	return (a << 24) | (r << 16) | (g << 8) | b;	}
LCXCOLORb::operator BYTE* ()						{	return (BYTE*) &r;								}
LCXCOLORb::operator const BYTE* () const			{	return (const BYTE*) &r;						}

// assignment operators
LCXCOLORb& LCXCOLORb::operator+= (const LCXCOLORb& c){	r += c.r;	g += c.g;	b += c.b;	a += c.a;	return *this;	}
LCXCOLORb& LCXCOLORb::operator-= (const LCXCOLORb& c){	r -= c.r;	g -= c.g;	b -= c.b;	a -= c.a;	return *this;	}
LCXCOLORb& LCXCOLORb::operator*= (const LCXCOLORb& c){	r *= c.r;	g *= c.g;	b *= c.b;	a *= c.a;	return *this;	}
LCXCOLORb& LCXCOLORb::operator*= (BYTE f)			{	r *= f;		g *= f;		b *= f;		a *= f;		return *this;	}
LCXCOLORb& LCXCOLORb::operator/= (BYTE f)			{	r /= f;		g /= f;		b /= f;		a /= f;		return *this;	}

// unary operators
LCXCOLORb LCXCOLORb::operator+ () const				{	return *this;						}
LCXCOLORb LCXCOLORb::operator- () const				{	return LCXCOLORb(-r, -g, -b, -a);	}

// binary operators
LCXCOLORb LCXCOLORb::operator+ (const LCXCOLORb& c)const{	return LCXCOLORb(r + c.r, g + c.g, b + c.b, a + c.a);	}
LCXCOLORb LCXCOLORb::operator- (const LCXCOLORb& c)const{	return LCXCOLORb(r - c.r, g - c.g, b - c.b, a - c.a);	}
LCXCOLORb LCXCOLORb::operator* (const LCXCOLORb& c)const{	return LCXCOLORb(r * c.r, g * c.g, b * c.b, a * c.a);	}
LCXCOLORb LCXCOLORb::operator* (BYTE f) const			{	return LCXCOLORb(r * f, g * f, b * f, a * f);			}
LCXCOLORb LCXCOLORb::operator/ (BYTE f) const			{	return LCXCOLORb(r / f, g / f, b / f, a / f);			}
LCXCOLORb operator* (BYTE f, const LCXCOLORb& c)		{	return LCXCOLORb(f * c.r, f * c.g, f * c.b, f * c.a);	}
BOOL LCXCOLORb::operator == (const LCXCOLORb& c) const	{	return r == c.r && g == c.g && b == c.b && a == c.a;	}
BOOL LCXCOLORb::operator != (const LCXCOLORb& c) const	{	return r != c.r || g != c.g || b != c.b || a != c.a;	}





////////////////////////////////////////////////////////////////////////////////





LCXVECTOR2::LCXVECTOR2()
{
	x = 0;	y = 0;
}

LCXVECTOR2::LCXVECTOR2(const FLOAT* v)
{
	if(!v)
		return;

	x = v[0];	y = v[1];
}

LCXVECTOR2::LCXVECTOR2(const LCXVECTOR2& v)
{
	x = v.x;	y = v.y;
}

LCXVECTOR2::LCXVECTOR2(const LCXVECTOR2* v)
{
	if(!v)
		return;

	x = v->x;	y = v->y;
}

LCXVECTOR2::LCXVECTOR2(FLOAT X, FLOAT Y) : x(X), y(Y)
{
}

LCXVECTOR2::operator FLOAT*()
{
	return(FLOAT*)&x;
}

LCXVECTOR2::operator const FLOAT*() const
{
	return(const FLOAT*)&x;
}


FLOAT& LCXVECTOR2::operator[](int n)
{
	return *((&x)+ n);
}

// assignment operators
LCXVECTOR2& LCXVECTOR2::operator +=(const LCXVECTOR2& v)
{
	x += v.x;	y += v.y;
	return *this;
}

LCXVECTOR2& LCXVECTOR2::operator -=(const LCXVECTOR2& v)
{
	x -= v.x;	y -= v.y;
	return *this;
}

LCXVECTOR2& LCXVECTOR2::operator *=(FLOAT v)
{
	x *= v;	y *= v;
	return *this;
}

LCXVECTOR2& LCXVECTOR2::operator /=(FLOAT v)
{
	v = 1.f/v;
	x *= v;	y *= v;
	return *this;
}


// unary operators
LCXVECTOR2 LCXVECTOR2::operator +() const
{
	return *this;
}

LCXVECTOR2 LCXVECTOR2::operator -() const
{
	return LCXVECTOR2(-x, -y);
}

// binary operators
LCXVECTOR2 LCXVECTOR2::operator +(const LCXVECTOR2& v) const	{	return LCXVECTOR2(x + v.x, y + v.y);	}
LCXVECTOR2 LCXVECTOR2::operator -(const LCXVECTOR2& v) const	{	return LCXVECTOR2(x - v.x, y - v.y);	}
LCXVECTOR2 LCXVECTOR2::operator *(FLOAT v) const				{	return LCXVECTOR2(x * v, y * v);		}
LCXVECTOR2 LCXVECTOR2::operator /(FLOAT v) const	{ v = 1.f/v;	return LCXVECTOR2(x * v, y * v);		}

LCXVECTOR2 operator *(FLOAT f, const LCXVECTOR2& v){			return LCXVECTOR2(f * v.x, f * v.y);		}
LCXVECTOR2 operator /(FLOAT f, const LCXVECTOR2& v){f=1.f/f;	return LCXVECTOR2(f * v.x, f * v.y);		}

BOOL LCXVECTOR2::operator ==(const LCXVECTOR2& v) const	{	return x == v.x && y == v.y;			}
BOOL LCXVECTOR2::operator !=(const LCXVECTOR2& v) const	{	return x != v.x || y != v.y;			}

// Dot Product
FLOAT LCXVECTOR2::operator *(const LCXVECTOR2& v)
{
	return x * v.x + y * v.y;
}


// Dot Product
FLOAT operator *(const LCXVECTOR2& v1, const LCXVECTOR2& v2)
{
	return v1.x * v2.x + v1.y * v2.y;
}


// Cross Product
FLOAT LCXVECTOR2::operator ^(const LCXVECTOR2& v)
{
	return (x * v.y  -  y * v.x	);
}


// Cross Product
FLOAT operator ^(const LCXVECTOR2& v1, const LCXVECTOR2& v2)
{
	return FLOAT(v1.x * v2.y  -  v1.y * v2.x );
}


// Transform: vector * Matrix
LCXVECTOR2 LCXVECTOR2::operator *(const FLOAT* v)
{
	FLOAT X = x * v[0] + y * v[4];
	FLOAT Y = x * v[1] + y * v[5];
	FLOAT W = x * v[3] + y * v[7];

	W = 1.F/W;

	return LCXVECTOR2(X * W, Y * W);
}

// Transform: Matrix * vector;
LCXVECTOR2 operator *(const FLOAT* v1, const LCXVECTOR2& v2)
{
	FLOAT X = v2.x * v1[ 0] + v2.y * v1[ 1];
	FLOAT Y = v2.x * v1[ 4] + v2.y * v1[ 5];
	FLOAT W = v2.x * v1[12] + v2.y * v1[13];

	W = 1.F/W;

	return LCXVECTOR2(X * W, Y * W);
}


// Length
FLOAT LCXVECTOR2::Length()
{
	return sqrtf(x*x + y*y);
}

// Length Square
FLOAT LCXVECTOR2::LengthSq()
{
	return(x*x + y*y);
}


LCXVECTOR2 LCXVECTOR2::Normalize()
{
	FLOAT l  = this->Length();
	if(l == 0)
		return *this;

	x *= l;
	y *= l;
	return *this;
}


LCXVECTOR2 LCXVECTOR2::Normalize(const LCXVECTOR2* v)
{
	FLOAT l  = 0;

	*this = v;
	l  = this->Length();

	if(l == 0)
		return *this;

	l = 1.f/l;
	x *= l;	y *= l;

	return *this;
}



FLOAT LCXVECTOR2::Dot(const LCXVECTOR2* v)
{
	return (this->x * v->x +
			this->y * v->y
			);
}


FLOAT LCXVECTOR2::Cross(const LCXVECTOR2* v)
{
	return (x * v->y  -  y * v->x	);
}


////////////////////////////////////////////////////////////////////////////////
LCXVECTOR3::LCXVECTOR3()
{
	x = 0;	y = 0;	z = 0;
}

LCXVECTOR3::LCXVECTOR3(const FLOAT* v)
{
	if(!v)
		return;

	x = v[0];	y = v[1];	z = v[2];
}

LCXVECTOR3::LCXVECTOR3(const LCXVECTOR3& v)
{
	x = v.x;	y = v.y;	z = v.z;
}

LCXVECTOR3::LCXVECTOR3(const LCXVECTOR3* v)
{
	if(!v)
		return;

	x = v->x;	y = v->y;	z = v->z;
}

LCXVECTOR3::LCXVECTOR3(FLOAT X, FLOAT Y, FLOAT Z) : x(X), y(Y), z(Z)
{
}

LCXVECTOR3::operator FLOAT*()
{
	return(FLOAT*)&x;
}

LCXVECTOR3::operator const FLOAT*() const
{
	return(const FLOAT*)&x;
}


FLOAT& LCXVECTOR3::operator[](int n)
{
	return *((&x)+ n);
}

// assignment operators
LCXVECTOR3& LCXVECTOR3::operator +=(const LCXVECTOR3& v)
{
	x += v.x;	y += v.y;	z += v.z;
	return *this;
}

LCXVECTOR3& LCXVECTOR3::operator -=(const LCXVECTOR3& v)
{
	x -= v.x;	y -= v.y;	z -= v.z;
	return *this;
}

LCXVECTOR3& LCXVECTOR3::operator *=(FLOAT v)
{
	x *= v;	y *= v;	z *= v;
	return *this;
}

LCXVECTOR3& LCXVECTOR3::operator /=(FLOAT v)
{
	v = 1.f/v;
	x *= v;	y *= v;	z *= v;
	return *this;
}


// unary operators
LCXVECTOR3 LCXVECTOR3::operator +() const
{
	return *this;
}

LCXVECTOR3 LCXVECTOR3::operator -() const
{
	return LCXVECTOR3(-x, -y, -z);
}

// binary operators
LCXVECTOR3 LCXVECTOR3::operator +(const LCXVECTOR3& v) const	{	return LCXVECTOR3(x + v.x, y + v.y, z + v.z);	}
LCXVECTOR3 LCXVECTOR3::operator -(const LCXVECTOR3& v) const	{	return LCXVECTOR3(x - v.x, y - v.y, z - v.z);	}
LCXVECTOR3 LCXVECTOR3::operator *(FLOAT v) const				{	return LCXVECTOR3(x * v, y * v, z * v);			}
LCXVECTOR3 LCXVECTOR3::operator /(FLOAT v) const	{ v = 1.f/v;	return LCXVECTOR3(x * v, y * v, z * v);			}

LCXVECTOR3 operator *(FLOAT f, const LCXVECTOR3& v){			return LCXVECTOR3(f * v.x, f * v.y, f * v.z);	}
LCXVECTOR3 operator /(FLOAT f, const LCXVECTOR3& v){f=1.f/f;	return LCXVECTOR3(f * v.x, f * v.y, f * v.z);	}

BOOL LCXVECTOR3::operator ==(const LCXVECTOR3& v) const	{	return x == v.x && y == v.y && z == v.z;	}
BOOL LCXVECTOR3::operator !=(const LCXVECTOR3& v) const	{	return x != v.x || y != v.y || z != v.z;	}

// Dot Product
FLOAT LCXVECTOR3::operator *(const LCXVECTOR3& v)
{
	return x * v.x + y * v.y + z * v.z;
}


// Dot Product
FLOAT operator *(const LCXVECTOR3& v1, const LCXVECTOR3& v2)
{
	return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z;
}


// Cross Product
LCXVECTOR3 LCXVECTOR3::operator ^(const LCXVECTOR3& v)
{
	return LCXVECTOR3(y * v.z  -  z * v.y
		, z * v.x  -  x * v.z
		, x * v.y  -  y * v.x	);
}


// Cross Product
LCXVECTOR3 operator ^(const LCXVECTOR3& v1, const LCXVECTOR3& v2)
{
	return LCXVECTOR3(v1.y * v2.z  -  v1.z * v2.y
		, v1.z * v2.x  -  v1.x * v2.z
		, v1.x * v2.y  -  v1.y * v2.x	);
}


// Transform: vector * Matrix
LCXVECTOR3 LCXVECTOR3::operator *(const FLOAT* v)
{
	FLOAT X = x * v[0] + y * v[4] + z * v[ 8] + v[12];
	FLOAT Y = x * v[1] + y * v[5] + z * v[ 9] + v[13];
	FLOAT Z = x * v[2] + y * v[6] + z * v[10] + v[14];
	FLOAT W = x * v[3] + y * v[7] + z * v[11] + v[15];

	W = 1.F/W;

	return LCXVECTOR3(X * W, Y * W, Z* W);
}

// Transform: Matrix * vector;
LCXVECTOR3 operator *(const FLOAT* v1, const LCXVECTOR3& v2)
{
	FLOAT X = v2.x * v1[ 0] + v2.y * v1[ 1] + v2.z * v1[ 2] + v1[ 3];
	FLOAT Y = v2.x * v1[ 4] + v2.y * v1[ 5] + v2.z * v1[ 6] + v1[ 7];
	FLOAT Z = v2.x * v1[ 8] + v2.y * v1[ 9] + v2.z * v1[10] + v1[11];
	FLOAT W = v2.x * v1[12] + v2.y * v1[13] + v2.z * v1[14] + v1[15];

	W = 1.F/W;

	return LCXVECTOR3(X * W, Y * W, Z* W);
}


// Length
FLOAT LCXVECTOR3::Length()
{
	return sqrtf(x*x + y*y + z*z);
}

// Length Square
FLOAT LCXVECTOR3::LengthSq()
{
	return(x*x + y*y + z*z);
}


LCXVECTOR3 LCXVECTOR3::Normalize()
{
	FLOAT l  = this->Length();
	if(l == 0)
		return *this;

	l = 1.f/l;
	x *= l;	y *= l;	z *= l;

	return *this;
}


LCXVECTOR3 LCXVECTOR3::Normalize(const LCXVECTOR3* v)
{
	FLOAT l  = 0;

	*this = v;
	l  = this->Length();

	if(l == 0)
		return *this;

	l = 1.f/l;
	x *= l;	y *= l;	z *= l;

	return *this;
}


FLOAT LCXVECTOR3::Dot(const LCXVECTOR3* v)
{
	return (this->x * v->x +
			this->y * v->y +
			this->z * v->z	);
}


LCXVECTOR3 LCXVECTOR3::Cross(const LCXVECTOR3* v)
{
	x  = (this->y * v->z  -  this->z * v->y);
	y  = (this->z * v->x  -  this->x * v->z);
	z  = (this->x * v->y  -  this->y * v->x);

	return *this;
}







////////////////////////////////////////////////////////////////////////////////
LCXVECTOR4::LCXVECTOR4() : x(0), y(0), z(0), w(0)
{
}

LCXVECTOR4::LCXVECTOR4(const FLOAT* v)
{
	if(!v)
		return;

	x = v[0]; y = v[1];	z = v[2]; z = v[3];
}

LCXVECTOR4::LCXVECTOR4(const LCXVECTOR4& v)
{
	x = v.x;	y = v.y;	z = v.z;	w = v.w;
}

LCXVECTOR4::LCXVECTOR4(const LCXVECTOR4* v)
{
	if(!v)
		return;

	x = v->x;	y = v->y;	z = v->z;	w = v->w;
}

LCXVECTOR4::LCXVECTOR4(FLOAT X, FLOAT Y, FLOAT Z, FLOAT W) : x(X), y(Y), z(Z), w(W)
{
}

LCXVECTOR4::operator FLOAT*()
{
	return(FLOAT*)&x;
}

LCXVECTOR4::operator const FLOAT*() const
{
	return(const FLOAT*)&x;
}


FLOAT& LCXVECTOR4::operator[](int n)
{
	return *((&x)+ n);
}

// assignment operators
LCXVECTOR4& LCXVECTOR4::operator +=(const LCXVECTOR4& v)
{
	x += v.x;	y += v.y;	z += v.z;	w += v.w;
	return *this;
}

LCXVECTOR4& LCXVECTOR4::operator -=(const LCXVECTOR4& v)
{
	x -= v.x;	y -= v.y;	z -= v.z;	w -= v.w;
	return *this;
}

LCXVECTOR4& LCXVECTOR4::operator *=(FLOAT v)
{
	x *= v;	y *= v;	z *= v;	w *= v;
	return *this;
}

LCXVECTOR4& LCXVECTOR4::operator /=(FLOAT v)
{
	v = 1.f/v;
	x *= v;	y *= v;	z *= v;	w *= v;
	return *this;
}


// unary operators
LCXVECTOR4 LCXVECTOR4::operator +() const
{
	return *this;
}

LCXVECTOR4 LCXVECTOR4::operator -() const
{
	return LCXVECTOR4(-x, -y, -z, -w);
}

// binary operators
LCXVECTOR4 LCXVECTOR4::operator +(const LCXVECTOR4& v) const	{	return LCXVECTOR4(x + v.x, y + v.y, z + v.z, w + v.w);	}
LCXVECTOR4 LCXVECTOR4::operator -(const LCXVECTOR4& v) const	{	return LCXVECTOR4(x - v.x, y - v.y, z - v.z, w - v.w);	}
LCXVECTOR4 LCXVECTOR4::operator *(FLOAT v) const				{	return LCXVECTOR4(x * v, y * v, z * v, w * v);			}
LCXVECTOR4 LCXVECTOR4::operator /(FLOAT v) const	{ v = 1.f/v;	return LCXVECTOR4(x * v, y * v, z * v, w * v);			}

LCXVECTOR4 operator *(FLOAT f, const LCXVECTOR4& v){			return LCXVECTOR4(f * v.x, f * v.y, f * v.z, f * v.w);	}
LCXVECTOR4 operator /(FLOAT f, const LCXVECTOR4& v){f=1.f/f;	return LCXVECTOR4(f * v.x, f * v.y, f * v.z, f * v.w);	}

BOOL LCXVECTOR4::operator ==(const LCXVECTOR4& v) const	{	return x == v.x && y == v.y && z == v.z && w == v.w;	}
BOOL LCXVECTOR4::operator !=(const LCXVECTOR4& v) const	{	return x != v.x || y != v.y || z != v.z || w != v.w;	}

// Dot Product
FLOAT LCXVECTOR4::operator *(const LCXVECTOR4& v)
{
	return x * v.x + y * v.y + z * v.z + w * v.w;
}


// Dot Product
FLOAT operator *(const LCXVECTOR4& v1, const LCXVECTOR4& v2)
{
	return v1.x * v2.x + v1.y * v2.y + v1.z * v2.z + v1.w * v2.w;
}




// Transform: vector * Matrix
LCXVECTOR4 LCXVECTOR4::operator *(const FLOAT* v)
{
	FLOAT X = x * v[0] + y * v[4] + z * v[ 8] + w * v[12];
	FLOAT Y = x * v[1] + y * v[5] + z * v[ 9] + w * v[13];
	FLOAT Z = x * v[2] + y * v[6] + z * v[10] + w * v[14];
	FLOAT W = x * v[3] + y * v[7] + z * v[11] + w * v[15];

	return LCXVECTOR4(X, Y, Z, W);
}

// Transform: Matrix * vector;
LCXVECTOR4 operator *(const FLOAT* v1, const LCXVECTOR4& v2)
{
	FLOAT X = v2.x * v1[ 0] + v2.y * v1[ 1] + v2.z * v1[ 2] +  v2.w * v1[ 3];
	FLOAT Y = v2.x * v1[ 4] + v2.y * v1[ 5] + v2.z * v1[ 6] +  v2.w * v1[ 7];
	FLOAT Z = v2.x * v1[ 8] + v2.y * v1[ 9] + v2.z * v1[10] +  v2.w * v1[11];
	FLOAT W = v2.x * v1[12] + v2.y * v1[13] + v2.z * v1[14] +  v2.w * v1[15];

	return LCXVECTOR4(X, Y, Z, W);
}


// Length
FLOAT LCXVECTOR4::Length()
{
	return sqrtf(x*x + y*y + z*z + w*w);
}

// Length Square
FLOAT LCXVECTOR4::LengthSq()
{
	return(x*x + y*y + z*z + w*w);
}


LCXVECTOR4 LCXVECTOR4::Normalize()
{
	FLOAT l  = this->Length();
	if(l == 0)
		return *this;

	l = 1.f/l;
	x *= l;	y *= l;	z *= l;	w *= l;

	return *this;
}


LCXVECTOR4 LCXVECTOR4::Normalize(const LCXVECTOR4* v)
{
	FLOAT l  = 0;

	*this = v;
	l  = this->Length();

	if(l == 0)
		return *this;

	l = 1.f/l;
	x *= l;	y *= l;	z *= l;	w *= l;

	return *this;
}


FLOAT LCXVECTOR4::Dot(const LCXVECTOR4* v)
{
	return (this->x * v->x +
			this->y * v->y +
			this->z * v->z +
			this->w * v->w		);
}


////////////////////////////////////////////////////////////////////////////////

LCXMATRIX::LCXMATRIX()
{
	_11 = 1;  _12 = 0;  _13 = 0;  _14 = 0;
	_21 = 0;  _22 = 1;  _23 = 0;  _24 = 0;
	_31 = 0;  _32 = 0;  _33 = 1;  _34 = 0;
	_41 = 0;  _42 = 0;  _43 = 0;  _44 = 1;
}

LCXMATRIX::LCXMATRIX(const FLOAT* v)
{
	if(!v)
		return;

	_11 = v[ 0]; _12 = v[ 1]; _13 = v[ 2]; _14 = v[ 3];
	_21 = v[ 4]; _22 = v[ 5]; _23 = v[ 6]; _24 = v[ 7];
	_31 = v[ 8]; _32 = v[ 9]; _33 = v[10]; _34 = v[11];
	_41 = v[12]; _42 = v[13]; _43 = v[14]; _44 = v[15];
}

LCXMATRIX::LCXMATRIX(const LCXMATRIX& v)
{
	_11 = v._11; _12 = v._12; _13 = v._13; _14 = v._14;
	_21 = v._21; _22 = v._22; _23 = v._23; _24 = v._24;
	_31 = v._31; _32 = v._32; _33 = v._33; _34 = v._34;
	_41 = v._41; _42 = v._42; _43 = v._43; _44 = v._44;
}

LCXMATRIX::LCXMATRIX(	FLOAT v11, FLOAT v12, FLOAT v13, FLOAT v14,
					 FLOAT v21, FLOAT v22, FLOAT v23, FLOAT v24,
					 FLOAT v31, FLOAT v32, FLOAT v33, FLOAT v34,
					 FLOAT v41, FLOAT v42, FLOAT v43, FLOAT v44 )
{
	_11 = v11; _12 = v12; _13 = v13; _14 = v14;
	_21 = v21; _22 = v22; _23 = v23; _24 = v24;
	_31 = v31; _32 = v32; _33 = v33; _34 = v34;
	_41 = v41; _42 = v42; _43 = v43; _44 = v44;
}


// access grants
FLOAT& LCXMATRIX::operator()(int iRow, int iCol )
{
	return m[iRow][iCol];
}

FLOAT LCXMATRIX::operator()(int iRow, int iCol ) const
{
	return m[iRow][iCol];
}

// casting operators
LCXMATRIX::operator FLOAT*()
{
	return(FLOAT*)&_11;
}

LCXMATRIX::operator const FLOAT*() const
{
	return(FLOAT*)&_11;
}

// assignment operators
LCXMATRIX& LCXMATRIX::operator *=(const LCXMATRIX& v)
{
	LCXMATRIX t = *this;
	_11 = t._11 * v._11 +  t._12 * v._21 +  t._13 * v._31 +  t._14 * v._41;
	_12 = t._11 * v._12 +  t._12 * v._22 +  t._13 * v._32 +  t._14 * v._42;
	_13 = t._11 * v._13 +  t._12 * v._23 +  t._13 * v._33 +  t._14 * v._43;
	_14 = t._11 * v._14 +  t._12 * v._24 +  t._13 * v._34 +  t._14 * v._44;

	_21 = t._21 * v._11 +  t._22 * v._21 +  t._23 * v._31 +  t._24 * v._41;
	_22 = t._21 * v._12 +  t._22 * v._22 +  t._23 * v._32 +  t._24 * v._42;
	_23 = t._21 * v._13 +  t._22 * v._23 +  t._23 * v._33 +  t._24 * v._43;
	_24 = t._21 * v._14 +  t._22 * v._24 +  t._23 * v._34 +  t._24 * v._44;

	_31 = t._31 * v._11 +  t._32 * v._21 +  t._33 * v._31 +  t._34 * v._41;
	_32 = t._31 * v._12 +  t._32 * v._22 +  t._33 * v._32 +  t._34 * v._42;
	_33 = t._31 * v._13 +  t._32 * v._23 +  t._33 * v._33 +  t._34 * v._43;
	_34 = t._31 * v._14 +  t._32 * v._24 +  t._33 * v._34 +  t._34 * v._44;

	_41 = t._41 * v._11 +  t._42 * v._21 +  t._43 * v._31 +  t._44 * v._41;
	_42 = t._41 * v._12 +  t._42 * v._22 +  t._43 * v._32 +  t._44 * v._42;
	_43 = t._41 * v._13 +  t._42 * v._23 +  t._43 * v._33 +  t._44 * v._43;
	_44 = t._41 * v._14 +  t._42 * v._24 +  t._43 * v._34 +  t._44 * v._44;

	return * this;
}


LCXMATRIX& LCXMATRIX::operator +=(const LCXMATRIX& v)
{
	_11 += v._11;	_12 += v._12;	_13 += v._13;	_14 += v._14;
	_21 += v._21;	_22 += v._22;	_23 += v._23;	_24 += v._24;
	_31 += v._31;	_32 += v._32;	_33 += v._33;	_34 += v._34;
	_41 += v._41;	_42 += v._42;	_43 += v._43;	_44 += v._44;

	return * this;
}

LCXMATRIX& LCXMATRIX::operator -=(const LCXMATRIX& v)
{
	_11 -= v._11;	_12 -= v._12;	_13 -= v._13;	_14 -= v._14;
	_21 -= v._21;	_22 -= v._22;	_23 -= v._23;	_24 -= v._24;
	_31 -= v._31;	_32 -= v._32;	_33 -= v._33;	_34 -= v._34;
	_41 -= v._41;	_42 -= v._42;	_43 -= v._43;	_44 -= v._44;

	return * this;
}

LCXMATRIX& LCXMATRIX::operator *=(FLOAT v)
{
	_11 *= v;	_12 *= v;	_13 *= v;	_14 *= v;
	_21 *= v;	_22 *= v;	_23 *= v;	_24 *= v;
	_31 *= v;	_32 *= v;	_33 *= v;	_34 *= v;
	_41 *= v;	_42 *= v;	_43 *= v;	_44 *= v;

	return * this;
}

LCXMATRIX& LCXMATRIX::operator /=(FLOAT v)
{
	v = 1.f/v;
	_11 *= v;	_12 *= v;	_13 *= v;	_14 *= v;
	_21 *= v;	_22 *= v;	_23 *= v;	_24 *= v;
	_31 *= v;	_32 *= v;	_33 *= v;	_34 *= v;
	_41 *= v;	_42 *= v;	_43 *= v;	_44 *= v;

	return * this;
}


// unary operators
LCXMATRIX LCXMATRIX::operator +() const
{
	return *this;
}

LCXMATRIX LCXMATRIX::operator -() const
{
	return LCXMATRIX(
		-_11, -_12, -_13, -_14,
		-_21, -_22, -_23, -_24,
		-_31, -_32, -_33, -_34,
		-_41, -_42, -_43, -_44);
}

// binary operators
LCXMATRIX LCXMATRIX::operator *(const LCXMATRIX& v) const
{
	LCXMATRIX r;
	r._11 = this->_11 * v._11 +  this->_12 * v._21 +  this->_13 * v._31 +  this->_14 * v._41;
	r._12 = this->_11 * v._12 +  this->_12 * v._22 +  this->_13 * v._32 +  this->_14 * v._42;
	r._13 = this->_11 * v._13 +  this->_12 * v._23 +  this->_13 * v._33 +  this->_14 * v._43;
	r._14 = this->_11 * v._14 +  this->_12 * v._24 +  this->_13 * v._34 +  this->_14 * v._44;

	r._21 = this->_21 * v._11 +  this->_22 * v._21 +  this->_23 * v._31 +  this->_24 * v._41;
	r._22 = this->_21 * v._12 +  this->_22 * v._22 +  this->_23 * v._32 +  this->_24 * v._42;
	r._23 = this->_21 * v._13 +  this->_22 * v._23 +  this->_23 * v._33 +  this->_24 * v._43;
	r._24 = this->_21 * v._14 +  this->_22 * v._24 +  this->_23 * v._34 +  this->_24 * v._44;

	r._31 = this->_31 * v._11 +  this->_32 * v._21 +  this->_33 * v._31 +  this->_34 * v._41;
	r._32 = this->_31 * v._12 +  this->_32 * v._22 +  this->_33 * v._32 +  this->_34 * v._42;
	r._33 = this->_31 * v._13 +  this->_32 * v._23 +  this->_33 * v._33 +  this->_34 * v._43;
	r._34 = this->_31 * v._14 +  this->_32 * v._24 +  this->_33 * v._34 +  this->_34 * v._44;

	r._41 = this->_41 * v._11 +  this->_42 * v._21 +  this->_43 * v._31 +  this->_44 * v._41;
	r._42 = this->_41 * v._12 +  this->_42 * v._22 +  this->_43 * v._32 +  this->_44 * v._42;
	r._43 = this->_41 * v._13 +  this->_42 * v._23 +  this->_43 * v._33 +  this->_44 * v._43;
	r._44 = this->_41 * v._14 +  this->_42 * v._24 +  this->_43 * v._34 +  this->_44 * v._44;

	return r;
}


LCXMATRIX LCXMATRIX::operator +(const LCXMATRIX& v) const
{
	return LCXMATRIX(	_11 + v._11, _12 + v._12, _13 + v._13, _14 + v._14,
						_21 + v._21, _22 + v._22, _23 + v._23, _24 + v._24,
						_31 + v._31, _32 + v._32, _33 + v._33, _34 + v._34,
						_41 + v._41, _42 + v._42, _43 + v._43, _44 + v._44);
}

LCXMATRIX LCXMATRIX::operator -(const LCXMATRIX& v) const
{
	return LCXMATRIX(	_11 - v._11, _12 - v._12, _13 - v._13, _14 - v._14,
						_21 - v._21, _22 - v._22, _23 - v._23, _24 - v._24,
						_31 - v._31, _32 - v._32, _33 - v._33, _34 - v._34,
						_41 - v._41, _42 - v._42, _43 - v._43, _44 - v._44);
}

LCXMATRIX LCXMATRIX::operator *(FLOAT v) const
{
	return LCXMATRIX(	_11 * v, _12 * v, _13 * v, _14 * v,
						_21 * v, _22 * v, _23 * v, _24 * v,
						_31 * v, _32 * v, _33 * v, _34 * v,
						_41 * v, _42 * v, _43 * v, _44 * v);
}

LCXMATRIX LCXMATRIX::operator /(FLOAT v) const
{
	v = 1.f / v;
	return LCXMATRIX(	_11 * v, _12 * v, _13 * v, _14 * v,
						_21 * v, _22 * v, _23 * v, _24 * v,
						_31 * v, _32 * v, _33 * v, _34 * v,
						_41 * v, _42 * v, _43 * v, _44 * v);
}


LCXMATRIX operator *(FLOAT f, const LCXMATRIX& v)
{
	return LCXMATRIX(	f * v._11, f * v._12, f * v._13, f * v._14,
						f * v._21, f * v._22, f * v._23, f * v._24,
						f * v._31, f * v._32, f * v._33, f * v._34,
						f * v._41, f * v._42, f * v._43, f * v._44);
}

LCXMATRIX operator *(const LCXMATRIX& v, FLOAT f)
{
	return LCXMATRIX(	f * v._11, f * v._12, f * v._13, f * v._14,
						f * v._21, f * v._22, f * v._23, f * v._24,
						f * v._31, f * v._32, f * v._33, f * v._34,
						f * v._41, f * v._42, f * v._43, f * v._44);
}


BOOL LCXMATRIX::operator ==(const LCXMATRIX& v) const
{
	return	(
		_11 == v._11 && _12 == v._12 && _13 == v._13 && _14 == v._14 &&
		_21 == v._21 && _22 == v._22 && _23 == v._23 && _24 == v._24 &&
		_31 == v._31 && _32 == v._32 && _33 == v._33 && _34 == v._34 &&
		_41 == v._41 && _42 == v._42 && _43 == v._43 && _44 == v._44
		);
}

BOOL LCXMATRIX::operator !=(const LCXMATRIX& v) const
{
	return	(
		_11 != v._11 || _12 != v._12 || _13 != v._13 || _14 != v._14 ||
		_21 != v._21 || _22 != v._22 || _23 != v._23 || _24 != v._24 ||
		_31 != v._31 || _32 != v._32 || _33 != v._33 || _34 != v._34 ||
		_41 != v._41 || _42 != v._42 || _43 != v._43 || _44 != v._44
		);
}


LCXMATRIX LCXMATRIX::Multiple(const LCXMATRIX* v) const
{
	LCXMATRIX r;
	r._11 = this->_11 * v->_11 +  this->_12 * v->_21 +  this->_13 * v->_31 +  this->_14 * v->_41;
	r._12 = this->_11 * v->_12 +  this->_12 * v->_22 +  this->_13 * v->_32 +  this->_14 * v->_42;
	r._13 = this->_11 * v->_13 +  this->_12 * v->_23 +  this->_13 * v->_33 +  this->_14 * v->_43;
	r._14 = this->_11 * v->_14 +  this->_12 * v->_24 +  this->_13 * v->_34 +  this->_14 * v->_44;

	r._21 = this->_21 * v->_11 +  this->_22 * v->_21 +  this->_23 * v->_31 +  this->_24 * v->_41;
	r._22 = this->_21 * v->_12 +  this->_22 * v->_22 +  this->_23 * v->_32 +  this->_24 * v->_42;
	r._23 = this->_21 * v->_13 +  this->_22 * v->_23 +  this->_23 * v->_33 +  this->_24 * v->_43;
	r._24 = this->_21 * v->_14 +  this->_22 * v->_24 +  this->_23 * v->_34 +  this->_24 * v->_44;

	r._31 = this->_31 * v->_11 +  this->_32 * v->_21 +  this->_33 * v->_31 +  this->_34 * v->_41;
	r._32 = this->_31 * v->_12 +  this->_32 * v->_22 +  this->_33 * v->_32 +  this->_34 * v->_42;
	r._33 = this->_31 * v->_13 +  this->_32 * v->_23 +  this->_33 * v->_33 +  this->_34 * v->_43;
	r._34 = this->_31 * v->_14 +  this->_32 * v->_24 +  this->_33 * v->_34 +  this->_34 * v->_44;

	r._41 = this->_41 * v->_11 +  this->_42 * v->_21 +  this->_43 * v->_31 +  this->_44 * v->_41;
	r._42 = this->_41 * v->_12 +  this->_42 * v->_22 +  this->_43 * v->_32 +  this->_44 * v->_42;
	r._43 = this->_41 * v->_13 +  this->_42 * v->_23 +  this->_43 * v->_33 +  this->_44 * v->_43;
	r._44 = this->_41 * v->_14 +  this->_42 * v->_24 +  this->_43 * v->_34 +  this->_44 * v->_44;

	return r;
}



// Length
LCXMATRIX& LCXMATRIX::Identity()
{
	_11=1; _12=0; _13=0; _14=0;
	_21=0; _22=1; _23=0; _24=0;
	_31=0; _32=0; _33=1; _34=0;
	_41=0; _42=0; _43=0; _44=1;
	return *this;
}


LCXMATRIX& LCXMATRIX::Transpose()
{
	FLOAT t;

	t   = _12;	_12 = _21;	_21 = t;
	t   = _13;	_13 = _31;	_31 = t;
	t   = _14;	_14 = _41;	_41 = t;

	t   = _23;	_23 = _32;	_32 = t;
	t   = _24;	_24 = _42;	_42 = t;

	t   = _34;	_34 = _43;	_43 = t;

	return *this;
}


LCXMATRIX& LCXMATRIX::Transpose(const LCXMATRIX* v)
{
	FLOAT t =0;
	*this = *v;

	t   = _12;	_12 = _21;	_21 = t;
	t   = _13;	_13 = _31;	_31 = t;
	t   = _14;	_14 = _41;	_41 = t;

	t   = _23;	_23 = _32;	_32 = t;
	t   = _24;	_24 = _42;	_42 = t;

	t   = _34;	_34 = _43;	_43 = t;

	return *this;
}


LCXMATRIX& LCXMATRIX::Inverse(INT nQuick)
{
	LCXMATRIX	t = *this;
	this->Inverse(&t, nQuick);
	return *this;
}


LCXMATRIX& LCXMATRIX::Inverse(const LCXMATRIX* pIn, INT nQuick)
{
	if(TRUE == nQuick)
	{
		FLOAT fDet = 1;

		// 4X4 ����� Determinant�� 1�� ���Ѵ�.
		fDet =	pIn->_11 * ( pIn->_22 * pIn->_33 - pIn->_23 * pIn->_32 ) +
				pIn->_12 * ( pIn->_23 * pIn->_31 - pIn->_21 * pIn->_33 ) +
				pIn->_13 * ( pIn->_21 * pIn->_32 - pIn->_22 * pIn->_31 );

		fDet = 1.f / fDet;

		this->_11 =  fDet * ( pIn->_22 * pIn->_33 - pIn->_23 * pIn->_32 );
		this->_12 = -fDet * ( pIn->_12 * pIn->_33 - pIn->_13 * pIn->_32 );
		this->_13 =  fDet * ( pIn->_12 * pIn->_23 - pIn->_13 * pIn->_22 );
		this->_14 = 0.0f;

		this->_21 = -fDet * ( pIn->_21 * pIn->_33 - pIn->_23 * pIn->_31 );
		this->_22 =  fDet * ( pIn->_11 * pIn->_33 - pIn->_13 * pIn->_31 );
		this->_23 = -fDet * ( pIn->_11 * pIn->_23 - pIn->_13 * pIn->_21 );
		this->_24 = 0.0f;

		this->_31 =  fDet * ( pIn->_21 * pIn->_32 - pIn->_22 * pIn->_31 );
		this->_32 = -fDet * ( pIn->_11 * pIn->_32 - pIn->_12 * pIn->_31 );
		this->_33 =  fDet * ( pIn->_11 * pIn->_22 - pIn->_12 * pIn->_21 );
		this->_34 = 0.0f;

		this->_41 = -( pIn->_41 * this->_11 + pIn->_42 * this->_21 + pIn->_43 * this->_31 );
		this->_42 = -( pIn->_41 * this->_12 + pIn->_42 * this->_22 + pIn->_43 * this->_32 );
		this->_43 = -( pIn->_41 * this->_13 + pIn->_42 * this->_23 + pIn->_43 * this->_33 );
		this->_44 = 1.0f;

		return *this;
	}

	// this code came from Intel.

	float*	v = (float*)pIn;
	float*	p = &m[0][0];

	float tmp[12]; /* temp array for pairs */
	float src[16]; /* array of transpose source matrix */
	float det; /* determinant */
	/* transpose matrix */
	for (int i = 0; i < 4; i++)
	{
		src[i] = v[i*4];
		src[i + 4] = v[i*4 + 1];
		src[i + 8] = v[i*4 + 2];
		src[i +12] = v[i*4 + 3];
	}
	/* calculate pairs for first 8 elements (cofactors) */
	tmp[ 0] = src[10] * src[15];
	tmp[ 1] = src[11] * src[14];
	tmp[ 2] = src[ 9] * src[15];
	tmp[ 3] = src[11] * src[13];
	tmp[ 4] = src[ 9] * src[14];
	tmp[ 5] = src[10] * src[13];
	tmp[ 6] = src[ 8] * src[15];
	tmp[ 7] = src[11] * src[12];
	tmp[ 8] = src[ 8] * src[14];
	tmp[ 9] = src[10] * src[12];
	tmp[10] = src[ 8] * src[13];
	tmp[11] = src[ 9] * src[12];
	/* calculate first 8 elements (cofactors) */
	p[0]  = tmp[0]*src[5] + tmp[3]*src[6] + tmp[ 4]*src[7];
	p[0] -= tmp[1]*src[5] + tmp[2]*src[6] + tmp[ 5]*src[7];
	p[1]  = tmp[1]*src[4] + tmp[6]*src[6] + tmp[ 9]*src[7];
	p[1] -= tmp[0]*src[4] + tmp[7]*src[6] + tmp[ 8]*src[7];
	p[2]  = tmp[2]*src[4] + tmp[7]*src[5] + tmp[10]*src[7];
	p[2] -= tmp[3]*src[4] + tmp[6]*src[5] + tmp[11]*src[7];
	p[3]  = tmp[5]*src[4] + tmp[8]*src[5] + tmp[11]*src[6];
	p[3] -= tmp[4]*src[4] + tmp[9]*src[5] + tmp[10]*src[6];
	p[4]  = tmp[1]*src[1] + tmp[2]*src[2] + tmp[ 5]*src[3];
	p[4] -= tmp[0]*src[1] + tmp[3]*src[2] + tmp[ 4]*src[3];
	p[5]  = tmp[0]*src[0] + tmp[7]*src[2] + tmp[ 8]*src[3];
	p[5] -= tmp[1]*src[0] + tmp[6]*src[2] + tmp[ 9]*src[3];
	p[6]  = tmp[3]*src[0] + tmp[6]*src[1] + tmp[11]*src[3];
	p[6] -= tmp[2]*src[0] + tmp[7]*src[1] + tmp[10]*src[3];
	p[7]  = tmp[4]*src[0] + tmp[9]*src[1] + tmp[10]*src[2];
	p[7] -= tmp[5]*src[0] + tmp[8]*src[1] + tmp[11]*src[2];


	/* calculate pairs for second 8 elements (cofactors) */
	tmp[ 0] = src[2]*src[7];
	tmp[ 1] = src[3]*src[6];
	tmp[ 2] = src[1]*src[7];
	tmp[ 3] = src[3]*src[5];
	tmp[ 4] = src[1]*src[6];
	tmp[ 5] = src[2]*src[5];
	tmp[ 6] = src[0]*src[7];
	tmp[ 7] = src[3]*src[4];
	tmp[ 8] = src[0]*src[6];
	tmp[ 9] = src[2]*src[4];
	tmp[10] = src[0]*src[5];
	tmp[11] = src[1]*src[4];
	/* calculate second 8 elements (cofactors) */
	p[ 8] = tmp[ 0]*src[13] + tmp[ 3]*src[14] + tmp[ 4]*src[15];
	p[ 8]-= tmp[ 1]*src[13] + tmp[ 2]*src[14] + tmp[ 5]*src[15];
	p[ 9] = tmp[ 1]*src[12] + tmp[ 6]*src[14] + tmp[ 9]*src[15];
	p[ 9]-= tmp[ 0]*src[12] + tmp[ 7]*src[14] + tmp[ 8]*src[15];
	p[10] = tmp[ 2]*src[12] + tmp[ 7]*src[13] + tmp[10]*src[15];
	p[10]-= tmp[ 3]*src[12] + tmp[ 6]*src[13] + tmp[11]*src[15];
	p[11] = tmp[ 5]*src[12] + tmp[ 8]*src[13] + tmp[11]*src[14];
	p[11]-= tmp[ 4]*src[12] + tmp[ 9]*src[13] + tmp[10]*src[14];
	p[12] = tmp[ 2]*src[10] + tmp[ 5]*src[11] + tmp[ 1]*src[ 9];
	p[12]-= tmp[ 4]*src[11] + tmp[ 0]*src[ 9] + tmp[ 3]*src[10];
	p[13] = tmp[ 8]*src[11] + tmp[ 0]*src[ 8] + tmp[ 7]*src[10];
	p[13]-= tmp[ 6]*src[10] + tmp[ 9]*src[11] + tmp[ 1]*src[ 8];
	p[14] = tmp[ 6]*src[ 9] + tmp[11]*src[11] + tmp[ 3]*src[ 8];
	p[14]-= tmp[10]*src[11] + tmp[ 2]*src[ 8] + tmp[ 7]*src[ 9];
	p[15] = tmp[10]*src[10] + tmp[ 4]*src[ 8] + tmp[ 9]*src[ 9];
	p[15]-= tmp[ 8]*src[ 9] + tmp[11]*src[10] + tmp[ 5]*src[ 8];
	/* calculate determinant */
	det=src[0]*p[0]+src[1]*p[1]+src[2]*p[2]+src[3]*p[3];
	/* calculate matrix inverse */
	det = 1/det;
	for (int j = 0; j < 16; j++)
		p[j] *= det;


	return *this;
}


FLOAT LCXMATRIX::Determinant()
{
	FLOAT t =0;

	t += (_24 * _11 - _14 * _21) * (_32 * _43 - _33 * _42);
	t += (_24 * _12 - _14 * _22) * (_33 * _41 - _31 * _43);
	t += (_24 * _13 - _14 * _23) * (_31 * _42 - _32 * _41);

	t += (_44 * _31 - _34 * _41) * (_12 * _23 - _13 * _22);
	t += (_44 * _32 - _34 * _42) * (_13 * _21 - _11 * _23);
	t += (_44 * _33 - _34 * _43) * (_11 * _22 - _12 * _21);

	return t;
}


LCXMATRIX& LCXMATRIX::SetupScaling(FLOAT X, FLOAT Y, FLOAT Z)
{
	this->Identity();
	_11 = X;    _22 = Y;    _33 = Z;
	return *this;
}




LCXMATRIX& LCXMATRIX::SetupViewLH(const LCXVECTOR3* pEye, const LCXVECTOR3* pLook, const LCXVECTOR3* pUp)
{
	LCXVECTOR3 vcX;
	LCXVECTOR3 vcY;
	LCXVECTOR3 vcZ;

	vcZ = *pLook - *pEye;
	vcZ.Normalize();

	vcX	= *pUp ^ vcZ;
	vcX.Normalize();

	vcY = vcZ ^ vcX;

	this->Identity();

	_11 = vcX.x;    _12 = vcY.x;    _13 = vcZ.x;
	_21 = vcX.y;    _22 = vcY.y;    _23 = vcZ.y;
	_31 = vcX.z;    _32 = vcY.z;    _33 = vcZ.z;

	_41 = - *pEye * vcX;
	_42 = - *pEye * vcY;
	_43 = - *pEye * vcZ;

	return *this;
}



LCXMATRIX& LCXMATRIX::SetupViewRH(const LCXVECTOR3* pEye, const LCXVECTOR3* pLook, const LCXVECTOR3* pUp)
{
	LCXVECTOR3 vcX;
	LCXVECTOR3 vcY;
	LCXVECTOR3 vcZ;

	vcZ = *pEye - *pLook;
	vcZ.Normalize();

	vcX	= *pUp ^ vcZ;
	vcX.Normalize();

	vcY = vcZ ^ vcX;

	this->Identity();

	_11 = vcX.x;    _12 = vcY.x;    _13 = vcZ.x;
	_21 = vcX.y;    _22 = vcY.y;    _23 = vcZ.y;
	_31 = vcX.z;    _32 = vcY.z;    _33 = vcZ.z;

	_41 = - *pEye * vcX;
	_42 = - *pEye * vcY;
	_43 = - *pEye * vcZ;

	return *this;
}


LCXMATRIX& LCXMATRIX::SetupPerspectiveLH(FLOAT fFov, FLOAT fAsp, FLOAT fNear, FLOAT fFar)
{
	fFov	*=0.5f;
	FLOAT cot = (FLOAT)cos(fFov)/(FLOAT)sin(fFov);

	FLOAT h = cot;
	FLOAT w = cot/fAsp;

	this->Identity();

	_11 = w;
	_22 = h;
	_34 = 1.f;
	_44 = 0.f;

	_33 =  fFar / ( fFar - fNear );
	_43 = -fNear * fFar / ( fFar - fNear );

	return *this;
}


LCXMATRIX& LCXMATRIX::SetupPerspectiveRH(FLOAT fFov, FLOAT fAsp, FLOAT fNear, FLOAT fFar)
{
	FLOAT cot = cosf(fFov/2)/sinf(fFov/2);

	FLOAT h = cot;
	FLOAT w = cot/fAsp;

	this->Identity();

	_11 = w;
	_22 = h;
	_34 = -1.f;
	_44 = 0.f;

	_33 = fFar / ( fNear - fFar );
	_43 = fNear * fFar / ( fNear - fFar );

	return *this;
}


LCXMATRIX& LCXMATRIX::SetupPerspectiveGL(FLOAT fFov, FLOAT fAsp, FLOAT fNear, FLOAT fFar)
{
	FLOAT cot = cosf(fFov/2)/sinf(fFov/2);

	FLOAT h = cot;
	FLOAT w = cot/fAsp;

	this->Identity();

	_11 = w;
	_22 = h;
	_34 = -1.f;
	_44 = 0.f;

	_33 = ( fNear + fFar ) / ( fNear - fFar );
	_43 = 2 * fNear * fFar / ( fNear - fFar );

	return *this;
}


LCXMATRIX& LCXMATRIX::SetupRotationX(FLOAT fRad)
{
	this->Identity();
	_22 =  (FLOAT)cos( fRad );
	_23 =  (FLOAT)sin( fRad );
	_32 = -_23;
	_33 =  _22;
	return *this;
}


LCXMATRIX& LCXMATRIX::SetupRotationY(FLOAT fRads)
{
	this->Identity();
	_11 =  (FLOAT)cos( fRads );
	_31 =  (FLOAT)sin( fRads );
	_13 = -_31;
	_33 =  _11;

	return *this;
}


LCXMATRIX& LCXMATRIX::SetupRotationZ(FLOAT fRads)
{
	this->Identity();
	_11  =  (FLOAT)cos( fRads );
	_12  =  (FLOAT)sin( fRads );
	_21  = -_12;
	_22  =  _11;

	return *this;
}


LCXMATRIX& LCXMATRIX::SetupRotationAxis(const LCXVECTOR3* vAxis, FLOAT fRad)
{
	FLOAT     fCos = (FLOAT)cos( fRad );
	FLOAT     fSin = (FLOAT)sin( fRad );
	LCXVECTOR3 v    = *vAxis;

	v.Normalize();

	this->Identity();

	_11 = ( v.x * v.x ) * ( 1 - fCos ) + fCos;
	_12 = ( v.x * v.y ) * ( 1 - fCos ) - (v.z * fSin);
	_13 = ( v.x * v.z ) * ( 1 - fCos ) + (v.y * fSin);

	_21 = ( v.y * v.x ) * ( 1 - fCos ) + (v.z * fSin);
	_22 = ( v.y * v.y ) * ( 1 - fCos ) + fCos ;
	_23 = ( v.y * v.z ) * ( 1 - fCos ) - (v.x * fSin);

	_31 = ( v.z * v.x ) * ( 1 - fCos ) - (v.y * fSin);
	_32 = ( v.z * v.y ) * ( 1 - fCos ) + (v.x * fSin);
	_33 = ( v.z * v.z ) * ( 1 - fCos ) + fCos;

	return *this;
}


LCXMATRIX& LCXMATRIX::SetupTranslation(const LCXVECTOR3* vTrs, BOOL bInit)
{
	if(bInit)
		this->Identity();

	_41 = vTrs->x;
	_42 = vTrs->y;
	_43 = vTrs->z;

	return *this;
}


void LCXMATRIX::TransformCoord(LCXVECTOR3* pOut, const LCXVECTOR3* pIn)
{
	FLOAT	_x, _y, _z;
	FLOAT	x, y, z, w;

	_x = pIn->x;
	_y = pIn->y;
	_z = pIn->z;

	x = _11 * _x +  _21 * _y + _31 * _z   +  _41;
	y = _12 * _x +  _22 * _y + _32 * _z   +  _42;
	z = _13 * _x +  _23 * _y + _33 * _z   +  _43;
	w = _14 * _x +  _24 * _y + _34 * _z   +  _44;

	x /=w;
	y /=w;
	z /=w;
	w =1;

	pOut->x =x;
	pOut->y =y;
	pOut->z =z;

}



////////////////////////////////////////////////////////////////////////////////
// Quaternion

LCXQUATERNION::LCXQUATERNION()
{
	x = 0;	y= 0; z = 0; w = 1;
}


LCXQUATERNION::LCXQUATERNION(const FLOAT* pf )
{
	x = pf[0];	y = pf[1];	z = pf[2];	w = pf[3];
}


LCXQUATERNION::LCXQUATERNION(const LCXQUATERNION& v)
{
	x = v.x;	y = v.y;	z = v.z;	w = v.w;
}


LCXQUATERNION::LCXQUATERNION( FLOAT fx, FLOAT fy, FLOAT fz, FLOAT fw )
{
	x = fx;	y = fy;	z = fz;	w = fw;
}


// casting
LCXQUATERNION::operator FLOAT* ()
{
	return (FLOAT *) &x;
}


LCXQUATERNION::operator const FLOAT* () const
{
	return (const FLOAT *) &x;
}


// assignment operators
LCXQUATERNION& LCXQUATERNION::operator += (const LCXQUATERNION& q )
{
	x += q.x;	y += q.y;	z += q.z;	w += q.w;
	return *this;
}

LCXQUATERNION& LCXQUATERNION::operator -= (const LCXQUATERNION& q )
{
	x -= q.x;	y -= q.y;	z -= q.z;	w -= q.w;
	return *this;
}

LCXQUATERNION& LCXQUATERNION::operator *= (const LCXQUATERNION& q )
{
	this->w = this->w * q.w - ( this->x * q.x + this->y * q.y + this->z * q.z);

	this->x = this->w * q.x + q.w * this->x + (this->y * q.z - this->z * q.y);
	this->y = this->w * q.y + q.w * this->y + (this->z * q.x - this->x * q.z);
	this->z = this->w * q.z + q.w * this->z + (this->x * q.y - this->y * q.x);

	return *this;
}

LCXQUATERNION& LCXQUATERNION::operator *= ( FLOAT f )
{
	x *= f;	y *= f;	z *= f;	w *= f;
	return *this;
}

LCXQUATERNION& LCXQUATERNION::operator /= ( FLOAT f )
{
	FLOAT fInv = 1.f / f;
	x *= fInv;	y *= fInv;	z *= fInv;	w *= fInv;
	return *this;
}


// unary operators
LCXQUATERNION LCXQUATERNION::operator + () const
{
	return *this;
}

LCXQUATERNION LCXQUATERNION::operator - () const
{
	return LCXQUATERNION(-x, -y, -z, -w);
}


// binary operators
LCXQUATERNION LCXQUATERNION::operator + (const LCXQUATERNION& q ) const
{
	return LCXQUATERNION(x + q.x, y + q.y, z + q.z, w + q.w);
}

LCXQUATERNION LCXQUATERNION::operator - (const LCXQUATERNION& q ) const
{
	return LCXQUATERNION(x - q.x, y - q.y, z - q.z, w - q.w);
}

LCXQUATERNION LCXQUATERNION::operator * (const LCXQUATERNION& q ) const
{
	LCXQUATERNION qT;

	qT.w = this->w * q.w - ( this->x * q.x + this->y * q.y + this->z * q.z);

	qT.x = this->w * q.x + q.w * this->x + (this->y * q.z - this->z * q.y);
	qT.y = this->w * q.y + q.w * this->y + (this->z * q.x - this->x * q.z);
	qT.z = this->w * q.z + q.w * this->z + (this->x * q.y - this->y * q.x);

	return qT;
}

LCXQUATERNION LCXQUATERNION::operator * ( FLOAT f ) const
{
	return LCXQUATERNION(x * f, y * f, z * f, w * f);
}

LCXQUATERNION LCXQUATERNION::operator / ( FLOAT f ) const
{
	FLOAT fInv = 1.f / f;
	return LCXQUATERNION(x * fInv, y * fInv, z * fInv, w * fInv);
}


LCXQUATERNION operator * (FLOAT f, const LCXQUATERNION& q )
{
	return LCXQUATERNION(f * q.x, f * q.y, f * q.z, f * q.w);
}


BOOL LCXQUATERNION::operator == (const LCXQUATERNION& q ) const
{
	return x == q.x && y == q.y && z == q.z && w == q.w;
}

BOOL LCXQUATERNION::operator != (const LCXQUATERNION& q ) const
{
	return x != q.x || y != q.y || z != q.z || w != q.w;
}


LCXQUATERNION LCXQUATERNION::Multiple(const LCXQUATERNION* q) const
{
	LCXQUATERNION qT;

	qT.w = this->w * q->w - ( this->x * q->x + this->y * q->y + this->z * q->z);

	qT.x = this->w * q->x + q->w * this->x + (this->y * q->z - this->z * q->y);
	qT.y = this->w * q->y + q->w * this->y + (this->z * q->x - this->x * q->z);
	qT.z = this->w * q->z + q->w * this->z + (this->x * q->y - this->y * q->x);

	return qT;
}


void LCXQUATERNION::SLerp(const LCXQUATERNION* q1, const LCXQUATERNION* q2, FLOAT t)
{
	LCXQUATERNION	q;

	//Q = (1/sin��)[  sin (��*(1-t)) * Q1 + sin (��*t) * Q2] 

	FLOAT w1;
	FLOAT w2;
	FLOAT dt = q1->x * q2->x + q1->y * q2->y + q1->z * q2->z + q1->w * q2->w;


	if( dt > 0.99999f || dt<-0.99999f)
	{
		w1 = 1 - t;
		w2 = t;
	}
	else
	{ 
		FLOAT fTheta  = (FLOAT)acos( fabsf(dt) );
		FLOAT fSin    = (FLOAT)sin( fTheta );

		w1 = (FLOAT)sin( (1 - t) * fTheta) / fSin;
		w2 = (FLOAT)sin(      t  * fTheta) / fSin;		
	}

	if( dt < 0 )
		w2 = -w2;

	q = *q1 * w1 + *q2 * w2;

	*this = q;
}


void LCXQUATERNION::RotationMatrix(LCXMATRIX* pOut, BOOL bDX)
{
	FLOAT	xx = x * x;
	FLOAT	yy = y * y;
	FLOAT	zz = z * z;

	FLOAT	xy = x * y;
	FLOAT	yz = y * z;
	FLOAT	xz = z * x;

	FLOAT	xw = x * w;
	FLOAT	yw = y * w;
	FLOAT	zw = z * w;

	pOut->Identity();


	if(bDX)
	{
		// Direct3D
		pOut->_11 = 1 - 2*yy - 2*zz;	pOut->_21 =     2*xy - 2*zw;	pOut->_31 =     2*xz + 2*yw;
		pOut->_12 =     2*xy + 2*zw;	pOut->_22 = 1 - 2*xx - 2*zz;	pOut->_32 =     2*yz - 2*xw;
		pOut->_13 =     2*xz - 2*yw;	pOut->_23 =     2*yz + 2*xw;	pOut->_33 = 1 - 2*xx - 2*yy;
	}
	else
	{
		pOut->_11 = 1 - 2*yy - 2*zz;	pOut->_12 =     2*xy - 2*zw;	pOut->_13 =     2*xz + 2*yw;
		pOut->_21 =     2*xy + 2*zw;	pOut->_22 = 1 - 2*xx - 2*zz;	pOut->_23 =     2*yz - 2*xw;
		pOut->_31 =     2*xz - 2*yw;	pOut->_32 =     2*yz + 2*xw;	pOut->_33 = 1 - 2*xx - 2*yy;
	}
}



////////////////////////////////////////////////////////////////////////////////
// Plane

LCXPLANE::LCXPLANE()
{
	a = 0;	b = 0;	c = 0;	d = 0;
}


LCXPLANE::LCXPLANE(const FLOAT* pf )
{
	a = pf[0];	b = pf[1];	c = pf[2];	d = pf[3];
}


LCXPLANE::LCXPLANE(const LCXPLANE& v )
{
	a = v.a;	b = v.b;	c = v.c;	d = v.d;
}


LCXPLANE::LCXPLANE( FLOAT fa, FLOAT fb, FLOAT fc, FLOAT fd )
{
	a = fa;	b = fb;	c = fc;	d = fd;
}


// casting
LCXPLANE::operator FLOAT* ()
{
	return (FLOAT *) &a;
}


LCXPLANE::operator const FLOAT* () const
{
	return (const FLOAT *) &a;
}


// unary operators
LCXPLANE LCXPLANE::operator + () const
{
	return *this;
}

LCXPLANE LCXPLANE::operator - () const
{
	return LCXPLANE(-a, -b, -c, -d);
}


// binary operators
BOOL LCXPLANE::operator == (const LCXPLANE& p) const
{
	return a == p.a && b == p.b && c == p.c && d == p.d;
}

BOOL LCXPLANE::operator != (const LCXPLANE& p ) const
{
	return a != p.a || b != p.b || c != p.c || d != p.d;
}



void LCXPLANE::SetupFromPointNormal(const LCXVECTOR3* point, const LCXVECTOR3* normal)
{
	this->a  = normal->x;
	this->b  = normal->y;
	this->c  = normal->z;
	this->d  = - *point * *normal;
}


void LCXPLANE::SetupFromPoints(const LCXVECTOR3* p0, const LCXVECTOR3* p1, const LCXVECTOR3* p2)
{
	LCXVECTOR3	n = (*p1 - *p0) ^ (*p2 - *p0);
	n.Normalize();

	this->a  = n.x;
	this->b  = n.y;
	this->c  = n.z;
	this->d  = - *p0 * n;
}



////////////////////////////////////////////////////////////////////////////////
// Color
LCXCOLOR::LCXCOLOR()
{
	r = 1;	g = 1;	b = 1;	a = 1;
}



LCXCOLOR::LCXCOLOR( DWORD dw )
{
	const FLOAT f = 1.f / 255.f;
	r = f * (FLOAT) (unsigned char) (dw >> 16);
	g = f * (FLOAT) (unsigned char) (dw >>  8);
	b = f * (FLOAT) (unsigned char) (dw >>  0);
	a = f * (FLOAT) (unsigned char) (dw >> 24);
}


LCXCOLOR::LCXCOLOR(const FLOAT* pf )
{
	r = pf[0];	g = pf[1];	b = pf[2];	a = pf[3];
}


LCXCOLOR::LCXCOLOR(const LCXCOLOR& v )
{
	r = v.r;	g = v.g;	b = v.b;	a = v.a;
}



LCXCOLOR::LCXCOLOR( FLOAT fr, FLOAT fg, FLOAT fb, FLOAT fa )
{
	r = fr;	g = fg;	b = fb;	a = fa;
}


// casting

LCXCOLOR::operator DWORD () const
{
	DWORD dwR = r >= 1.f ? 0xff : r <= 0.f ? 0x00 : (DWORD) (r * 255.f + 0.5f);
	DWORD dwG = g >= 1.f ? 0xff : g <= 0.f ? 0x00 : (DWORD) (g * 255.f + 0.5f);
	DWORD dwB = b >= 1.f ? 0xff : b <= 0.f ? 0x00 : (DWORD) (b * 255.f + 0.5f);
	DWORD dwA = a >= 1.f ? 0xff : a <= 0.f ? 0x00 : (DWORD) (a * 255.f + 0.5f);

	return (dwA << 24) | (dwR << 16) | (dwG << 8) | dwB;
}



LCXCOLOR::operator FLOAT * ()
{
	return (FLOAT *) &r;
}


LCXCOLOR::operator const FLOAT * () const
{
	return (const FLOAT *) &r;
}


// assignment operators
LCXCOLOR& LCXCOLOR::operator += (const LCXCOLOR& c )
{
	r += c.r;	g += c.g;	b += c.b;	a += c.a;
	return *this;
}

LCXCOLOR& LCXCOLOR::operator -= (const LCXCOLOR& c )
{
	r -= c.r;	g -= c.g;	b -= c.b;	a -= c.a;
	return *this;
}

LCXCOLOR& LCXCOLOR::operator *= ( FLOAT f )
{
	r *= f;	g *= f;	b *= f;	a *= f;
	return *this;
}

LCXCOLOR& LCXCOLOR::operator /= ( FLOAT f )
{
	FLOAT fInv = 1.f / f;
	r *= fInv;	g *= fInv;	b *= fInv;	a *= fInv;
	return *this;
}


// unary operators
LCXCOLOR LCXCOLOR::operator + () const
{
	return *this;
}

LCXCOLOR LCXCOLOR::operator - () const
{
	return LCXCOLOR(-r, -g, -b, -a);
}


// binary operators
LCXCOLOR LCXCOLOR::operator + (const LCXCOLOR& c ) const
{
	return LCXCOLOR(r + c.r, g + c.g, b + c.b, a + c.a);
}

LCXCOLOR LCXCOLOR::operator - (const LCXCOLOR& c ) const
{
	return LCXCOLOR(r - c.r, g - c.g, b - c.b, a - c.a);
}

LCXCOLOR LCXCOLOR::operator * (const LCXCOLOR& c ) const
{
	return LCXCOLOR(r * c.r, g * c.g, b * c.b, a * c.a);
}


LCXCOLOR LCXCOLOR::operator * ( FLOAT f ) const
{
	return LCXCOLOR(r * f, g * f, b * f, a * f);
}

LCXCOLOR LCXCOLOR::operator / ( FLOAT f ) const
{
	FLOAT fInv = 1.f / f;
	return LCXCOLOR(r * fInv, g * fInv, b * fInv, a * fInv);
}


LCXCOLOR operator * (FLOAT f, const LCXCOLOR& c )
{
	return LCXCOLOR(f * c.r, f * c.g, f * c.b, f * c.a);
}



BOOL LCXCOLOR::operator == (const LCXCOLOR& c ) const
{
	return r == c.r && g == c.g && b == c.b && a == c.a;
}

BOOL LCXCOLOR::operator != (const LCXCOLOR& c ) const
{
	return r != c.r || g != c.g || b != c.b || a != c.a;
}


FLOAT LCXVec3Dot(const LCXVECTOR3* p1, const LCXVECTOR3* p2)
{
	return (*p1) * (*p2);
}


FLOAT LCXVec3Length(const LCXVECTOR3* v)
{
	return (FLOAT)sqrt(	v->x * v->x +
						v->y * v->y +
						v->z * v->z		);
}


FLOAT LCXPlaneDotCoord(const LCXPLANE *pP, const LCXVECTOR3 *pV)
{
	return pP->a * pV->x + pP->b * pV->y + pP->c * pV->z + pP->d;
}



