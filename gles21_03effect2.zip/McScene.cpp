// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pEft	= NULL;
}


CMcScene::~CMcScene()
{
	Destroy();
}


void CMcScene::Destroy()
{
	if(m_pEft)
	{
		delete m_pEft;
		m_pEft = NULL;
	}
}


INT CMcScene::Create()
{
	INT hr =0;

	// Create Effect
	hr = LgDev_CreateEffect("File", &m_pEft, "shaders/vertex.glsl", "shaders/fragment.glsl", "att_pos");

	if(FAILED(hr))
		return -1;

	m_pEft->SetAttribIndex("att_pos", 0);

	return 0;
}


INT CMcScene::FrameMove()
{
	return 0;
}

void CMcScene::Render()
{
	GLfloat s_vtx[] =
	{
		-1.0f, -1.0f,
		 1.0f, -1.0f,
		 0.0f,  1.0f, 
	};

	// Use the program object
	m_pEft->Begin();
	glEnableVertexAttribArray(0);	glVertexAttribPointer(0, 2, GL_FLOAT, GL_FALSE, 0, s_vtx);

	glDrawArrays(GL_TRIANGLE_FAN, 0, 3);
	glDisableVertexAttribArray(0);

	m_pEft->End();
}




