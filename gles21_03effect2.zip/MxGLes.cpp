

#include "_StdAfx.h"


CMain*	g_pApp = NULL;

//int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nShowCmd )
int main(int argc, char* argv[])
{
	CMain AppMain;
	g_pApp = &AppMain;

	if(FAILED(AppMain.Create()))
		return 0;

	return AppMain.Run();
}


