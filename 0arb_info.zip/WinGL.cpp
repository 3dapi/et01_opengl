// Implementation of the CApplicationGL class.
//
////////////////////////////////////////////////////////////////////////////////


#include <windows.h>
#include <stdio.h>

#include <gl/gl.h>
#include <gl/glu.h>
#include <gl/GLAux.h>


#include "_gl/glext.h"

#include "AppGL.h"



PFNGLCREATEPROGRAMOBJECTARBPROC  glCreateProgramObjectARB ;
PFNGLDELETEOBJECTARBPROC         glDeleteObjectARB       ;
PFNGLUSEPROGRAMOBJECTARBPROC     glUseProgramObjectARB   ;
PFNGLCREATESHADEROBJECTARBPROC   glCreateShaderObjectARB ;
PFNGLSHADERSOURCEARBPROC         glShaderSourceARB        ;
PFNGLCOMPILESHADERARBPROC        glCompileShaderARB       ;
PFNGLGETOBJECTPARAMETERIVARBPROC glGetObjectParameterivARB;
PFNGLATTACHOBJECTARBPROC         glAttachObjectARB        ;
PFNGLGETINFOLOGARBPROC           glGetInfoLogARB          ;
PFNGLLINKPROGRAMARBPROC          glLinkProgramARB         ;
PFNGLGETUNIFORMLOCATIONARBPROC   glGetUniformLocationARB  ;
PFNGLUNIFORM4FARBPROC            glUniform4fARB           ;
PFNGLUNIFORM3FARBPROC            glUniform3fARB           ;
PFNGLUNIFORM1FARBPROC            glUniform1fARB           ;
PFNGLUNIFORM1IARBPROC            glUniform1iARB           ;


PFNGLGETATTRIBLOCATIONARBPROC  glGetAttribLocationARB;
PFNGLVERTEXATTRIB3FARBPROC     glVertexAttrib3fARB;

PFNGLVERTEXATTRIBPOINTERARBPROC      glVertexAttribPointerARB;
PFNGLENABLEVERTEXATTRIBARRAYARBPROC  glEnableVertexAttribArrayARB ;
PFNGLDISABLEVERTEXATTRIBARRAYARBPROC glDisableVertexAttribArrayARB;



void loadShaderExtension()
{
	char *ven = (char*)glGetString( GL_VENDOR );
	printf("Venter: %s\n", ven);


	char *ver = (char*)glGetString( GL_VERSION );
	printf("OpenGL Supporting Version: %s\n", ver);



	//Check to see if the extensionexsists.
	char *ext = (char*)glGetString( GL_EXTENSIONS );
	char* s = ext;

//	printf("GL Extensions: %s.\n", ext);

	while(*s)
	{
		putc(*s, stdout);
		if(' ' == *s)
			putc('\n', stdout);

		++s;
	}

	//Is the Device the OpenGL Shading Language, version 1.00 supported?
	if( strstr( ext, "GL_ARB_shading_language_100" ) == NULL )
	{
		printf("Shaders are not supported.\n");
		return;
	}

	//Create all the functions using wglGetProcAddress
	glCreateProgramObjectARB		= (PFNGLCREATEPROGRAMOBJECTARBPROC		)wglGetProcAddress("glCreateProgramObjectARB"		);
	glDeleteObjectARB				= (PFNGLDELETEOBJECTARBPROC				)wglGetProcAddress("glDeleteObjectARB"				);
	glUseProgramObjectARB			= (PFNGLUSEPROGRAMOBJECTARBPROC			)wglGetProcAddress("glUseProgramObjectARB"			);
	glCreateShaderObjectARB			= (PFNGLCREATESHADEROBJECTARBPROC		)wglGetProcAddress("glCreateShaderObjectARB"		);
	glShaderSourceARB				= (PFNGLSHADERSOURCEARBPROC				)wglGetProcAddress("glShaderSourceARB"				);
	glCompileShaderARB				= (PFNGLCOMPILESHADERARBPROC			)wglGetProcAddress("glCompileShaderARB"				);

	glGetObjectParameterivARB		= (PFNGLGETOBJECTPARAMETERIVARBPROC		)wglGetProcAddress("glGetObjectParameterivARB"		);
	glAttachObjectARB				= (PFNGLATTACHOBJECTARBPROC				)wglGetProcAddress("glAttachObjectARB"				);
	glGetInfoLogARB					= (PFNGLGETINFOLOGARBPROC				)wglGetProcAddress("glGetInfoLogARB"				);
	glLinkProgramARB				= (PFNGLLINKPROGRAMARBPROC				)wglGetProcAddress("glLinkProgramARB"				);

	glGetUniformLocationARB			= (PFNGLGETUNIFORMLOCATIONARBPROC		)wglGetProcAddress("glGetUniformLocationARB"		);
	glUniform4fARB					= (PFNGLUNIFORM4FARBPROC				)wglGetProcAddress("glUniform4fARB"					);
	glUniform3fARB					= (PFNGLUNIFORM3FARBPROC				)wglGetProcAddress("glUniform3fARB"					);
	glUniform1fARB					= (PFNGLUNIFORM1FARBPROC				)wglGetProcAddress("glUniform1fARB"					);
	glUniform1iARB					= (PFNGLUNIFORM1IARBPROC				)wglGetProcAddress("glUniform1iARB"					);
	glGetAttribLocationARB			= (PFNGLGETATTRIBLOCATIONARBPROC		)wglGetProcAddress("glGetAttribLocationARB"			);
	glVertexAttrib3fARB				= (PFNGLVERTEXATTRIB3FARBPROC			)wglGetProcAddress("glVertexAttrib3fARB"			);

	glVertexAttribPointerARB		= (PFNGLVERTEXATTRIBPOINTERARBPROC		)wglGetProcAddress("glVertexAttribPointerARB"		);
	glEnableVertexAttribArrayARB	= (PFNGLENABLEVERTEXATTRIBARRAYARBPROC	)wglGetProcAddress("glEnableVertexAttribArrayARB"	);
	glDisableVertexAttribArrayARB	= (PFNGLDISABLEVERTEXATTRIBARRAYARBPROC	)wglGetProcAddress("glDisableVertexAttribArrayARB"	);
}


