

#include "_StdAfx.h"


CMain*	g_pApp = NULL;


#if defined _CONSOLE
int main(int argc, char* argv[])
#else
int WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
#endif
{
	CMain mainApp;

	HINSTANCE hInst =(HINSTANCE)GetModuleHandle(NULL);

	g_pApp = &mainApp;


	if(FAILED(mainApp.Create(hInst)))
		return 0;


	return mainApp.Run();
}


