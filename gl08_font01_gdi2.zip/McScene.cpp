// Implementation of the CMcScene class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcScene::CMcScene()
{
	m_pFont1= NULL;
	m_pFont2= NULL;

	m_pTex	= NULL;

	m_dTime	= 0;
}


CMcScene::~CMcScene()
{
	Destroy();
}

void CMcScene::Destroy()
{
	SAFE_DELETE(	m_pFont1	);
	SAFE_DELETE(	m_pFont2	);
	SAFE_DELETE(	m_pTex		);
}


INT CMcScene::Init()
{
	INT	hr=0;


	hr = LgDev_CreateTexture(NULL, &m_pTex, "texture/title_06.png", NULL, 0, 0);
	if(FAILED(hr))
		return -1;

	{
		IGLFont::TFont	hFont(18, FW_BOLD, FALSE, 0, "Arial��ü");
		hr = LgDev_CreateFont(NULL, &m_pFont1, &hFont);
		if(FAILED(hr))
			return -1;

		m_pFont1->SetString("FPS:");
	}

	{
		IGLFont::TFont	hFont(72, FW_BOLD, FALSE, 0, "�ü�ü");
		hr = LgDev_CreateFont(NULL, &m_pFont2, &hFont);
		if(FAILED(hr))
			return -1;

		m_pFont2->SetString("�ȳ��ϼ���. GDI ��� �Դϴ�.");
	}

	m_dTime = GetTickCount();

	return 0;
}

INT CMcScene::FrameMove()
{
	static int c= 0;

	++c;

	if(c>512)
	{
		DWORD	dTime = GetTickCount();

		FLOAT	fTime = dTime - m_dTime;

		fTime	/=c;

		fTime	= 1000.f/fTime;

		m_dTime = dTime;
		c		= 0;


		char	sMsg[128]={0};
		sprintf(sMsg, "FPS: %4.f", fTime);
		m_pFont1->SetString(sMsg);
	}


//	m_pFont->SetString("");

	return 0;
}

void CMcScene::Render()
{
	glShadeModel(GL_SMOOTH);
	glEnable(GL_CULL_FACE);
	glFrontFace(GL_CCW);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

	m_pTex->DrawPixel(NULL, &D3DXVECTOR2(2,2), NULL, 0, NULL, D3DXCOLOR(1,1,1,1));
	m_pFont1->DrawTxt(NULL, NULL, 0, &D3DXVECTOR2(5, 5), D3DXCOLOR(1,1,0,1));
	m_pFont2->DrawTxt(NULL, NULL, 0, &D3DXVECTOR2(-10, 200), D3DXCOLOR(0,1,1,1));
}


