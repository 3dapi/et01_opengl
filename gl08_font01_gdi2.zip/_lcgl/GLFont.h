// Interface for the CGLFont class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _GLFont_H_
#define _GLFont_H_

#include <string>

class CGLFont : public IGLFont
{
protected:
	HFONT		m_hFnt;
	TFont		m_Font;

	GLuint		m_nTex;			// Name
	INT			m_ImgW;
	INT			m_ImgH;

	std::string	m_sMsg;

public:
	CGLFont ();
	virtual ~CGLFont();

	virtual	INT		Create(void* =0, void* =0, void* =0, void* =0);
	virtual	void	Destroy();

	virtual	GLuint	GetName();
	virtual	GLenum	GetFMT() ;
	virtual	GLenum	GetType();

	virtual	INT		GetImgW();
	virtual	INT		GetImgH();

	virtual	void	SetString(char* sMsg);

	virtual	void	DrawTxt(  D3DXVECTOR2* vcScl	// Scaling
							, D3DXVECTOR2* vcRot	// Rotation Center
							, FLOAT fRot			// Angle(Radian)
							, D3DXVECTOR2* vcTrn	// Position
							, D3DXCOLOR dcolor		// color
						);
};




#endif